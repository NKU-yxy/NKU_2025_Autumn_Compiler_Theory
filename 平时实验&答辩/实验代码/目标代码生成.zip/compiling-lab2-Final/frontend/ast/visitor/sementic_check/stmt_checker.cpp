#include <frontend/ast/visitor/sementic_check/ast_checker.h>
#include <debug.h>

namespace FE::AST
{
    bool ASTChecker::visit(ExprStmt& node)
    {
        // 在全局作用域不允许表达式语句（除了空语句）
        if (node.expr && symTable.isGlobalScope())
        {
            errors.push_back("Expression statement not allowed at global scope at line " +
                            std::to_string(node.line_num));
            return false;
        }
        
        // 空表达式语句直接通过，否则检查内部表达式
        if (!node.expr) 
            return true;
        return apply(*this, *node.expr);
    }

    // SysY和自己定义的函数都存在funcDecls内 
    // 但SysY语言不要求对main函数一定要有return xx 的检查 所以对main函数去掉这个检查
    // FuncDeclStmt: 检查函数重定义 & 记录 main 函数存在性 & 处理形参和函数体
    // 函数检查
    bool ASTChecker::visit(FuncDeclStmt& node)
    {
        bool res = true;

        // 检查函数重定义（按 Entry* 作为 key）
        if (funcDecls.count(node.entry))
        {
            errors.push_back("Redefinition of function at line " + std::to_string(node.line_num));
            res = false;
        }
        else
        {
            // 在这里记录自己新写的新函数
            funcDecls[node.entry] = &node;
        }

        // 记录 main 是否存在：比较 Entry 指针是否等于 "main" 对应的 Entry
        using SymEnt = FE::Sym::Entry;
        static SymEnt* mainEntry = SymEnt::getEntry("main");
        bool isMain = (node.entry == mainEntry);
        if (isMain) 
            mainExists = true;

        // 保存旧状态
        Type*  oldRet    = curFuncRetType;
        bool   oldHasRet = funcHasReturn;
        size_t oldLoop   = loopDepth;

        curFuncRetType = node.retType;
        funcHasReturn  = false;
        loopDepth      = 0;

        // 函数作用域
        symTable.enterScope();

        // 处理形参
        if (node.params)
        {
            for (auto* param : *(node.params))
            {
                if (!param) 
                    continue;
                res &= apply(*this, *param);
            }
        }

        // 处理函数体
        if (node.body) res &= apply(*this, *node.body);

        symTable.exitScope();

        // 非 void 函数要求出现过 return 语句
        // 但对 main 做特例：允许省略 return，默认返回 0
        if (node.retType != voidType && !funcHasReturn)
        {
            if (!isMain)
            {
                errors.push_back(
                    "Non-void function may not return a value at line " + std::to_string(node.line_num));
                res = false;
            }
            // isMain 的情况不报错，语义上允许 int main() 无 return
        }

        // 恢复旧状态
        curFuncRetType = oldRet;
        funcHasReturn  = oldHasRet;
        loopDepth      = oldLoop;

        return res;
    }


    bool ASTChecker::visit(VarDeclStmt& node)
    {
        // 空声明直接通过，否则交给 VarDeclaration 处理
        if (!node.decl) 
            return true;
        return apply(*this, *node.decl);
    }

    bool ASTChecker::visit(BlockStmt& node)
    {
        bool res = true;

        // 新的块作用域
        symTable.enterScope();

        if (node.stmts)
        {
            for (auto* stmt : *(node.stmts))
            {
                if (!stmt) continue;
                res &= apply(*this, *stmt);
            }
        }

        symTable.exitScope();

        return res;
    }
    // ReturnStmt: 检查返回值表达式 & 类型兼容性
    // 对 main 函数做特例处理，允许省略 return 语句
    // 非 main 函数仍然要求非 void 函数必须有 return 语句
    // 注意：这里只检查 return 语句本身，是否有 return 语句由 FuncDeclStmt 检查
    /*
        1.int-like 之间可以互相转换（int / bool / long long）。
        2. 形参是 float、实参是 int-like：允许 int → float。
        • 你会写：arg->attr.val.value.type = paramTy;
        • 也就是说，直接把这个表达式节点的类型“改成” float，以便后续 codegen 知道要做对应的转换。
        3. 形参是 int-like、实参是 float：允许 float → int。
        • 同样把实参表达式的类型改成形参类型。
    */
    bool ASTChecker::visit(ReturnStmt& node)
    {
        bool res = true;

        // 当前函数出现过 return
        funcHasReturn = true;

        // 无返回值：对应 "return;"
        if (!node.retExpr)
        {
            if (curFuncRetType != voidType)
            {
                errors.push_back(
                    "Missing return value in non-void function at line " +
                    std::to_string(node.line_num));
                res = false;
            }
            return res;
        }

        // 有返回值
        res &= apply(*this, *node.retExpr);
        auto* retTy = node.retExpr->attr.val.value.type;

        // 1) 函数声明为 void，但实际 return 有值
        if (curFuncRetType == voidType)
        {
            errors.push_back(
                "Return with a value in void function at line " +
                std::to_string(node.line_num));
            res = false;
            return res;
        }

        // 2) 非 void：检查返回表达式类型与函数返回类型是否“兼容”
        if (!retTy || !curFuncRetType)
        {
            // 理论上不会为空，这里防御一下
            errors.push_back("Return type unresolved at line " +
                            std::to_string(node.line_num));
            return false;
        }

        // ---------- int / bool / float 兼容规则 ----------
        auto isIntLike = [](Type* t) {
            return t == intType || t == boolType || t == llType;
        };
        auto isFloatLike = [](Type* t) {
            return t == floatType;
        };

        Type* exprType = retTy;
        Type* funcRet  = curFuncRetType;

        bool compatible = false;

        // (1) 类型完全相同
        if (exprType == funcRet)
        {
            compatible = true;
        }
        // (2) 函数返回 & 表达式都是 int-like（int/bool/ll）
        else if (isIntLike(funcRet) && isIntLike(exprType))
        {
            compatible = true;
        }
        // (3) 函数返回 float，表达式是 int-like：允许 int -> float
        else if (isFloatLike(funcRet) && isIntLike(exprType))
        {
            compatible = true;
            // 标记为float，便于CodeGen知道需要做类型转换
            node.retExpr->attr.val.value.type = funcRet;
        }
        // (4) 函数返回 int-like，表达式是 float：允许 float -> int
        // 注意：不要修改expression的type，让它保持float
        // 这样CodeGen会看到类型不匹配并插入fptosi转换指令
        else if (isIntLike(funcRet) && isFloatLike(exprType))
        {
            compatible = true;
            // 不修改type，保持expression为float
            // CodeGen的visit(ReturnStmt)会检测到类型不匹配并做转换
        }

        if (!compatible)
        {
            errors.push_back("Return type mismatch at line " +
                            std::to_string(node.line_num));
            res = false;
        }

        return res;
    }

    // WhileStmt: 检查条件表达式 & 循环体
    bool ASTChecker::visit(WhileStmt& node)
    {
        bool res = true;

        // 检查条件表达式
        if (node.cond)
        {
            res &= apply(*this, *node.cond);
            if (node.cond->attr.val.value.type == voidType)
            {
                errors.push_back(
                    "While condition has void type at line " + std::to_string(node.line_num));
                res = false;
            }
        }

        // 循环体：管理循环深度（用于 break/continue 检查）
        ++loopDepth;
        if (node.body) res &= apply(*this, *node.body);
        --loopDepth;

        return res;
    }

    // IfStmt: 检查条件表达式 & then / else 分支
    bool ASTChecker::visit(IfStmt& node)
    {
        bool res = true;

        // 条件
        res &= apply(*this, *node.cond);
        if (node.cond->attr.val.value.type == voidType)
        {
            errors.push_back("If condition has void type at line " + std::to_string(node.line_num));
            res = false;
        }

        // then / else 分支
        if (node.thenStmt) 
            res &= apply(*this, *node.thenStmt);

        if (node.elseStmt) 
            res &= apply(*this, *node.elseStmt);

        return res;
    }

    bool ASTChecker::visit(BreakStmt& node)
    {
        // 只能在循环内部使用
        if (loopDepth == 0)
        {
            errors.push_back("break statement not within loop at line " + std::to_string(node.line_num));
            return false;
        }
        return true;
    }

    bool ASTChecker::visit(ContinueStmt& node)
    {
        // 只能在循环内部使用
        if (loopDepth == 0)
        {
            errors.push_back(
                "continue statement not within loop at line " + std::to_string(node.line_num));
            return false;
        }
        return true;
    }

   bool ASTChecker::visit(ForStmt& node)
    {
        bool res = true;

        // for(init; cond; step) 共用一层作用域
        symTable.enterScope();

        // 1) init
        if (node.init) res &= apply(*this, *node.init);

        // 2) cond
        if (node.cond)
        {
            res &= apply(*this, *node.cond);
            if (node.cond->attr.val.value.type == voidType)
            {
                errors.push_back(
                    "For condition has void type at line " + std::to_string(node.line_num));
                res = false;
            }
        }
        // 没有 cond ==> for(;;) 视为无限循环，这里不用特判

        // 3) body：真正处于“循环内部”的只有 body
        ++loopDepth;
        if (node.body) res &= apply(*this, *node.body);
        --loopDepth;

        // 4) step：不允许 break/continue，本来语法上也写不出
        if (node.step) res &= apply(*this, *node.step);

        symTable.exitScope();
        return res;
    }



}  // namespace FE::AST
