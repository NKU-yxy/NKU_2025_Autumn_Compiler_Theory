#include <frontend/ast/visitor/sementic_check/ast_checker.h>
#include <debug.h>
#include <algorithm>

namespace FE::AST
{
    

    
    bool ASTChecker::visit(LeftValExpr& node)
    {
        bool res = true;

        // 1) 查符号
        auto* symAttr = symTable.getSymbol(node.entry);
        if (!symAttr)
        {
            errors.push_back("Use of undeclared variable at line " +
                            std::to_string(node.line_num));
            res = false;

            node.attr.val.isConstexpr = false;
            node.attr.val.value       = VarValue();
            node.attr.val.value.type  = voidType;
            return false;
        }

        // 2) 检查数组下标表达式
        if (node.indices)
        {
            for (auto* idx : *(node.indices))
            {
                if (!idx) continue;
                res &= apply(*this, *idx);

                auto* idxTy = idx->attr.val.value.type;
                bool  isValidIndex = (idxTy == intType || idxTy == boolType || idxTy == llType);
                if (!isValidIndex)
                {
                    errors.push_back("Array index must be int at line " +
                                    std::to_string(idx->line_num));
                    res = false;
                }
            }
        }

        Type* baseTy   = symAttr->type;
        bool  hasIndex = (node.indices && !node.indices->empty());
        bool  isScalar = !hasIndex && symAttr->arrayDims.empty();

        node.attr.val.isConstexpr = false;
        node.attr.val.value       = VarValue();

        if (hasIndex)
        {
            // a[i] / a[i][j]：元素类型
            // 兼容两种情况：
            //  1) 普通数组：symAttr->type 是 basic type (int/float)
            //  2) 形参数组：symAttr->type 是 pointer type (int*)
            Type* elemTy = nullptr;
            if (baseTy)
            {
                if (baseTy->getTypeGroup() == TypeGroup::POINTER)
                {
                    auto bt = baseTy->getBaseType();         // underlying basic kind
                    elemTy  = TypeFactory::getBasicType(bt); // intType / floatType 等
                }
                else
                {
                    elemTy = baseTy;
                }
            }
            node.attr.val.value.type = elemTy ? elemTy : intType;
        }
        else
        {
            // 无下标：保持声明时的类型
            node.attr.val.value.type = baseTy ? baseTy : intType;
        }

        // 4) 标量 const 且有常量初始化：当作编译期常量
        if (!hasIndex && isScalar && !symAttr->initList.empty())
        {
            node.attr.val.isConstexpr = true;
            node.attr.val.value       = symAttr->initList[0];

            if (!node.attr.val.value.type)
            {
                node.attr.val.value.type = baseTy ? baseTy : intType;
            }
        }

        return res;

        /*
        if (!hasIndex && isScalar && symAttr->isConstDecl && !symAttr->initList.empty())
        {
            node.attr.val.isConstexpr = true;
            node.attr.val.value       = symAttr->initList[0];

            if (!node.attr.val.value.type)
            {
                node.attr.val.value.type = baseTy ? baseTy : intType;
            }
        }

        return res;
        */
    }


    bool ASTChecker::visit(LiteralExpr& node)
    {
        // 字面量：总是编译期常量，类型和值都在 literal 里
        node.attr.val.isConstexpr = true;
        node.attr.val.value       = node.literal;
        return true;
    }

    bool ASTChecker::visit(UnaryExpr& node)
    {
        ASSERT(node.expr && "Null operand in UnaryExpr");
        bool res = apply(*this, *node.expr);

        if (node.expr->attr.val.value.type == voidType)
        {
            errors.push_back("Unary operator applied to void expression at line " +
                             std::to_string(node.line_num));
            return false;
        }

        bool hasError = false;
        node.attr.val = typeInfer(node.expr->attr.val, node.op, node, hasError);

        return res && !hasError;
    }

    bool ASTChecker::visit(BinaryExpr& node)
    {
        ASSERT(node.lhs && node.rhs && "Null operand in BinaryExpr");

        bool res = true;
        res &= apply(*this, *node.lhs);
        res &= apply(*this, *node.rhs);

        // 左右不能是 void
        if (node.lhs->attr.val.value.type == voidType ||
            node.rhs->attr.val.value.type == voidType)
        {
            errors.push_back("Binary operator applied to void expression at line " +
                             std::to_string(node.line_num));
            return false;
        }

        // 赋值要求左侧是可赋值的左值
        if (node.op == Operator::ASSIGN)
        {
            if (dynamic_cast<LeftValExpr*>(node.lhs) == nullptr)
            {
                errors.push_back("Left operand of assignment is not an lvalue at line " +
                                 std::to_string(node.line_num));
                res = false;
            }
        }

        bool hasError = false;
        node.attr.val = typeInfer(node.lhs->attr.val, node.rhs->attr.val, node.op, node, hasError);

        return res && !hasError;
    }
    

   

    // 检查函数是否声明，参数个数和类型是否匹配
    // 检查函数调用是否合法
    bool ASTChecker::visit(CallExpr& node)
    {
        bool res = true;

        // 1. 函数是否声明
        auto it = funcDecls.find(node.func);
        if (it == funcDecls.end())
        {
            errors.push_back("Call to undefined function at line " +
                            std::to_string(node.line_num));
            node.attr.val.isConstexpr = false;
            node.attr.val.value       = VarValue();
            node.attr.val.value.type  = voidType;
            return false;
        }
        // 找到了声明（可能是库函数，也可能是用户函数
        FuncDeclStmt* func = it->second;

        auto* args   = node.args;
        auto* params = func->params;
        // 2.检查实参个数 和 形参个数是否一致
        size_t argN   = args ? args->size() : 0;
        size_t paramN = params ? params->size() : 0;

        if (argN != paramN)
        {
            errors.push_back("Argument count mismatch at line " +
                            std::to_string(node.line_num));
            res = false;
        }

        size_t n = std::min(argN, paramN);
        // 3.逐个参数检查类型兼容性
        for (size_t i = 0; i < n; ++i)
        {
            auto* arg   = (*args)[i];
            auto* param = (*params)[i];

            if (!arg || !param) continue;

            // 先检查实参表达式本身
            res &= apply(*this, *arg);

            auto* argTy   = arg->attr.val.value.type;
            auto* paramTy = param->attr.val.value.type;

            // 防御：类型指针为空就先跳过，避免空指针崩溃
            if (!argTy || !paramTy) 
                continue;

            // int / bool/float  互相兼容 
            auto isIntLike = [](Type* t) {
                return t == intType || t == boolType || t == llType;
            };

            auto isFloatLike = [](Type* t) {
                return t == floatType;
            };


            bool compatible = false;

            // 1) 类型完全相同：直接兼容
            if (argTy == paramTy)
            {
                compatible = true;
            }
            // 2) 形参和实参都是 int-like：int / bool / long long 互相兼容
            else if (isIntLike(paramTy) && isIntLike(argTy))
            {
                compatible = true;
            }
            // 3) 形参是 float，实参是 int-like：允许 int -> float 隐式转换
            else if (isFloatLike(paramTy) && isIntLike(argTy))
            {
                compatible = true;
            }
            // 4) 形参是 int-like，实参是 float：允许 float -> int 隐式转换
            else if (isIntLike(paramTy) && isFloatLike(argTy))
            {
                compatible = true;
            }

            //  指针形参 ← 数组实参 允许匹配 
            if (!compatible)
            {
                // 形参是指针类型
                if (paramTy->getTypeGroup() == FE::AST::TypeGroup::POINTER)
                {
                    // 实参是一个左值表达式
                    if (auto* lv = dynamic_cast<LeftValExpr*>(arg))
                    {
                        // 查符号表，看这个左值是不是数组变量
                        auto* vAttr = symTable.getSymbol(lv->entry);   // VarAttr*
                        if (vAttr && !vAttr->arrayDims.empty())
                        {
                            // 数组变量作为实参，允许匹配指针形参
                            compatible = true;
                        }
                    }
                }
            }
            // 报错：参数类型不兼容
            if (!compatible)
            {
                errors.push_back("Argument type mismatch at line " +
                                std::to_string(arg->line_num));
                res = false;
            }
        }

        // 调用表达式本身：运行期值，不做常量折叠
        node.attr.val.isConstexpr = false;
        node.attr.val.value       = VarValue();
        node.attr.val.value.type  = func->retType;

        return res;
    }

    // 逗号表达式按顺序执行所有子表达式，但最终的 “值”“类型”“是否为常量” 仅由最后一个子表达式决定
    bool ASTChecker::visit(CommaExpr& node)
    {
        bool res = true;
        // 空逗号表达式：没有子表达式
        if (!node.exprs || node.exprs->empty())
        {
            node.attr.val.isConstexpr = false;
            node.attr.val.value       = VarValue();
            node.attr.val.value.type  = voidType;
            return true;
        }

        ExprNode* last = nullptr;
        // 遍历并处理所有子表达式
        for (auto* e : *(node.exprs))
        {
            if (!e) 
                continue;
            last = e;
            res &= apply(*this, *e);
        }

        // 逗号表达式的值 = 最后一个子表达式的值
        // 赋值逗号表达式的最终属性
        if (last) 
            node.attr.val = last->attr.val;

        return res;
    }

}  // namespace FE::AST
