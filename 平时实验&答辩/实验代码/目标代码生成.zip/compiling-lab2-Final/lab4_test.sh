#!/usr/bin/env bash
# lab4_test.sh - Run required Lab4 tests in sequence
# Usage: ./lab4_test.sh

set -u

echo "Starting Lab4 test suite"

cmds=(
  "python3 test.py --group=Basic --opt=0"
  "python3 test.py --group=Basic --opt=1"
  "python3 test.py --group=Advanced --opt=0"
  "python3 test.py --group=Advanced --opt=1"
  "python3 optimize_test.py"
)

i=1
for c in "${cmds[@]}"; do
  echo
  echo "=========================================="
  echo "Test #$i: $c"
  echo "------------------------------------------"
  eval $c
  rc=$?
  if [ $rc -eq 0 ]; then
    echo "Result: PASS"
  else
    echo "Result: FAIL (rc=$rc)"
  fi
  i=$((i+1))
done

# Compile all .sy files under testcase/semant to LLVM IR
SEMANT_DIR="testcase/semant"
OUT_DIR="semant_output"
mkdir -p "$OUT_DIR"

echo
echo "Compiling all files in $SEMANT_DIR to LLVM IR (level O1)"

total=0
fails=0
shopt -s nullglob
for f in "$SEMANT_DIR"/*.sy; do
  base=$(basename "$f")
  out="$OUT_DIR/${base%.sy}.ll"
  echo
  echo "Compiling: $base -> $out"
  ./bin/compiler "$f" -llvm -o "$out" -O1
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "  -> COMPILER ERROR (rc=$rc)"
    fails=$((fails+1))
  else
    echo "  -> OK"
  fi
  total=$((total+1))
done

echo
echo "Semant tests compiled: $total files, failures: $fails"

echo "Lab4 test suite finished"
exit 0
