#!/usr/bin/env bash
# final_test.sh - Run full Lab4 test battery and summarize scores
# Usage: ./final_test.sh

set -u

LOG_FILE="final_test_output.log"

echo "Starting final test suite"
echo "Logging to $LOG_FILE"
: > "$LOG_FILE"

cmds=(
  "python3 test.py --group=Basic --opt=0"
  "python3 test.py --group=Basic --opt=1"
  "python3 test.py --group=Advanced --opt=0"
  "python3 test.py --group=Advanced --opt=1"
  "python3 test.py --stage=arm --group=Basic --opt=1"
  "python3 test.py --stage=arm --group=Advanced --opt=1"
  "python3 optimize_test.py"
)

i=1
for c in "${cmds[@]}"; do
  echo
  echo "=========================================="
  echo "Test #$i: $c"
  echo "------------------------------------------"
  eval "$c" 2>&1 | tee -a "$LOG_FILE"
  rc=${PIPESTATUS[0]}
  if [ $rc -eq 0 ]; then
    echo "Result: PASS"
  else
    echo "Result: FAIL (rc=$rc)"
  fi
  i=$((i+1))
done

# Compile all .sy files under testcase/semant to LLVM IR
SEMANT_DIR="testcase/semant"
OUT_DIR="semant_output"
mkdir -p "$OUT_DIR"

echo
echo "Compiling all files in $SEMANT_DIR to LLVM IR (level O1)"

total=0
fails=0
shopt -s nullglob
for f in "$SEMANT_DIR"/*.sy; do
  base=$(basename "$f")
  out="$OUT_DIR/${base%.sy}.ll"
  echo
  echo "Compiling: $base -> $out"
  ./bin/compiler "$f" -llvm -o "$out" -O1
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "  -> COMPILER ERROR (rc=$rc)"
    fails=$((fails+1))
  else
    echo "  -> OK"
  fi
  total=$((total+1))
done

shopt -u nullglob

echo
echo "Semant tests compiled: $total files, failures: $fails"

echo
echo "Score excerpts (/100) from test runs:"
if grep -Eq "[0-9]+/100" "$LOG_FILE"; then
  grep -E "[0-9]+/100" "$LOG_FILE" | sed 's/^/  /'
else
  echo "  (no '/100' score lines found; check $LOG_FILE for details)"
fi

echo "Final test suite finished"
exit 0
