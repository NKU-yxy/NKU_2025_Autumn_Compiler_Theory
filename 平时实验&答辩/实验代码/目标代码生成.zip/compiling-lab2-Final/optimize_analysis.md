# 优化答辩讲解（结合本仓库实现 + O0/O1 对照）

目标：用“大白话”讲清 mem2reg / SCCP / CSE 的概念、实现、证据。

---

## 0. 优化流水线（答辩先说这段最稳）

- 触发条件：`optimizeLevel > 0` 才跑优化（也就是 `-O1`）。
- 流水线位置：见 [main.cpp][pipe-main]。
- 顺序（非常关键）：
  1) UnifyReturn：把多个 `return` 统一成一个出口块。
  2) mem2reg：局部标量 alloca 提升到 SSA（插 `phi`）。
  3) SCCP：常量传播 + 条件可达性剪枝 + 删不可达块。
  4) CSE：块内公共子表达式消除（你的实现是 block-local）。
- 为什么这样排：
  - mem2reg 先把值流变 SSA，SCCP 才好推常量。
  - SCCP 删块后 IR 变短，CSE 更容易命中。

---

## 1. mem2reg（把“栈变量”变成 SSA）

### 1.1 它是什么（大白话）

未优化时，局部变量通常是“栈槽模型”：

- `alloca`：开槽
- `store`：写槽（赋值）
- `load`：读槽（使用变量）

mem2reg 做的事：

- 把这些局部标量变量改成 SSA 值流（尽量不落内存）
- 在控制流汇合处插 `phi` 表达“按前驱选择值”

一句话总结：消灭局部 `alloca/load/store`，在汇合点用 `phi`。

### 1.2 你自己的实现（老师问“你怎么做的”就按这 4 步答）

入口：`Mem2RegPass::runOnFunction`，见 [mem2reg-run][].

1) 收集可提升变量：`collectPromotableVars`，见 [mem2reg-collect][].
- 只提升标量：数组（`dims` 非空）不做。
- 地址不逃逸才做：地址被当普通值乱用就不提升。
- 记录 `defBlocks`：哪些块里对变量有 `store`。

2) 支配信息：DomInfo（支配树/支配前沿），见 [dominfo][].

3) 插 phi：`insertPhiNodes`，见 [mem2reg-insert-phi][].
- 从 `defBlocks` 出发，沿支配前沿（DF）扩散。
- 到达的汇合点插对应变量的 `phi`。

4) 重命名：`renameVariables`，见 [mem2reg-rename][].
- 维护 `valueStack[var]`（变量“当前最新 SSA 值”）。
- `store`：RHS 入栈并删 store。
- `load`：用栈顶替换 uses 并删 load。
- 给后继块的 `phi` 补 incoming。

清理：删入口块里被提升变量的 alloca，并做 DCE，见 [mem2reg-clean][].

### 1.3 证据（optimize 用例）

- noloadstore：见 [noloadstore-ll][]（无局部 alloca/store）。
- samebb：见 [samebb-ll][]（全程 SSA 计算链）。
- complex_phi：见 [complexphi-ll][]（循环/汇合处多路 `phi`）。

### 1.4 功能样例（functional）O0 vs O1 对照

#### (1) Basic：if-if-else 的 `phi`

- 源码：见 [45-if-sy][].
- O0：栈槽形态（alloca/load/store），见 [45-if-o0][].
- O1：出现 `phi`、load/store 消失，见 [45-if-o1][].

#### (2) Basic：while 循环头的 `phi`

- 源码：见 [50-while-sy][].
- O0：每轮 load -> 算 -> store，见 [50-while-o0][].
- O1：循环头 `phi` 合并初值/回边更新值，见 [50-while-o1][].

#### (3) Advanced：多分支返回用 `phi` 合并

- 源码：见 [68-full-sy][].
- O0：参数先 alloca/store/load，见 [68-full-o0][].
- O1：返回前 `phi` 合并不同路径返回值，见 [68-full-o1][].

---

## 2. SCCP（稀疏条件常量传播：推常量 + 剪枝）

### 2.1 它是什么（大白话）

SCCP = 常量传播 + 条件剪枝：

- 值能确定为常量：一路替换成常量。
- `br i1 cond` 若 `cond` 恒真/恒假：只保留会走的边。
- 另一边对应块会不可达，然后整体删掉。

一句话总结：能算死的提前算死，走不到的路剪掉。

### 2.2 你自己的实现（对应源码）

- 三值格：UNDEF / CONST / OVERDEF，见 [sccp-lattice][].
- 合并 `join`：见 [sccp-join][].
- 可达性 `executable[blockId]`：见 [sccp-exe-init][].
- 条件分支传播可达性：见 [sccp-branch][].
- `phi` 只合并可达前驱：见 [sccp-phi][].
- 常量替换 uses：见 [sccp-replace][].
- 分支折叠 + 清 phi incoming：见 [sccp-fold-branch][].
- 删除不可达块：见 [sccp-rm-unreach][].

### 2.3 证据（optimize + functional）

- optimize：sccp2
  - 源码：见 [sccp2-sy][].
  - 优化后只剩常量链：见 [sccp2-ll][].

- functional/Basic：short_circuit3
  - 源码：见 [21-short-sy][].
  - O0：先算条件再分支：见 [21-short-o0][].
  - O1：条件被折叠，直接顺序输出：见 [21-short-o1][].

---

## 3. CSE（公共子表达式消除：重复纯计算只算一次）

### 3.1 它是什么（大白话）

同一个基本块里如果重复出现完全一样的纯计算：

- 未优化：每次都重新算。
- CSE：第一次算出来后，后面复用第一次结果，删掉重复指令。

### 3.2 你自己的实现（对应源码）

- 你的 CSE 是“块内 CSE”：每个 block 一张表 `expr2reg`。
  - 见 [cse-block-local][].
- 表达式 key：`opcode + (type/cond) + operands`。
  - 可交换运算归一：见 [cse-comm][].
  - buildKey：见 [cse-key][].
- 保守性（防错优化）：遇到副作用/控制流指令清表。
  - `STORE/CALL/BR/RET` 清表：见 [cse-clear][].

### 3.3 证据与补充说明

- 最典型证据（optimize）：cse1
  - 源码：见 [cse1-sy][].
  - 优化后：见 [cse1-ll][].
  - 现象：大和式凝结成一次 `%reg_69`，后续大量复用。

- functional 里 CSE 不明显是正常的：
  - 如 [29-csemem-sy][] 大量数组读写/调用。
  - 你的实现遇到 `call/store` 会清表，所以不跨副作用复用。

---

## 4. 答辩 30 秒速讲模板

- 我这份 O1 流水线：UnifyReturn → mem2reg → SCCP → CSE（见 [pipe-main][]）。
- mem2reg：消掉局部栈槽，在汇合点插 `phi`。
  - 证据：while 头 `phi`，见 [50-while-o1][].
- SCCP：三值格推常量 + 条件剪枝删不可达。
  - 证据：short_circuit3 直接输出常量字符，见 [21-short-o1][].
- CSE：块内重复纯计算只算一次；遇副作用清表保语义。
  - 证据：cse1 里 `%reg_69` 被大量复用，见 [cse1-ll][].

## 5. 结论

- mem2reg：局部标量 SSA 化 + `phi` 选值。
- SCCP：常量折叠 + 分支剪枝 + 删除不可达。
- CSE：块内复用纯计算，保守处理副作用。

---

[pipe-main]: main.cpp#L320-L343

[mem2reg-run]: middleend/pass/mem2reg.cpp#L700-L761
[mem2reg-collect]: middleend/pass/mem2reg.cpp#L423-L569
[mem2reg-insert-phi]: middleend/pass/mem2reg.cpp#L572-L603
[mem2reg-rename]: middleend/pass/mem2reg.cpp#L604-L689
[mem2reg-clean]: middleend/pass/mem2reg.cpp#L740-L758
[dominfo]: middleend/pass/analysis/dominfo.cpp#L12-L54

[noloadstore-ll]: test_output/noloadstore.ll#L22-L77
[samebb-ll]: test_output/samebb.ll#L22-L140
[complexphi-ll]: test_output/complex_phi.ll#L25-L147

[45-if-sy]: testcase/functional/Basic/45_if_test3.sy
[45-if-o0]: test_output/45_if_test3-O0.ll#L20-L61
[45-if-o1]: test_output/45_if_test3-O1.ll#L20-L40

[50-while-sy]: testcase/functional/Basic/50_while_test3.sy
[50-while-o0]: test_output/50_while_test3-O0.ll#L24-L60
[50-while-o1]: test_output/50_while_test3-O1.ll#L27-L56

[68-full-sy]: testcase/functional/Advanced/68_full_conn.sy
[68-full-o0]: test_output/68_full_conn-O0.ll#L20-L45
[68-full-o1]: test_output/68_full_conn-O1.ll#L20-L41

[sccp-lattice]: middleend/pass/sccp.cpp#L22-L47
[sccp-join]: middleend/pass/sccp.cpp#L49-L90
[sccp-exe-init]: middleend/pass/sccp.cpp#L628-L639
[sccp-branch]: middleend/pass/sccp.cpp#L665-L717
[sccp-phi]: middleend/pass/sccp.cpp#L781-L807
[sccp-replace]: middleend/pass/sccp.cpp#L834-L844
[sccp-fold-branch]: middleend/pass/sccp.cpp#L846-L879
[sccp-rm-unreach]: middleend/pass/sccp.cpp#L474-L526

[sccp2-sy]: testcase/optimize/sccp/sccp2.sy#L1-L34
[sccp2-ll]: test_output/sccp2.ll#L20-L60

[21-short-sy]: testcase/functional/Basic/21_short_circuit3.sy
[21-short-o0]: test_output/21_short_circuit3-O0.ll#L160-L214
[21-short-o1]: test_output/21_short_circuit3-O1.ll#L114-L155

[cse-block-local]: middleend/pass/cse.cpp#L297-L333
[cse-comm]: middleend/pass/cse.cpp#L139-L156
[cse-key]: middleend/pass/cse.cpp#L167-L273
[cse-clear]: middleend/pass/cse.cpp#L276-L313

[cse1-sy]: testcase/optimize/scalar_cse/cse1.sy#L1-L123
[cse1-ll]: test_output/cse1.ll#L31-L140

[29-csemem-sy]: testcase/functional/Advanced/29_csememtest1.sy
