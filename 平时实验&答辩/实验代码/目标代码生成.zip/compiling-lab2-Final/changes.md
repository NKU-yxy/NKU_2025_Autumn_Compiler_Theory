## Change Log

### 2025-12-22

1) **LinearScan register allocation rework**
   - Replaced previous "spill everything" behavior with a real linear-scan allocator that: (a) builds allocatable pools excluding reserved and scratch registers; (b) collects physical registers already referenced by instructions to avoid conflicts; (c) marks intervals crossing calls and prefers callee-saved registers for them; (d) performs active-set based allocation with spill heuristics (spill farthest end); (e) records spill slots only when needed.
   - Added scratch filtering to avoid assigning real allocations onto dedicated spill/reload temporaries.
   - Added MIR rewrite that uses allocated phys regs when available, otherwise inserts reload/spill with bounded scratch selection and ensures spill slots exist.

### 2025-12-23

1) **AArch64 暂存寄存器预留**
   - 将 x9 标记为保留寄存器，避免寄存器分配器把其分配给虚拟寄存器，从而与栈展开/恢复阶段用作大偏移计算的临时寄存器发生冲突。
2) **AArch64 Phi 下沉修复**
   - Phi 处理改为先收集、后统一插入前驱拷贝，并修正键值顺序错误（label 作为键），保证 SSA Phi 能正确生成前驱到目标的 move，避免未初始化寄存器导致的循环和分支错误（验证用例：Basic/4_accumulate.sy 输出正确 210）。
3) **AArch64 全局常量初始化回退**
   - 全局变量若 VarAttr.initList 为空时，回退读取 GlbVarDeclInst 的立即数 init，确保标量常量（如 const 全局）初始化不丢失。验证 Basic/8_stmt_expr.sy 输出修复为 1024，返回码 0。
4) **保守跨调用寄存器分配**
   - 在函数包含调用点时，将所有活跃区间标记为跨调用，优先使用被调用者保存寄存器，避免递归/深调用下 caller-saved 被覆盖。验证 Basic/10_reverse_output.sy 按 AArch64 流程输出与期望一致。
5) **AArch64 Phi 并行拷贝纠正**
   - 针对同一前驱存在多组 Phi 时使用并行拷贝+临时寄存器断环，保证循环/交换等场景的 Phi 赋值不被后续拷贝覆盖（修复 18_enum 等涉及多 Phi 的用例潜在错误）。
6) **线性扫描活跃区间构建修正**
   - 反向遍历时为所有 live 寄存器延伸区间、修正指令位置索引，避免活跃区间被截断导致错误分配（例如 18_enum 中 5*x 与 1*y 在同一加法处被分配到同一物理寄存器）。

2) **Notes on goal**
   - Aim is to reduce TLEs by cutting excessive spill/reload traffic and stack growth introduced by the previous "spill-all" strategy.
