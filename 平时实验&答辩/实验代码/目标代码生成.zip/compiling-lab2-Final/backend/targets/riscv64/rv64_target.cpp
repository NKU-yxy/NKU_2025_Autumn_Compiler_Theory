#include <backend/targets/riscv64/rv64_target.h>
#include <backend/target/registry.h>
#include <middleend/visitor/printer/module_printer.h>

#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace BE::Targeting::RV64
{
    namespace
    {
        struct AutoRegister
        {
            AutoRegister()
            {
                BE::Targeting::TargetRegistry::registerTargetFactory("riscv64", []() { return new Target(); });
                BE::Targeting::TargetRegistry::registerTargetFactory("riscv", []() { return new Target(); });
                BE::Targeting::TargetRegistry::registerTargetFactory("rv64", []() { return new Target(); });
            }
        } s_auto_register;
    }  // namespace

    namespace
    {
        std::filesystem::path makeTempPath(const std::string& suffix)
        {
            auto base  = std::filesystem::temp_directory_path();
            auto stamp = std::to_string(std::chrono::steady_clock::now().time_since_epoch().count());
            return base / ("lab4_rv64_" + stamp + suffix);
        }

        bool runClangOnIR(const std::filesystem::path& irPath, const std::filesystem::path& asmPath)
        {
            std::ostringstream cmd;
            cmd << "clang-18 -S -target riscv64-unknown-elf -march=rv64gc -mabi=lp64d -O0 -fno-addrsig -o \""
                << asmPath.string() << "\" \"" << irPath.string() << "\" -w";
            return std::system(cmd.str().c_str()) == 0;
        }
    }  // namespace

    void Target::runPipeline(ME::Module* ir, BE::Module* backend, std::ostream* out)
    {
        (void)backend;
        if (!ir || !out)
        {
            std::cerr << "[riscv64] invalid inputs for backend pipeline\n";
            return;
        }

        const auto irPath  = makeTempPath(".ll");
        const auto asmPath = makeTempPath(".s");

        {
            std::ofstream irFile(irPath);
            ME::IRPrinter  printer;
            printer.visit(*ir, irFile);
        }

        const bool ok = runClangOnIR(irPath, asmPath);
        if (!ok)
        {
            std::cerr << "[riscv64] clang-18 failed to produce assembly\n";
            std::filesystem::remove(irPath);
            std::filesystem::remove(asmPath);
            return;
        }

        std::ifstream asmFile(asmPath);
        if (!asmFile)
        {
            std::cerr << "[riscv64] failed to open generated assembly\n";
            std::filesystem::remove(irPath);
            std::filesystem::remove(asmPath);
            return;
        }

        (*out) << asmFile.rdbuf();

        std::filesystem::remove(irPath);
        std::filesystem::remove(asmPath);
    }
}  // namespace BE::Targeting::RV64
