#ifndef __BACKEND_TARGETS_AARCH64_AARCH64_REG_INFO_H__
#define __BACKEND_TARGETS_AARCH64_AARCH64_REG_INFO_H__

#include <backend/target/target_reg_info.h>
#include <backend/targets/aarch64/aarch64_defs.h>
#include <map>

namespace BE::Targeting::AArch64
{
    class RegInfo : public TargetRegInfo
    {
      public:
        RegInfo()
        {
            // AArch64 通用寄存器 ID：x0-x30，sp=31，xzr=32
            for (int i = 0; i <= BE::AArch64::A64_MAX_GPR_ID; ++i) int_regs_.push_back(i);
            int_regs_.push_back(BE::AArch64::A64_REGISTER_ID_XZR);

            // 浮点寄存器 ID：v0-v31
            for (int i = 0; i <= BE::AArch64::A64_MAX_FPR_ID; ++i) float_regs_.push_back(i);

            // 调用约定：前 8 个整数/浮点寄存器作为参数寄存器
            for (int i = 0; i < BE::AArch64::A64_GPR_ARG_COUNT; ++i) int_arg_regs_.push_back(i);
            for (int i = 0; i < BE::AArch64::A64_FPR_ARG_COUNT; ++i) float_arg_regs_.push_back(i);

            // 被调用者保存寄存器
            for (int i = BE::AArch64::A64_CALLEE_INT_FIRST; i <= BE::AArch64::A64_CALLEE_INT_LAST; ++i) callee_saved_int_.push_back(i);
            for (int i = BE::AArch64::A64_CALLEE_FP_FIRST; i <= BE::AArch64::A64_CALLEE_FP_LAST; ++i) callee_saved_float_.push_back(i);

            // 保留寄存器：sp/xzr/lr/x29(frame pointer)；x9/x10/x15 作为框架展开的临时寄存器
            reserved_regs_ = {BE::AArch64::A64_REGISTER_ID_SP, BE::AArch64::A64_REGISTER_ID_XZR, 30, 29, 9, 10, 15};
        }

          int spRegId() const override { return BE::AArch64::A64_REGISTER_ID_SP; }
          int raRegId() const override { return 30; }
          int zeroRegId() const override { return BE::AArch64::A64_REGISTER_ID_XZR; }

        const std::vector<int>& intArgRegs() const override { return int_arg_regs_; }
        const std::vector<int>& floatArgRegs() const override { return float_arg_regs_; }

        const std::vector<int>& calleeSavedIntRegs() const override { return callee_saved_int_; }
        const std::vector<int>& calleeSavedFloatRegs() const override { return callee_saved_float_; }

        const std::vector<int>& reservedRegs() const override { return reserved_regs_; }

        const std::vector<int>& intRegs() const override { return int_regs_; }
        const std::vector<int>& floatRegs() const override { return float_regs_; }

      private:
        std::vector<int> int_regs_;
        std::vector<int> float_regs_;
        std::vector<int> int_arg_regs_;
        std::vector<int> float_arg_regs_;
        std::vector<int> callee_saved_int_;
        std::vector<int> callee_saved_float_;
        std::vector<int> reserved_regs_;
    };
}  // namespace BE::Targeting::AArch64

#endif  // __BACKEND_TARGETS_AARCH64_AARCH64_REG_INFO_H__
