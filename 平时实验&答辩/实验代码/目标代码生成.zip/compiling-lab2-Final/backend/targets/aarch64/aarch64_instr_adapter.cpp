#include <backend/targets/aarch64/aarch64_instr_adapter.h>
#include <backend/targets/aarch64/aarch64_defs.h>
#include <debug.h>

namespace BE::Targeting::AArch64
{
    using namespace BE::AArch64;

    bool InstrAdapter::isCall(BE::MInstruction* inst) const
    {
        auto* ti = dynamic_cast<Instr*>(inst);
        return ti && ti->op == Operator::BL;
    }

    bool InstrAdapter::isReturn(BE::MInstruction* inst) const
    {
        auto* ti = dynamic_cast<Instr*>(inst);
        return ti && ti->op == Operator::RET;
    }

    bool InstrAdapter::isUncondBranch(BE::MInstruction* inst) const
    {
        auto* ti = dynamic_cast<Instr*>(inst);
        return ti && ti->op == Operator::B;
    }

    bool InstrAdapter::isCondBranch(BE::MInstruction* inst) const
    {
        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return false;
        switch (ti->op)
        {
            case Operator::BEQ:
            case Operator::BNE:
            case Operator::BLT:
            case Operator::BLE:
            case Operator::BGT:
            case Operator::BGE: return true;
            default: return false;
        }
    }

    int InstrAdapter::extractBranchTarget(BE::MInstruction* inst) const
    {
        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti || ti->operands.empty()) return -1;
        if (!(isUncondBranch(inst) || isCondBranch(inst))) return -1;

        if (auto* lb = dynamic_cast<LabelOperand*>(ti->operands[0])) return lb->targetBlockId;
        return -1;
    }

    void InstrAdapter::enumUses(BE::MInstruction* inst, std::vector<BE::Register>& out) const
    {
        if (auto* mv = dynamic_cast<BE::MoveInst*>(inst))
        {
            if (auto* src = dynamic_cast<RegOperand*>(mv->src)) out.push_back(src->reg);
            return;
        }

        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return;

        auto addReg = [&](Operand* op) {
            if (auto* r = dynamic_cast<RegOperand*>(op)) out.push_back(r->reg);
            if (auto* m = dynamic_cast<MemOperand*>(op)) out.push_back(m->base);
        };

        switch (ti->op)
        {
            case Operator::CMP:
            case Operator::FCMP:
                addReg(ti->operands[0]);
                addReg(ti->operands[1]);
                break;
            case Operator::LDR:
                addReg(ti->operands[1]);  // base
                break;
            case Operator::STR:
                addReg(ti->operands[0]);  // value
                addReg(ti->operands[1]);  // base
                break;
            case Operator::STP:
                addReg(ti->operands[0]);
                addReg(ti->operands[1]);
                addReg(ti->operands[2]);
                break;
            case Operator::LDP:
                addReg(ti->operands[2]);
                break;
            case Operator::BL:
                // Model arguments (x0-x7, d0-d7) as uses.
                // We don't know exact args, so assume all arg regs are used to prevent DCE.
                for (int i = 0; i <= 7; ++i) out.push_back(BE::Register(i, BE::I64, false));
                for (int i = 0; i < 8; ++i) out.push_back(BE::Register(i, BE::F64, false));
                break;
            case Operator::MOV:
            case Operator::FMOV:
            case Operator::SCVTF:
            case Operator::FCVTZS:
            case Operator::UXTW:
            case Operator::SXTW:
            case Operator::ADD:
            case Operator::SUB:
            case Operator::SDIV:
            case Operator::MUL:
            case Operator::AND:
            case Operator::ORR:
            case Operator::EOR:
            case Operator::LSL:
            case Operator::LSR:
            case Operator::ASR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
                addReg(ti->operands[1]);
                if (ti->operands.size() > 2) addReg(ti->operands[2]);
                break;
            default: break;
        }
    }

    void InstrAdapter::enumDefs(BE::MInstruction* inst, std::vector<BE::Register>& out) const
    {
        if (auto* mv = dynamic_cast<BE::MoveInst*>(inst))
        {
            if (auto* dst = dynamic_cast<RegOperand*>(mv->dest)) out.push_back(dst->reg);
            return;
        }

        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return;

        auto addReg = [&](Operand* op) {
            if (auto* r = dynamic_cast<RegOperand*>(op)) out.push_back(r->reg);
        };

        switch (ti->op)
        {
            case Operator::CMP:
            case Operator::FCMP:
            case Operator::STR:
            case Operator::STP:
            case Operator::B:
            case Operator::BEQ:
            case Operator::BNE:
            case Operator::BLT:
            case Operator::BLE:
            case Operator::BGT:
            case Operator::BGE:
            case Operator::RET: break;
            case Operator::BL:
                // Treat the full caller-saved set as clobbered by calls.
                for (int i = 0; i <= 18; ++i) out.push_back(BE::Register(i, BE::I64, false));
                for (int i = 0; i < 8; ++i) out.push_back(BE::Register(i, BE::F64, false));
                break;
            case Operator::LDR:
                addReg(ti->operands[0]);
                break;
            case Operator::LDP:
                addReg(ti->operands[0]);
                addReg(ti->operands[1]);
                break;
            case Operator::CSET:
            case Operator::MOV:
            case Operator::FMOV:
            case Operator::SCVTF:
            case Operator::FCVTZS:
            case Operator::UXTW:
            case Operator::SXTW:
            case Operator::MOVZ:
            case Operator::MOVN:
            case Operator::MOVK:
            case Operator::ADD:
            case Operator::SUB:
            case Operator::SDIV:
            case Operator::MUL:
            case Operator::AND:
            case Operator::ORR:
            case Operator::EOR:
            case Operator::LSL:
            case Operator::LSR:
            case Operator::ASR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
            case Operator::LA:
                addReg(ti->operands[0]);
                break;
            default: break;
        }
    }

    static void replaceOne(Operand* op, const BE::Register& from, const BE::Register& to)
    {
        if (auto* regOp = dynamic_cast<RegOperand*>(op))
            if (regOp->reg == from) regOp->reg = to;
    }

    // tip: 1.MemOperand 的 base 和 RegOperand 的 reg 都是寄存器，需要分别处理
    //      2.注意不同指令的寄存器使用方式不同，个数也不相同，需要根据指令类型进行处理
    //      3.定义寄存器可能为空集，需要根据指令类型进行处理
    //      4.可以借助replaceOne函数实现
    void InstrAdapter::replaceUse(BE::MInstruction* inst, const BE::Register& from, const BE::Register& to) const
    {
        if (auto* mv = dynamic_cast<BE::MoveInst*>(inst))
        {
            replaceOne(mv->src, from, to);
            return;
        }

        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return;

        auto replaceMemBase = [&](Operand* op) {
            if (auto* mem = dynamic_cast<MemOperand*>(op))
                if (mem->base == from) mem->base = to;
        };

        switch (ti->op)
        {
            case Operator::CMP:
            case Operator::FCMP:
                replaceOne(ti->operands[0], from, to);
                replaceOne(ti->operands[1], from, to);
                break;
            case Operator::LDR:
                replaceMemBase(ti->operands[1]);
                break;
            case Operator::STR:
                replaceOne(ti->operands[0], from, to);
                replaceMemBase(ti->operands[1]);
                break;
            case Operator::STP:
                replaceOne(ti->operands[0], from, to);
                replaceOne(ti->operands[1], from, to);
                replaceMemBase(ti->operands[2]);
                break;
            case Operator::LDP:
                replaceMemBase(ti->operands[2]);
                break;
            case Operator::MOV:
            case Operator::FMOV:
            case Operator::SCVTF:
            case Operator::FCVTZS:
            case Operator::UXTW:
            case Operator::SXTW:
            case Operator::ADD:
            case Operator::SUB:
            case Operator::SDIV:
            case Operator::MUL:
            case Operator::AND:
            case Operator::ORR:
            case Operator::EOR:
            case Operator::LSL:
            case Operator::LSR:
            case Operator::ASR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
                replaceOne(ti->operands[1], from, to);
                if (ti->operands.size() > 2) replaceOne(ti->operands[2], from, to);
                break;
            default: break;
        }
    }

    void InstrAdapter::replaceDef(BE::MInstruction* inst, const BE::Register& from, const BE::Register& to) const
    {
        if (auto* mv = dynamic_cast<BE::MoveInst*>(inst))
        {
            replaceOne(mv->dest, from, to);
            return;
        }

        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return;

        switch (ti->op)
        {
            case Operator::LDR:
            case Operator::MOV:
            case Operator::FMOV:
            case Operator::SCVTF:
            case Operator::FCVTZS:
            case Operator::UXTW:
            case Operator::SXTW:
            case Operator::MOVZ:
            case Operator::MOVN:
            case Operator::MOVK:
            case Operator::ADD:
            case Operator::SUB:
            case Operator::SDIV:
            case Operator::MUL:
            case Operator::AND:
            case Operator::ORR:
            case Operator::EOR:
            case Operator::LSL:
            case Operator::LSR:
            case Operator::ASR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
            case Operator::CSET:
            case Operator::LA:
                replaceOne(ti->operands[0], from, to);
                break;
            case Operator::LDP:
                replaceOne(ti->operands[0], from, to);
                replaceOne(ti->operands[1], from, to);
                break;
            default: break;
        }
    }

    void InstrAdapter::enumPhysRegs(BE::MInstruction* inst, std::vector<BE::Register>& out) const
    {
        auto collect = [&](Operand* op) {
            if (auto* r = dynamic_cast<RegOperand*>(op))
            {
                if (!r->reg.isVreg) out.push_back(r->reg);
            }
            else if (auto* m = dynamic_cast<MemOperand*>(op))
            {
                if (!m->base.isVreg) out.push_back(m->base);
            }
        };

        if (auto* mv = dynamic_cast<BE::MoveInst*>(inst))
        {
            collect(mv->src);
            collect(mv->dest);
            return;
        }

        auto* ti = dynamic_cast<Instr*>(inst);
        if (!ti) return;
        for (auto* op : ti->operands) collect(op);
    }

    void InstrAdapter::insertReloadBefore(
        BE::Block* block, std::deque<BE::MInstruction*>::iterator it, const BE::Register& physReg, int frameIndex) const
    {
        auto* load = new BE::FILoadInst(physReg, frameIndex);
        block->insts.insert(it, load);
    }

    void InstrAdapter::insertSpillAfter(
        BE::Block* block, std::deque<BE::MInstruction*>::iterator it, const BE::Register& physReg, int frameIndex) const
    {
        auto next = it;
        ++next;
        auto* store = new BE::FIStoreInst(physReg, frameIndex);
        block->insts.insert(next, store);
    }
}  // namespace BE::Targeting::AArch64
