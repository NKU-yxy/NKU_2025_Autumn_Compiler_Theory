#include <backend/targets/aarch64/isel/aarch64_ir_isel.h>
#include <backend/targets/aarch64/aarch64_defs.h>
#include <backend/target/target_instr_adapter.h>
#include <deque>
#include <cstdint>
#include <cstring>
#include <set>

namespace BE::AArch64
{
    namespace
    {
        static BE::DataType* toBEType(ME::DataType dt)
        {
            switch (dt)
            {
                case ME::DataType::I32: return BE::I32;
                case ME::DataType::I64: return BE::I64;
                case ME::DataType::F32: return BE::F32;
                case ME::DataType::DOUBLE: return BE::F64;
                case ME::DataType::PTR: return BE::PTR;
                default: return BE::I64;
            }
        }

        static int typeSize(ME::DataType dt)
        {
            switch (dt)
            {
                case ME::DataType::I32:
                case ME::DataType::F32: return 4;
                case ME::DataType::I64:
                case ME::DataType::DOUBLE:
                case ME::DataType::PTR: return 8;
                default: return 8;
            }
        }

        static BE::Register ensureVReg(std::map<size_t, BE::Register>& reg_map, size_t id, BE::DataType* dt)
        {
            auto it = reg_map.find(id);
            if (it != reg_map.end()) return it->second;
            auto vr        = getVReg(dt);
            reg_map[id] = vr;
            return vr;
        }

        static AddrInfo resolveAddr(const std::map<size_t, AddrInfo>& addr_map, ME::Operand* op)
        {
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op))
            {
                auto it = addr_map.find(ro->regNum);
                if (it != addr_map.end()) return it->second;
            }
            if (auto* go = dynamic_cast<ME::GlobalOperand*>(op))
            {
                AddrInfo info;
                info.kind       = AddrInfo::Kind::Global;
                info.globalName = go->name;
                return info;
            }
            return AddrInfo{};
        }

        static bool isFloatType(BE::DataType* dt) { return dt == BE::F32 || dt == BE::F64; }
        static bool is64BitType(BE::DataType* dt) { return dt == BE::I64 || dt == BE::PTR || dt == BE::F64; }

        static bool fitsAddSubImm(int value) { return BE::AArch64::fitsUnsignedImm12(value); }

        static bool fitsShiftImm(int value, BE::DataType* dt)
        {
            if (value < 0) return false;
            int maxShift = is64BitType(dt) ? 63 : 31;
            return value <= maxShift;
        }

        static void emitLoadImm(BE::Block* block, const BE::Register& dst, int imm)
        {
            uint64_t u = 0;
            int      maxShift = 48;
            if (is64BitType(dst.dt))
            {
                u = static_cast<uint64_t>(static_cast<int64_t>(imm));
                maxShift = 48;
            }
            else
            {
                u = static_cast<uint32_t>(imm);
                maxShift = 16;
            }

            int      firstShift = -1;
            uint16_t firstChunk = 0;
            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk != 0 && firstShift == -1)
                {
                    firstShift = shift;
                    firstChunk = chunk;
                }
            }
            if (firstShift == -1)
            {
                firstShift = 0;
                firstChunk = 0;
            }

            auto* movz = BE::AArch64::createInstr3(
                BE::AArch64::Operator::MOVZ,
                new BE::RegOperand(dst),
                new BE::AArch64::ImmeOperand(firstChunk),
                new BE::AArch64::ImmeOperand(firstShift));
            block->insts.push_back(movz);

            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                if (shift == firstShift) continue;
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk == 0) continue;
                auto* movk = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::MOVK,
                    new BE::RegOperand(dst),
                    new BE::AArch64::ImmeOperand(chunk),
                    new BE::AArch64::ImmeOperand(shift));
                block->insts.push_back(movk);
            }
        }

        static void emitLoadImmAt(
            BE::Block* block,
            std::deque<BE::MInstruction*>::iterator& it,
            const BE::Register& dst,
            int imm)
        {
            uint64_t u = 0;
            int      maxShift = 48;
            if (is64BitType(dst.dt))
            {
                u = static_cast<uint64_t>(static_cast<int64_t>(imm));
                maxShift = 48;
            }
            else
            {
                u = static_cast<uint32_t>(imm);
                maxShift = 16;
            }

            int      firstShift = -1;
            uint16_t firstChunk = 0;
            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk != 0 && firstShift == -1)
                {
                    firstShift = shift;
                    firstChunk = chunk;
                }
            }
            if (firstShift == -1)
            {
                firstShift = 0;
                firstChunk = 0;
            }

            auto* movz = BE::AArch64::createInstr3(
                BE::AArch64::Operator::MOVZ,
                new BE::RegOperand(dst),
                new BE::AArch64::ImmeOperand(firstChunk),
                new BE::AArch64::ImmeOperand(firstShift));
            it = block->insts.insert(it, movz);
            ++it;

            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                if (shift == firstShift) continue;
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk == 0) continue;
                auto* movk = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::MOVK,
                    new BE::RegOperand(dst),
                    new BE::AArch64::ImmeOperand(chunk),
                    new BE::AArch64::ImmeOperand(shift));
                it = block->insts.insert(it, movk);
                ++it;
            }
        }

        static void appendLoadImm(
            std::vector<BE::MInstruction*>& out,
            const BE::Register& dst,
            int imm)
        {
            uint64_t u = 0;
            int      maxShift = 48;
            if (is64BitType(dst.dt))
            {
                u = static_cast<uint64_t>(static_cast<int64_t>(imm));
                maxShift = 48;
            }
            else
            {
                u = static_cast<uint32_t>(imm);
                maxShift = 16;
            }

            int      firstShift = -1;
            uint16_t firstChunk = 0;
            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk != 0 && firstShift == -1)
                {
                    firstShift = shift;
                    firstChunk = chunk;
                }
            }
            if (firstShift == -1)
            {
                firstShift = 0;
                firstChunk = 0;
            }

            auto* movz = BE::AArch64::createInstr3(
                BE::AArch64::Operator::MOVZ,
                new BE::RegOperand(dst),
                new BE::AArch64::ImmeOperand(firstChunk),
                new BE::AArch64::ImmeOperand(firstShift));
            out.push_back(movz);

            for (int shift = 0; shift <= maxShift; shift += 16)
            {
                if (shift == firstShift) continue;
                uint16_t chunk = static_cast<uint16_t>((u >> shift) & 0xFFFF);
                if (chunk == 0) continue;
                auto* movk = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::MOVK,
                    new BE::RegOperand(dst),
                    new BE::AArch64::ImmeOperand(chunk),
                    new BE::AArch64::ImmeOperand(shift));
                out.push_back(movk);
            }
        }
    }  // namespace

    void IRIsel::runImpl() { apply(*this, *ir_module_); }

    BE::Register IRIsel::materializeF32(float value, BE::Block* block, std::vector<BE::MInstruction*>* buffer)
    {
        auto dst    = getVReg(BE::F32);
        auto intReg = getVReg(BE::I32);
        uint32_t bits;
        std::memcpy(&bits, &value, sizeof(uint32_t));

        if (buffer)
        {
            appendLoadImm(*buffer, intReg, static_cast<int32_t>(bits));
            auto mov = BE::AArch64::createInstr2(
                BE::AArch64::Operator::FMOV, new BE::RegOperand(dst), new BE::RegOperand(intReg));
            buffer->push_back(mov);
        }
        else
        {
            BE::Block* targetBlock = block ? block : cur_block_;
            if (!targetBlock) targetBlock = cur_block_;
            emitLoadImm(targetBlock, intReg, static_cast<int32_t>(bits));
            auto mov = BE::AArch64::createInstr2(
                BE::AArch64::Operator::FMOV, new BE::RegOperand(dst), new BE::RegOperand(intReg));
            targetBlock->insts.push_back(mov);
        }

        return dst;
    }

    BE::Register IRIsel::ensureIntType(BE::Register reg, BE::DataType* target,
        BE::Block* insertBlock,
        std::deque<BE::MInstruction*>::iterator* insertPos)
    {
        if (!target || reg.dt == target) return reg;

        auto isIntLike = [](BE::DataType* dt) {
            return dt == BE::I32 || dt == BE::I64 || dt == BE::PTR;
        };
        if (!isIntLike(reg.dt) || !isIntLike(target)) return reg;

        BE::Block* block = insertBlock ? insertBlock : cur_block_;
        if (!block) return reg;

        auto dst = getVReg(target);
        auto mv  = BE::AArch64::createMove(new BE::RegOperand(dst), new BE::RegOperand(reg));
        if (insertPos)
            block->insts.insert(*insertPos, mv);
        else
            block->insts.push_back(mv);
        return dst;
    }

    void IRIsel::visit(ME::Module& module)
    {
        for (auto* gv : module.globalVars)
        {
            if (!gv) continue;
            auto* beGV = new BE::GlobalVariable(toBEType(gv->dt), gv->name);
            // 优先使用 VarAttr 里的初始化列表；若缺失则从 init 操作数回退
            for (auto v : gv->initList.initList) beGV->initVals.push_back(v.getInt());
            if (beGV->initVals.empty() && gv->init)
            {
                if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(gv->init))
                    beGV->initVals.push_back(imm->value);
                else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(gv->init))
                    beGV->initVals.push_back(static_cast<int>(immf->value));
            }
            for (auto d : gv->initList.arrayDims) beGV->dims.push_back(d);
            m_backend_module->globals.push_back(beGV);
        }

        for (auto* func : module.functions)
        {
            if (!func || !func->funcDef) continue;
            cur_func_ = new BE::Function(func->funcDef->funcName);
            m_backend_module->functions.push_back(cur_func_);
            reg_map_.clear();
            addr_map_.clear();
            apply(*this, *func);
        }
    }

    void IRIsel::visit(ME::Function& func)
    {
        if (!cur_func_) return;

        // 参数映射
        size_t intArgIdx = 0;
        size_t floatArgIdx = 0;
        size_t stackArgIdx = 0;
        for (auto& [dt, op] : func.funcDef->argRegs)
        {
            auto beType       = toBEType(dt);
            BE::Register vreg = ensureVReg(reg_map_, op->getRegNum(), beType);
            cur_func_->params.push_back(vreg);

            auto recordAddrReg = [&](size_t regId, const BE::Register& reg) {
                AddrInfo info;
                info.kind   = AddrInfo::Kind::Reg;
                info.reg    = reg;
                info.offset = 0;
                addr_map_[regId] = info;
            };

            if (isFloatType(beType))
            {
                if (floatArgIdx < AArch64::A64_FPR_ARG_COUNT)
                {
                    BE::Register phys(static_cast<int>(floatArgIdx), beType, false);
                    auto mv = BE::AArch64::createMove(new BE::RegOperand(vreg), new BE::RegOperand(phys));
                    cur_func_->allocInsts.push_back(mv);
                    ++floatArgIdx;
                }
                else
                {
                    int offset = static_cast<int>(16 + stackArgIdx * 8);
                    auto* mem = new BE::AArch64::MemOperand(BE::AArch64::PR::x29, offset);
                    auto* ldr = BE::AArch64::createInstr2(
                        BE::AArch64::Operator::LDR, new BE::RegOperand(vreg), mem);
                    cur_func_->allocInsts.push_back(ldr);
                    ++stackArgIdx;
                }
            }
            else
            {
                if (dt == ME::DataType::PTR) recordAddrReg(op->getRegNum(), vreg);

                if (intArgIdx < AArch64::A64_GPR_ARG_COUNT)
                {
                    BE::Register phys(static_cast<int>(intArgIdx), beType, false);
                    auto mv = BE::AArch64::createMove(new BE::RegOperand(vreg), new BE::RegOperand(phys));
                    cur_func_->allocInsts.push_back(mv);
                    ++intArgIdx;
                }
                else
                {
                    int offset = static_cast<int>(16 + stackArgIdx * 8);
                    auto* mem = new BE::AArch64::MemOperand(BE::AArch64::PR::x29, offset);
                    auto* ldr = BE::AArch64::createInstr2(
                        BE::AArch64::Operator::LDR, new BE::RegOperand(vreg), mem);
                    cur_func_->allocInsts.push_back(ldr);
                    ++stackArgIdx;
                }
            }
        }

        // 基本块创建
        for (auto& [bid, _] : func.blocks) cur_func_->blocks[bid] = new BE::Block(static_cast<uint32_t>(bid));

        if (!cur_func_->blocks.empty())
        {
            auto* entryBlock = cur_func_->blocks.begin()->second;
            for (auto* inst : cur_func_->allocInsts) entryBlock->insts.push_back(inst);
        }

        // 指令遍历：先处理非 Phi，再统一处理 Phi，确保前驱基本块已生成完毕
        struct PhiRecord
        {
            ME::PhiInst* phi = nullptr;
            uint32_t     blockId = 0;
        };
        std::vector<PhiRecord> phiList;
        for (auto& [bid, irBlock] : func.blocks)
        {
            cur_block_ = cur_func_->blocks[bid];
            for (auto* inst : irBlock->insts)
            {
                if (!inst) continue;
                if (auto* phi = dynamic_cast<ME::PhiInst*>(inst))
                {
                    phiList.push_back(PhiRecord{phi, static_cast<uint32_t>(bid)});
                    continue;
                }
                apply(*this, *inst);
            }
        }

        struct PhiCopy
        {
            BE::Register  dst;
            ME::Operand*  srcOp;
            BE::DataType* dt;
        };

        struct EdgeKey
        {
            uint32_t pred = 0;
            uint32_t succ = 0;
            bool operator<(const EdgeKey& other) const
            {
                if (pred != other.pred) return pred < other.pred;
                return succ < other.succ;
            }
        };

        std::map<EdgeKey, std::vector<PhiCopy>> copiesPerEdge;
        for (const auto& rec : phiList)
        {
            auto dest = ensureVReg(reg_map_, rec.phi->res->getRegNum(), toBEType(rec.phi->dt));
            for (auto& [labelOp, val] : rec.phi->incomingVals)
            {
                auto* label = dynamic_cast<ME::LabelOperand*>(labelOp);
                if (!label) continue;
                copiesPerEdge[EdgeKey{static_cast<uint32_t>(label->lnum), rec.blockId}]
                    .push_back(PhiCopy{dest, val, toBEType(rec.phi->dt)});
            }
        }

        auto* adapter = BE::Targeting::g_adapter;
        auto collectSuccs = [&](BE::Block* block) {
            std::set<uint32_t> succs;
            if (!block || !adapter) return succs;
            for (auto* inst : block->insts)
            {
                if (!(adapter->isUncondBranch(inst) || adapter->isCondBranch(inst))) continue;
                int tgt = adapter->extractBranchTarget(inst);
                if (tgt >= 0) succs.insert(static_cast<uint32_t>(tgt));
            }
            return succs;
        };

        auto updateBranchTarget = [&](BE::Block* block, uint32_t from, uint32_t to) {
            if (!block || !adapter) return;
            for (auto it = block->insts.rbegin(); it != block->insts.rend(); ++it)
            {
                auto* inst = *it;
                if (!(adapter->isUncondBranch(inst) || adapter->isCondBranch(inst))) continue;
                auto* ti = dynamic_cast<BE::AArch64::Instr*>(inst);
                if (!ti || ti->operands.empty()) continue;
                if (auto* lb = dynamic_cast<BE::AArch64::LabelOperand*>(ti->operands[0]))
                {
                    if (lb->targetBlockId == static_cast<int>(from))
                    {
                        lb->targetBlockId = static_cast<int>(to);
                        return;
                    }
                }
            }
        };

        uint32_t nextBlockId = 0;
        for (auto& [bid, _] : cur_func_->blocks) nextBlockId = std::max(nextBlockId, static_cast<uint32_t>(bid));
        ++nextBlockId;

        std::map<EdgeKey, uint32_t> edgeSplitBlock;
        for (auto& [edge, copies] : copiesPerEdge)
        {
            BE::Block* predBlock = cur_func_->blocks[edge.pred];
            auto succs = collectSuccs(predBlock);
            const bool needSplit = succs.size() > 1;

            BE::Block* insertBlock = predBlock;
            if (needSplit)
            {
                auto it = edgeSplitBlock.find(edge);
                if (it == edgeSplitBlock.end())
                {
                    uint32_t splitId = nextBlockId++;
                    auto* splitBlock = new BE::Block(splitId);
                    cur_func_->blocks[splitId] = splitBlock;
                    edgeSplitBlock[edge] = splitId;

                    updateBranchTarget(predBlock, edge.succ, splitId);

                    auto* b = BE::AArch64::createInstr1(
                        BE::AArch64::Operator::B, new BE::AArch64::LabelOperand(static_cast<int>(edge.succ)));
                    splitBlock->insts.push_back(b);
                }
                insertBlock = cur_func_->blocks[edgeSplitBlock[edge]];
            }

            auto insertIt = insertBlock->insts.end();
            if (!insertBlock->insts.empty())
            {
                auto* back = insertBlock->insts.back();
                if (adapter && (adapter->isUncondBranch(back) || adapter->isCondBranch(back) || adapter->isReturn(back)))
                    insertIt = std::prev(insertBlock->insts.end());
            }

            std::vector<BE::MInstruction*> newInsts;

            auto ensurePhiType = [&](BE::Register reg, BE::DataType* dt) -> BE::Register {
                if (!dt || reg.dt == dt) return reg;
                auto isIntLike = [&](BE::DataType* t) {
                    return t == BE::I32 || t == BE::I64 || t == BE::PTR;
                };
                if (!isIntLike(reg.dt) || !isIntLike(dt)) return reg;
                auto widened = getVReg(dt);
                auto mv      = BE::AArch64::createMove(new BE::RegOperand(widened), new BE::RegOperand(reg));
                newInsts.push_back(mv);
                return widened;
            };

            auto materialize = [&](ME::Operand* op, BE::DataType* dt) -> BE::Register {
                if (auto* ro = dynamic_cast<ME::RegOperand*>(op))
                {
                    auto reg = ensureVReg(reg_map_, ro->regNum, dt);
                    return ensurePhiType(reg, dt);
                }
                if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
                {
                    auto v = getVReg(dt);
                    appendLoadImm(newInsts, v, imm->value);
                    return v;
                }
                if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(op))
                {
                    std::vector<BE::MInstruction*> seq;
                    auto v = materializeF32(immf->value, insertBlock, &seq);
                    newInsts.insert(newInsts.end(), seq.begin(), seq.end());
                    return v;
                }
                if (auto* go = dynamic_cast<ME::GlobalOperand*>(op))
                {
                    auto v  = getVReg(BE::PTR);
                    auto la = BE::AArch64::createInstr2(
                        BE::AArch64::Operator::LA, new BE::RegOperand(v), new BE::AArch64::SymbolOperand(go->name));
                    newInsts.push_back(la);
                    return v;
                }
                return getVReg(dt);
            };

            std::map<BE::Register, BE::Register> pending;
            for (auto& cp : copies)
            {
                auto srcReg = materialize(cp.srcOp, cp.dt);
                srcReg      = ensurePhiType(srcReg, cp.dt);
                if (cp.dst == srcReg) continue;
                pending[cp.dst] = srcReg;
            }

            auto rebuildUseSet = [&](const std::map<BE::Register, BE::Register>& m) {
                std::set<BE::Register> s;
                for (auto& [_, src] : m) s.insert(src);
                return s;
            };

            auto emitMove = [&](const BE::Register& dst, const BE::Register& src) {
                auto mv = BE::AArch64::createMove(new BE::RegOperand(dst), new BE::RegOperand(src));
                newInsts.push_back(mv);
            };

            auto useSet = rebuildUseSet(pending);
            while (!pending.empty())
            {
                bool progress = false;
                for (auto it = pending.begin(); it != pending.end(); ++it)
                {
                    if (useSet.find(it->first) != useSet.end()) continue;
                    emitMove(it->first, it->second);
                    pending.erase(it);
                    useSet = rebuildUseSet(pending);
                    progress = true;
                    break;
                }
                if (progress) continue;

                auto it = pending.begin();
                BE::Register startDst = it->first;
                BE::Register startSrc = it->second;
                pending.erase(it);

                auto temp = getVReg(startDst.dt);
                emitMove(temp, startDst);

                BE::Register curDst = startDst;
                BE::Register curSrc = startSrc;

                while (!(curSrc == startDst))
                {
                    emitMove(curDst, curSrc);
                    auto nextIt = pending.find(curSrc);
                    if (nextIt == pending.end()) break;
                    curDst = nextIt->first;
                    curSrc = nextIt->second;
                    pending.erase(nextIt);
                }

                emitMove(curDst, temp);
                useSet = rebuildUseSet(pending);
            }

            insertBlock->insts.insert(insertIt, newInsts.begin(), newInsts.end());
        }
    }

    void IRIsel::visit(ME::Block& block) { (void)block; }

    void IRIsel::visit(ME::LoadInst& inst)
    {
        auto* beType = toBEType(inst.dt);
        auto  dest   = ensureVReg(reg_map_, inst.res->getRegNum(), beType);

        auto info = resolveAddr(addr_map_, inst.ptr);
        auto emitLoadFrom = [&](const BE::Register& base, int offset, BE::FrameIndexOperand* fiop) {
            auto* mem  = new BE::AArch64::MemOperand(base, offset);
            auto* ldr  = BE::AArch64::createInstr2(BE::AArch64::Operator::LDR, new BE::RegOperand(dest), mem);
            ldr->fiop  = fiop;
            cur_block_->insts.push_back(ldr);
        };

        switch (info.kind)
        {
            case AddrInfo::Kind::Frame:
                emitLoadFrom(BE::AArch64::PR::sp, info.offset, new BE::FrameIndexOperand(info.frameIndex));
                break;
            case AddrInfo::Kind::Global:
            {
                auto tmp = getVReg(BE::PTR);
                auto la  = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(tmp), new BE::AArch64::SymbolOperand(info.globalName));
                cur_block_->insts.push_back(la);
                emitLoadFrom(tmp, info.offset, nullptr);
                break;
            }
            case AddrInfo::Kind::Reg:
                emitLoadFrom(info.reg, info.offset, nullptr);
                break;
            default:
            {
                BE::Register base;
                if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.ptr))
                    base = ensureVReg(reg_map_, ro->regNum, BE::PTR);
                else
                    base = getVReg(BE::PTR);
                emitLoadFrom(base, 0, nullptr);
                break;
            }
        }

        if (beType == BE::PTR)
        {
            AddrInfo info;
            info.kind   = AddrInfo::Kind::Reg;
            info.reg    = dest;
            info.offset = 0;
            addr_map_[inst.res->getRegNum()] = info;
        }
    }

    void IRIsel::visit(ME::StoreInst& inst)
    {
        auto* beType = toBEType(inst.dt);

        auto materialize = [&](ME::Operand* op) {
            BE::Register reg;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op)) reg = ensureVReg(reg_map_, ro->regNum, beType);
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
            {
                reg = getVReg(beType);
                emitLoadImm(cur_block_, reg, imm->value);
            }
            else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(op))
            {
                reg = materializeF32(immf->value);
            }
            else if (auto* go = dynamic_cast<ME::GlobalOperand*>(op))
            {
                reg = getVReg(BE::PTR);
                auto m = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(reg), new BE::AArch64::SymbolOperand(go->name));
                cur_block_->insts.push_back(m);
            }
            else reg = getVReg(beType);
            return ensureIntType(reg, beType);
        };

        auto valReg = materialize(inst.val);
        auto info   = resolveAddr(addr_map_, inst.ptr);
        auto emitStoreTo = [&](const BE::Register& base, int offset, BE::FrameIndexOperand* fiop) {
            auto* mem  = new BE::AArch64::MemOperand(base, offset);
            auto* str  = BE::AArch64::createInstr2(
                BE::AArch64::Operator::STR, new BE::RegOperand(valReg), mem);
            str->fiop  = fiop;
            cur_block_->insts.push_back(str);
        };

        switch (info.kind)
        {
            case AddrInfo::Kind::Frame:
                emitStoreTo(BE::AArch64::PR::sp, info.offset, new BE::FrameIndexOperand(info.frameIndex));
                break;
            case AddrInfo::Kind::Global:
            {
                auto tmp = getVReg(BE::PTR);
                auto la  = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(tmp), new BE::AArch64::SymbolOperand(info.globalName));
                cur_block_->insts.push_back(la);
                emitStoreTo(tmp, info.offset, nullptr);
                break;
            }
            case AddrInfo::Kind::Reg:
                emitStoreTo(info.reg, info.offset, nullptr);
                break;
            default:
            {
                BE::Register base;
                if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.ptr))
                    base = ensureVReg(reg_map_, ro->regNum, BE::PTR);
                else
                    base = getVReg(BE::PTR);
                emitStoreTo(base, 0, nullptr);
                break;
            }
        }
    }

    void IRIsel::visit(ME::ArithmeticInst& inst)
    {
        auto* beType = toBEType(inst.dt);
        auto  dst    = ensureVReg(reg_map_, inst.res->getRegNum(), beType);

        auto materializeAsReg = [&](ME::Operand* op) -> BE::Register {
            BE::Register reg;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op)) reg = ensureVReg(reg_map_, ro->regNum, beType);
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
            {
                reg = getVReg(beType);
                emitLoadImm(cur_block_, reg, imm->value);
            }
            else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(op))
            {
                reg = materializeF32(immf->value);
            }
            else reg = getVReg(beType);
            return ensureIntType(reg, beType);
        };

        auto materializeAsOp = [&](ME::Operand* op, bool allowImm, bool immFits) -> BE::Operand* {
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op)) return new BE::RegOperand(ensureVReg(reg_map_, ro->regNum, beType));
            if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
            {
                if (allowImm && immFits) return new BE::AArch64::ImmeOperand(imm->value);
                auto v = getVReg(beType);
                emitLoadImm(cur_block_, v, imm->value);
                return new BE::RegOperand(v);
            }
            // Float immediate as operand is not supported in most instructions (except FMOV)
            // So we must materialize it as reg.
            return nullptr;
        };

        BE::AArch64::Operator op = BE::AArch64::Operator::ADD;
        bool allowImm = false;

        switch (inst.opcode)
        {
            case ME::Operator::ADD: op = BE::AArch64::Operator::ADD; allowImm = true; break;
            case ME::Operator::SUB: op = BE::AArch64::Operator::SUB; allowImm = true; break;
            case ME::Operator::MUL: op = BE::AArch64::Operator::MUL; allowImm = false; break;
            case ME::Operator::DIV: op = BE::AArch64::Operator::SDIV; allowImm = false; break;
            case ME::Operator::MOD:
            {
                auto lhs = materializeAsReg(inst.lhs);
                auto rhs = materializeAsReg(inst.rhs);
                auto q   = getVReg(beType);
                auto tmp = getVReg(beType);
                auto* div = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::SDIV, new BE::RegOperand(q), new BE::RegOperand(lhs), new BE::RegOperand(rhs));
                cur_block_->insts.push_back(div);
                auto* mul = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::MUL, new BE::RegOperand(tmp), new BE::RegOperand(q), new BE::RegOperand(rhs));
                cur_block_->insts.push_back(mul);
                auto* sub = BE::AArch64::createInstr3(
                    BE::AArch64::Operator::SUB, new BE::RegOperand(dst), new BE::RegOperand(lhs), new BE::RegOperand(tmp));
                cur_block_->insts.push_back(sub);
                return;
            }
            case ME::Operator::FADD: op = BE::AArch64::Operator::FADD; allowImm = false; break;
            case ME::Operator::FSUB: op = BE::AArch64::Operator::FSUB; allowImm = false; break;
            case ME::Operator::FMUL: op = BE::AArch64::Operator::FMUL; allowImm = false; break;
            case ME::Operator::FDIV: op = BE::AArch64::Operator::FDIV; allowImm = false; break;
            case ME::Operator::BITOR: op = BE::AArch64::Operator::ORR; allowImm = false; break;
            case ME::Operator::BITXOR: op = BE::AArch64::Operator::EOR; allowImm = false; break;
            case ME::Operator::BITAND: op = BE::AArch64::Operator::AND; allowImm = false; break;
            case ME::Operator::SHL: op = BE::AArch64::Operator::LSL; allowImm = true; break;
            case ME::Operator::ASHR: op = BE::AArch64::Operator::ASR; allowImm = true; break;
            case ME::Operator::LSHR: op = BE::AArch64::Operator::LSR; allowImm = true; break;
            default: op = BE::AArch64::Operator::ADD; allowImm = true; break;
        }

        bool immFits = false;
        if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(inst.rhs))
        {
            if (op == BE::AArch64::Operator::ADD || op == BE::AArch64::Operator::SUB)
                immFits = fitsAddSubImm(imm->value);
            else if (op == BE::AArch64::Operator::LSL || op == BE::AArch64::Operator::LSR || op == BE::AArch64::Operator::ASR)
                immFits = fitsShiftImm(imm->value, beType);
        }

        auto* lhs = new BE::RegOperand(materializeAsReg(inst.lhs));
        auto* rhs = allowImm ? materializeAsOp(inst.rhs, true, immFits) : new BE::RegOperand(materializeAsReg(inst.rhs));

        auto* inst3 = BE::AArch64::createInstr3(op, new BE::RegOperand(dst), lhs, rhs);
        cur_block_->insts.push_back(inst3);
    }

    void IRIsel::visit(ME::IcmpInst& inst)
    {
        auto dst = ensureVReg(reg_map_, inst.res->getRegNum(), BE::I32);

        auto materializeLHS = [&](ME::Operand* op) -> BE::Register {
            BE::Register reg;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op)) reg = ensureVReg(reg_map_, ro->regNum, BE::I32);
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
            {
                reg = getVReg(BE::I32);
                emitLoadImm(cur_block_, reg, imm->value);
            }
            else reg = getVReg(BE::I32);
            return ensureIntType(reg, BE::I32);
        };

        auto lhs   = materializeLHS(inst.lhs);
        auto rhsOp = [&]() -> BE::Operand* {
            if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.rhs))
                return new BE::RegOperand(ensureIntType(ensureVReg(reg_map_, ro->regNum, BE::I32), BE::I32));
            if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(inst.rhs))
            {
                if (fitsAddSubImm(imm->value)) return new BE::AArch64::ImmeOperand(imm->value);
                auto v = getVReg(BE::I32);
                emitLoadImm(cur_block_, v, imm->value);
                return new BE::RegOperand(v);
            }
            return new BE::RegOperand(lhs);
        }();

        auto* cmp = BE::AArch64::createInstr2(BE::AArch64::Operator::CMP, new BE::RegOperand(lhs), rhsOp);
        cur_block_->insts.push_back(cmp);

        int cond = 0;
        switch (inst.cond)
        {
            case ME::ICmpOp::EQ: cond = 0; break;
            case ME::ICmpOp::NE: cond = 1; break;
            case ME::ICmpOp::UGE: cond = 2; break;
            case ME::ICmpOp::ULT: cond = 3; break;
            case ME::ICmpOp::UGT: cond = 8; break;
            case ME::ICmpOp::ULE: cond = 9; break;
            case ME::ICmpOp::SLT: cond = 11; break;
            case ME::ICmpOp::SLE: cond = 13; break;
            case ME::ICmpOp::SGT: cond = 12; break;
            case ME::ICmpOp::SGE: cond = 10; break;
            default: cond = 0; break;
        }
        auto* cset = BE::AArch64::createInstr2(
            BE::AArch64::Operator::CSET, new BE::RegOperand(dst), new BE::AArch64::ImmeOperand(cond));
        cur_block_->insts.push_back(cset);
    }

    void IRIsel::visit(ME::FcmpInst& inst)
    {
        auto* beType = toBEType(inst.dt);
        auto  dst    = ensureVReg(reg_map_, inst.res->getRegNum(), BE::I32);

        auto materialize = [&](ME::Operand* op) -> BE::Register {
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op))
                return ensureVReg(reg_map_, ro->regNum, beType);
            if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(op))
                return materializeF32(immf->value);
            if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
                return materializeF32(static_cast<float>(imm->value));
            return materializeF32(0.0f);
        };

        auto lhs = materialize(inst.lhs);
        auto rhs = materialize(inst.rhs);

        auto* cmp = BE::AArch64::createInstr2(
            BE::AArch64::Operator::FCMP, new BE::RegOperand(lhs), new BE::RegOperand(rhs));
        cur_block_->insts.push_back(cmp);

        int cond = 0;
        switch (inst.cond)
        {
            case ME::FCmpOp::OEQ: cond = 0; break;
            case ME::FCmpOp::ONE: cond = 1; break;
            case ME::FCmpOp::OLT: cond = 11; break;
            case ME::FCmpOp::OLE: cond = 13; break;
            case ME::FCmpOp::OGT: cond = 12; break;
            case ME::FCmpOp::OGE: cond = 10; break;
            default: cond = 0; break;
        }
        auto* cset = BE::AArch64::createInstr2(
            BE::AArch64::Operator::CSET, new BE::RegOperand(dst), new BE::AArch64::ImmeOperand(cond));
        cur_block_->insts.push_back(cset);
    }

    void IRIsel::visit(ME::AllocaInst& inst)
    {
        int bytes = typeSize(inst.dt);
        int elems = 1;
        for (auto d : inst.dims) elems *= d;
        bytes *= elems;

        size_t rid = inst.res->getRegNum();
        cur_func_->frameInfo.createLocalObject(rid, bytes, 16);

        auto ptrReg = ensureVReg(reg_map_, rid, BE::PTR);
        auto add    = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
               new BE::RegOperand(ptrReg),
               new BE::RegOperand(BE::AArch64::PR::sp),
               new BE::AArch64::ImmeOperand(0));
        add->fiop = new BE::FrameIndexOperand(static_cast<int>(rid));
        cur_block_->insts.push_back(add);

        AddrInfo info;
        info.kind       = AddrInfo::Kind::Frame;
        info.frameIndex = static_cast<int>(rid);
        info.offset     = 0;
        info.reg        = ptrReg;
        addr_map_[rid]  = info;
    }

    void IRIsel::visit(ME::BrCondInst& inst)
    {
        auto condReg = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.cond)->regNum, BE::I64);
        auto* cmp    = BE::AArch64::createInstr2(
            BE::AArch64::Operator::CMP, new BE::RegOperand(condReg), new BE::AArch64::ImmeOperand(0));
        cur_block_->insts.push_back(cmp);

        auto* tLabel = dynamic_cast<ME::LabelOperand*>(inst.trueTar);
        auto* fLabel = dynamic_cast<ME::LabelOperand*>(inst.falseTar);

        if (tLabel)
        {
            auto* bne = BE::AArch64::createInstr1(
                BE::AArch64::Operator::BNE, new BE::AArch64::LabelOperand(static_cast<int>(tLabel->lnum)));
            cur_block_->insts.push_back(bne);
        }
        if (fLabel)
        {
            auto* b = BE::AArch64::createInstr1(
                BE::AArch64::Operator::B, new BE::AArch64::LabelOperand(static_cast<int>(fLabel->lnum)));
            cur_block_->insts.push_back(b);
        }
    }

    void IRIsel::visit(ME::BrUncondInst& inst)
    {
        auto* lb = dynamic_cast<ME::LabelOperand*>(inst.target);
        if (!lb) return;
        auto* b = BE::AArch64::createInstr1(
            BE::AArch64::Operator::B, new BE::AArch64::LabelOperand(static_cast<int>(lb->lnum)));
        cur_block_->insts.push_back(b);
    }

    void IRIsel::visit(ME::CallInst& inst)
    {
        size_t intArgIdx = 0;
        size_t floatArgIdx = 0;
        size_t stackArgIdx = 0;
        for (auto& [dt, op] : inst.args)
        {
            auto* beType = toBEType(dt);
            BE::Register vreg;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(op)) vreg = ensureVReg(reg_map_, ro->regNum, beType);
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(op))
            {
                vreg = getVReg(beType);
                emitLoadImm(cur_block_, vreg, imm->value);
            }
            else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(op))
            {
                vreg = materializeF32(immf->value);
            }
            else if (auto* go = dynamic_cast<ME::GlobalOperand*>(op))
            {
                vreg = getVReg(BE::PTR);
                auto la = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(vreg), new BE::AArch64::SymbolOperand(go->name));
                cur_block_->insts.push_back(la);
            }
            vreg = ensureIntType(vreg, beType);

            if (isFloatType(beType))
            {
                if (floatArgIdx < AArch64::A64_FPR_ARG_COUNT)
                {
                    BE::Register phys(static_cast<int>(floatArgIdx), beType, false);
                    auto mv = BE::AArch64::createMove(new BE::RegOperand(phys), new BE::RegOperand(vreg));
                    cur_block_->insts.push_back(mv);
                    ++floatArgIdx;
                }
                else
                {
                    int offset = static_cast<int>(stackArgIdx * 8);
                    auto* mem  = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, offset);
                    auto* str  = BE::AArch64::createInstr2(
                        BE::AArch64::Operator::STR, new BE::RegOperand(vreg), mem);
                    cur_block_->insts.push_back(str);
                    ++stackArgIdx;
                }
            }
            else
            {
                if (intArgIdx < AArch64::A64_GPR_ARG_COUNT)
                {
                    if (beType == BE::I32) {
                        BE::Register phys(static_cast<int>(intArgIdx), BE::I64, false);
                        auto* sxtw = BE::AArch64::createInstr2(BE::AArch64::Operator::SXTW,
                            new BE::RegOperand(phys), new BE::RegOperand(vreg));
                        cur_block_->insts.push_back(sxtw);
                    } else {
                        BE::Register phys(static_cast<int>(intArgIdx), beType, false);
                        auto mv = BE::AArch64::createMove(new BE::RegOperand(phys), new BE::RegOperand(vreg));
                        cur_block_->insts.push_back(mv);
                    }
                    ++intArgIdx;
                }
                else
                {
                    BE::Register storeReg = vreg;
                    if (beType == BE::I32)
                    {
                         auto ext = getVReg(BE::I64);
                         auto* sxtw = BE::AArch64::createInstr2(BE::AArch64::Operator::SXTW,
                             new BE::RegOperand(ext), new BE::RegOperand(vreg));
                         cur_block_->insts.push_back(sxtw);
                         storeReg = ext;
                    }

                    int offset = static_cast<int>(stackArgIdx * 8);
                    auto* mem  = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, offset);
                    auto* str  = BE::AArch64::createInstr2(
                        BE::AArch64::Operator::STR, new BE::RegOperand(storeReg), mem);
                    cur_block_->insts.push_back(str);
                    ++stackArgIdx;
                }
            }
        }
        if (stackArgIdx) cur_func_->frameInfo.setParamAreaSize(static_cast<int>(stackArgIdx * 8));

        auto* bl = BE::AArch64::createInstr1(
            BE::AArch64::Operator::BL, new BE::AArch64::SymbolOperand(inst.funcName));
        cur_block_->insts.push_back(bl);

        if (inst.retType != ME::DataType::VOID && inst.res)
        {
            auto* beType = toBEType(inst.retType);
            auto  dst    = ensureVReg(reg_map_, inst.res->getRegNum(), beType);
            BE::Register phys;
            if (beType == BE::F32)
                phys = BE::Register(0, BE::F32, false);
            else if (beType == BE::F64)
                phys = BE::Register(0, BE::F64, false);
            else
                phys = BE::Register(0, beType, false);
            auto mv = BE::AArch64::createMove(new BE::RegOperand(dst), new BE::RegOperand(phys));
            cur_block_->insts.push_back(mv);

            if (beType == BE::PTR)
            {
                AddrInfo info;
                info.kind   = AddrInfo::Kind::Reg;
                info.reg    = dst;
                info.offset = 0;
                addr_map_[inst.res->getRegNum()] = info;
            }
        }
    }

    void IRIsel::visit(ME::RetInst& inst)
    {
        if (inst.rt != ME::DataType::VOID && inst.res)
        {
            auto* beType = toBEType(inst.rt);
            BE::Register dst;
            if (beType == BE::F32)
                dst = BE::Register(0, BE::F32, false);
            else if (beType == BE::F64)
                dst = BE::Register(0, BE::F64, false);
            else
                dst = BE::Register(0, beType, false);

            BE::Register src;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.res)) src = ensureVReg(reg_map_, ro->regNum, beType);
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(inst.res))
            {
                src = getVReg(beType);
                emitLoadImm(cur_block_, src, imm->value);
            }
            else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(inst.res))
            {
                src = materializeF32(immf->value);
            }

            if (beType == BE::I32) {
                 BE::Register dst64(0, BE::I64, false); // x0
                 auto* sxtw = BE::AArch64::createInstr2(BE::AArch64::Operator::SXTW,
                     new BE::RegOperand(dst64), new BE::RegOperand(src));
                 cur_block_->insts.push_back(sxtw);
            } else {
                 auto mv = BE::AArch64::createMove(new BE::RegOperand(dst), new BE::RegOperand(src));
                 cur_block_->insts.push_back(mv);
            }
        }

        auto* ret = BE::AArch64::createInstr0(BE::AArch64::Operator::RET);
        cur_block_->insts.push_back(ret);
    }

    void IRIsel::visit(ME::GEPInst& inst)
    {
        auto baseInfo = resolveAddr(addr_map_, inst.basePtr);
        int  elemSize = typeSize(inst.dt);
        size_t dimCount = inst.dims.size();
        size_t idxCount = inst.idxs.size();

        auto calcStride = [&](size_t idx) {
            int stride = elemSize;
            int mult   = 1;
            int dimIdx = static_cast<int>(idx) + static_cast<int>(dimCount) - static_cast<int>(idxCount);
            if (dimIdx < 0)
            {
                for (auto dim : inst.dims) mult *= dim;
            }
            else if (static_cast<size_t>(dimIdx) < dimCount)
            {
                for (size_t i = static_cast<size_t>(dimIdx) + 1; i < dimCount; ++i) mult *= inst.dims[i];
            }
            stride = mult * elemSize;
            return stride;
        };

        int          constOffset = 0;
        BE::Register dynOffset;
        bool         hasDyn = false;
        for (size_t i = 0; i < inst.idxs.size(); ++i)
        {
            int stride = calcStride(i);
            if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(inst.idxs[i]))
            {
                constOffset += imm->value * stride;
            }
            else if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.idxs[i]))
            {
                auto srcReg = ensureVReg(reg_map_, ro->regNum, BE::I32);
                auto idxReg = getVReg(BE::I64);
                auto* sxtw = BE::AArch64::createInstr2(BE::AArch64::Operator::SXTW,
                    new BE::RegOperand(idxReg),
                    new BE::RegOperand(srcReg));
                cur_block_->insts.push_back(sxtw);

                BE::Register scaled = idxReg;
                if (stride != 1)
                {
                    scaled = getVReg(BE::I64);
                    emitLoadImm(cur_block_, scaled, stride);
                    auto mul = BE::AArch64::createInstr3(BE::AArch64::Operator::MUL,
                        new BE::RegOperand(scaled),
                        new BE::RegOperand(idxReg),
                        new BE::RegOperand(scaled));
                    cur_block_->insts.push_back(mul);
                }
                if (!hasDyn)
                {
                    dynOffset = scaled;
                    hasDyn    = true;
                }
                else
                {
                    auto add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                        new BE::RegOperand(dynOffset),
                        new BE::RegOperand(dynOffset),
                        new BE::RegOperand(scaled));
                    cur_block_->insts.push_back(add);
                }
            }
        }

        size_t resId  = inst.res->getRegNum();
        auto   resReg = ensureVReg(reg_map_, resId, BE::PTR);

        auto emitBaseAdd = [&](const BE::Register& base, int off, BE::FrameIndexOperand* fiop) {
            if (fitsAddSubImm(off))
            {
                auto* add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                    new BE::RegOperand(resReg),
                    new BE::RegOperand(base),
                    new BE::AArch64::ImmeOperand(off));
                add->fiop = fiop;
                cur_block_->insts.push_back(add);
                return;
            }
            auto offReg = getVReg(BE::I64);
            emitLoadImm(cur_block_, offReg, off);
            auto* add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                new BE::RegOperand(resReg),
                new BE::RegOperand(base),
                new BE::RegOperand(offReg));
            add->fiop = fiop;
            cur_block_->insts.push_back(add);
        };

        switch (baseInfo.kind)
        {
            case AddrInfo::Kind::Frame:
            {
                emitBaseAdd(BE::AArch64::PR::sp, constOffset, new BE::FrameIndexOperand(baseInfo.frameIndex));
                if (hasDyn)
                {
                    auto addDyn = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(dynOffset));
                    cur_block_->insts.push_back(addDyn);
                }
                AddrInfo info;
                if (hasDyn)
                {
                    info.kind = AddrInfo::Kind::Reg;
                    info.reg  = resReg;
                }
                else
                {
                    info.kind       = AddrInfo::Kind::Frame;
                    info.frameIndex = baseInfo.frameIndex;
                    info.offset     = baseInfo.offset + constOffset;
                    info.reg        = resReg;
                }
                addr_map_[resId] = info;
                break;
            }
            case AddrInfo::Kind::Global:
            {
                auto baseReg = getVReg(BE::PTR);
                auto la      = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(baseReg), new BE::AArch64::SymbolOperand(baseInfo.globalName));
                cur_block_->insts.push_back(la);
                emitBaseAdd(baseReg, constOffset + baseInfo.offset, nullptr);
                if (hasDyn)
                {
                    auto addDyn = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(dynOffset));
                    cur_block_->insts.push_back(addDyn);
                }
                AddrInfo info;
                info.kind       = AddrInfo::Kind::Reg;
                info.reg        = resReg;
                info.offset     = 0;
                addr_map_[resId] = info;
                break;
            }
            case AddrInfo::Kind::Reg:
            {
                int baseOff = baseInfo.offset + constOffset;
                emitBaseAdd(baseInfo.reg, baseOff, nullptr);
                if (hasDyn)
                {
                    auto addDyn = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(resReg),
                        new BE::RegOperand(dynOffset));
                    cur_block_->insts.push_back(addDyn);
                }
                AddrInfo info;
                info.kind       = AddrInfo::Kind::Reg;
                info.reg        = resReg;
                info.offset     = 0;
                addr_map_[resId] = info;
                break;
            }
            default:
            {
                BE::Register baseReg;
                bool         hasBaseReg = false;
                if (auto* ro = dynamic_cast<ME::RegOperand*>(inst.basePtr))
                {
                    baseReg    = ensureVReg(reg_map_, ro->regNum, BE::PTR);
                    hasBaseReg = true;
                }

                if (hasBaseReg)
                {
                    emitBaseAdd(baseReg, constOffset, nullptr);
                    if (hasDyn)
                    {
                        auto addDyn = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                            new BE::RegOperand(resReg),
                            new BE::RegOperand(resReg),
                            new BE::RegOperand(dynOffset));
                        cur_block_->insts.push_back(addDyn);
                    }
                    AddrInfo info;
                    info.kind   = AddrInfo::Kind::Reg;
                    info.reg    = resReg;
                    info.offset = 0;
                    addr_map_[resId] = info;
                }
                else
                {
                    emitBaseAdd(BE::AArch64::PR::sp, constOffset, nullptr);
                    if (hasDyn)
                    {
                        auto addDyn = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                            new BE::RegOperand(resReg),
                            new BE::RegOperand(resReg),
                            new BE::RegOperand(dynOffset));
                        cur_block_->insts.push_back(addDyn);
                    }
                    addr_map_[resId] = AddrInfo{AddrInfo::Kind::Reg, -1, 0, "", resReg};
                }
                break;
            }
        }
    }

    void IRIsel::visit(ME::FP2SIInst& inst)
    {
        auto dst = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.dest)->regNum, BE::I32);
        auto src = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.src)->regNum, BE::F32);
        auto* cvt = BE::AArch64::createInstr2(BE::AArch64::Operator::FCVTZS,
            new BE::RegOperand(dst),
            new BE::RegOperand(src));
        cur_block_->insts.push_back(cvt);
    }

    void IRIsel::visit(ME::SI2FPInst& inst)
    {
        auto dst = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.dest)->regNum, BE::F32);
        auto src = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.src)->regNum, BE::I32);
        auto* cvt = BE::AArch64::createInstr2(BE::AArch64::Operator::SCVTF,
            new BE::RegOperand(dst),
            new BE::RegOperand(src));
        cur_block_->insts.push_back(cvt);
    }

    void IRIsel::visit(ME::ZextInst& inst)
    {
        auto dst = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.dest)->regNum, toBEType(inst.to));
        auto src = ensureVReg(reg_map_, dynamic_cast<ME::RegOperand*>(inst.src)->regNum, toBEType(inst.from));
        auto mv  = BE::AArch64::createMove(new BE::RegOperand(dst), new BE::RegOperand(src));
        cur_block_->insts.push_back(mv);
    }

    void IRIsel::visit(ME::PhiInst& inst)
    {
        auto dest = ensureVReg(reg_map_, inst.res->getRegNum(), toBEType(inst.dt));

        for (auto& [labelOp, val] : inst.incomingVals)
        {
            auto* label = dynamic_cast<ME::LabelOperand*>(labelOp);
            if (!label) continue;

            BE::Block* predBlock = cur_func_->blocks[label->lnum];

            // Find insertion point: before the terminator.
            auto insertIt = predBlock->insts.end();
            if (!predBlock->insts.empty())
            {
                auto* back = predBlock->insts.back();
                auto* adapter = BE::Targeting::g_adapter;
                if (adapter && (adapter->isUncondBranch(back) || adapter->isCondBranch(back) || adapter->isReturn(back)))
                {
                    insertIt = std::prev(predBlock->insts.end());
                }
            }

            // Materialize val
            BE::Register srcReg;
            bool hasSrc = false;
            if (auto* ro = dynamic_cast<ME::RegOperand*>(val))
            {
                srcReg = ensureVReg(reg_map_, ro->regNum, toBEType(inst.dt));
                hasSrc = true;
            }
            else if (auto* imm = dynamic_cast<ME::ImmeI32Operand*>(val))
            {
                srcReg  = getVReg(toBEType(inst.dt));
                emitLoadImmAt(predBlock, insertIt, srcReg, imm->value);
                hasSrc = true;
            }
            else if (auto* immf = dynamic_cast<ME::ImmeF32Operand*>(val))
            {
                std::vector<BE::MInstruction*> seq;
                srcReg = materializeF32(immf->value, predBlock, &seq);
                for (auto* inst : seq)
                {
                    insertIt = predBlock->insts.insert(insertIt, inst);
                    ++insertIt;
                }
                hasSrc = true;
            }
            else if (auto* go = dynamic_cast<ME::GlobalOperand*>(val))
            {
                srcReg  = getVReg(BE::PTR);
                auto la = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LA, new BE::RegOperand(srcReg), new BE::AArch64::SymbolOperand(go->name));
                predBlock->insts.insert(insertIt, la);
                hasSrc = true;
            }

            // Create Move
            if (hasSrc)
            {
                auto mv = BE::AArch64::createMove(new BE::RegOperand(dest), new BE::RegOperand(srcReg));
                predBlock->insts.insert(insertIt, mv);
            }
        }

        if (toBEType(inst.dt) == BE::PTR)
        {
            AddrInfo info;
            info.kind   = AddrInfo::Kind::Reg;
            info.reg    = dest;
            info.offset = 0;
            addr_map_[inst.res->getRegNum()] = info;
        }
    }

    void IRIsel::visit(ME::GlbVarDeclInst& inst)
    {
        ERROR("Global variable declarations should not appear in IR during instruction selection.");
    }
    void IRIsel::visit(ME::FuncDeclInst& inst)
    {
        ERROR("Function declarations should not appear in IR during instruction selection.");
    }
    void IRIsel::visit(ME::FuncDefInst& inst)
    {
        ERROR("Function definitions should not appear in IR during instruction selection.");
    }
}  // namespace BE::AArch64

    