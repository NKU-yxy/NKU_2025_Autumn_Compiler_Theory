#include <backend/targets/aarch64/passes/lowering/frame_lowering.h>
#include <backend/targets/aarch64/aarch64_defs.h>
#include <backend/mir/m_block.h>
#include <backend/mir/m_function.h>
#include <debug.h>
#include <algorithm>

namespace BE::AArch64::Passes::Lowering
{
    void FrameLoweringPass::runOnModule(BE::Module& module)
    {
        for (auto* func : module.functions)
        {
            if (!func) continue;
            lowerFunction(func);
        }
    }

    void FrameLoweringPass::lowerFunction(BE::Function* func)
    {
        // 预留：当前简化实现将具体栈框架与帧索引解析放在 StackLowering 中完成。
        // 这里无需修改 MIR。
        (void)func;
    }
}  // namespace BE::AArch64::Passes::Lowering
