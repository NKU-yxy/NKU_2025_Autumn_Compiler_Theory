#include <backend/targets/aarch64/passes/lowering/stack_lowering.h>
#include <backend/targets/aarch64/aarch64_defs.h>
#include <backend/targets/aarch64/aarch64_reg_info.h>
#include <backend/target/target_instr_adapter.h>
#include <backend/mir/m_block.h>
#include <backend/mir/m_function.h>
#include <backend/mir/m_instruction.h>
#include <set>
#include <vector>
#include <deque>

namespace BE::AArch64::Passes::Lowering
{
    // Helper functions
    static bool fitsLdrStrImm(int64_t off, int size)
    {
        if (off >= -256 && off <= 255) return true;
        if (off < 0) return false;
        if (off % size != 0) return false;
        return (off / size) <= 4095;
    }

    static bool fitsLdpStpImm(int64_t off, int size)
    {
        if (off % size != 0) return false;
        int64_t scaled = off / size;
        return scaled >= -64 && scaled <= 63;
    }

    static void insertLoadImm(BE::Block* block, std::deque<BE::MInstruction*>::iterator& it, int reg, int64_t val)
    {
        if (val == 0)
        {
            auto* mov = BE::AArch64::createInstr3(BE::AArch64::Operator::MOVZ,
                new BE::RegOperand(BE::Register(reg, BE::I64, false)),
                new BE::AArch64::ImmeOperand(0),
                new BE::AArch64::ImmeOperand(0));
            it = block->insts.insert(it, mov);
            it++;
            return;
        }

        uint64_t uval = static_cast<uint64_t>(val);
        bool first = true;
        for (int i = 0; i < 4; ++i)
        {
            uint16_t part = (uval >> (i * 16)) & 0xFFFF;
            if (part != 0)
            {
                if (first)
                {
                    auto* movz = BE::AArch64::createInstr3(BE::AArch64::Operator::MOVZ,
                        new BE::RegOperand(BE::Register(reg, BE::I64, false)),
                        new BE::AArch64::ImmeOperand(part),
                        new BE::AArch64::ImmeOperand(i * 16));
                    it = block->insts.insert(it, movz);
                    it++;
                    first = false;
                }
                else
                {
                    auto* movk = BE::AArch64::createInstr3(BE::AArch64::Operator::MOVK,
                        new BE::RegOperand(BE::Register(reg, BE::I64, false)),
                        new BE::AArch64::ImmeOperand(part),
                        new BE::AArch64::ImmeOperand(i * 16));
                    it = block->insts.insert(it, movk);
                    it++;
                }
            }
        }
    }

    void StackLoweringPass::runOnModule(BE::Module& module)
    {
        for (auto* func : module.functions)
        {
            if (!func) continue;
            lowerFunction(func);
        }
    }

    void StackLoweringPass::lowerFunction(BE::Function* func)
    {
        if (!func) return;

        // Compute base frame (param/locals/spills) size and align.
        int frameSize = func->frameInfo.calculateOffsets();
        // DEBUG: Print frame size
        std::cout << "Function: " << func->name << " FrameSize: " << frameSize << std::endl;
        frameSize = (frameSize + 15) & ~15;  // 16-byte alignment

        BE::Targeting::AArch64::RegInfo regInfo;
        std::set<int> usedInt;
        std::set<int> usedFloat;
        if (BE::Targeting::g_adapter)
        {
            for (auto& [bid, block] : func->blocks)
            {
                (void)bid;
                for (auto* inst : block->insts)
                {
                    std::vector<BE::Register> phys;
                    BE::Targeting::g_adapter->enumPhysRegs(inst, phys);
                    for (auto& pr : phys)
                    {
                        if (pr.dt == BE::F32 || pr.dt == BE::F64)
                            usedFloat.insert(pr.rId);
                        else
                            usedInt.insert(pr.rId);
                    }
                }
            }
        }

        int paramArea = func->frameInfo.getParamAreaSize();
        if (frameSize < paramArea) frameSize = paramArea;

        std::vector<BE::Register> saveInt;
        std::vector<BE::Register> saveFloat;
        for (int r : regInfo.calleeSavedIntRegs())
            if (usedInt.count(r)) saveInt.emplace_back(r, BE::I64, false);
        for (int r : regInfo.calleeSavedFloatRegs())
            if (usedFloat.count(r)) saveFloat.emplace_back(r, BE::F64, false);

        int savedAreaSize = static_cast<int>((saveInt.size() + saveFloat.size()) * 8);
        if (savedAreaSize % 16 != 0) savedAreaSize = (savedAreaSize + 15) / 16 * 16;

        int savedOffset = paramArea;
        frameSize += savedAreaSize;
        frameSize = (frameSize + 15) & ~15;
        int frameSizeTotal = frameSize;  // already includes saved area

        // 1. Resolve FrameIndex
        for (auto& [bid, block] : func->blocks)
        {
            for (auto it = block->insts.begin(); it != block->insts.end(); ++it)
            {
                auto* inst = *it;
                auto* ti = dynamic_cast<BE::AArch64::Instr*>(inst);
                if (!ti || !ti->fiop) continue;

                auto* fi = dynamic_cast<BE::FrameIndexOperand*>(ti->fiop);
                if (!fi) continue;
                int offset = func->frameInfo.getObjectOffset(static_cast<size_t>(fi->frameIndex));
                if (offset < 0)
                {
                    offset = func->frameInfo.getSpillSlotOffset(fi->frameIndex);
                    if (offset < 0)
                        std::cout << "[StackLowering] missing frame offset for FI=" << fi->frameIndex << std::endl;
                }
                offset += savedAreaSize;
                bool offsetHandled = false;
                
                for (size_t i = 0; i < ti->operands.size(); ++i)
                {
                    auto* op = ti->operands[i];
                    if (auto* mem = dynamic_cast<BE::AArch64::MemOperand*>(op))
                    {
                        int64_t newOffset = mem->offset + offset;
                        int size = 8;
                        if (ti->operands.size() > 0) {
                            if (auto* ro = dynamic_cast<BE::RegOperand*>(ti->operands[0])) {
                                if (ro->dt == BE::I32 || ro->dt == BE::F32) size = 4;
                            }
                        }

                        bool isPair = (ti->op == BE::AArch64::Operator::LDP || ti->op == BE::AArch64::Operator::STP);
                        bool fits = isPair ? fitsLdpStpImm(newOffset, size) : fitsLdrStrImm(newOffset, size);

                        if (fits)
                        {
                            mem->offset = newOffset;
                        }
                        else
                        {
                            int tmpReg = 15; // Use reserved register x15

                            insertLoadImm(block, it, tmpReg, newOffset);
                            auto* add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                                new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)),
                                new BE::RegOperand(BE::AArch64::PR::sp),
                                new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)));
                            it = block->insts.insert(it, add);
                            it++;
                            
                            mem->base = BE::Register(tmpReg, BE::I64, false);
                            mem->offset = 0;
                        }
                        offsetHandled = true;
                    }
                    else if (auto* imm = dynamic_cast<BE::AArch64::ImmeOperand*>(op))
                    {
                        int64_t newVal = imm->value + offset;
                        bool fits = (newVal >= 0 && newVal <= 4095) || (newVal >= 0 && (newVal & 0xFFF) == 0 && (newVal >> 12) <= 4095);
                        
                        if (fits)
                        {
                            imm->value = newVal;
                        }
                        else
                        {
                            insertLoadImm(block, it, 15, newVal);
                            delete imm;
                            ti->operands[i] = new BE::RegOperand(BE::Register(15, BE::I64, false));
                        }
                        offsetHandled = true;
                    }
                }

                // If offset is still not applied (e.g., address materialization "add dest, sp"),
                // fold it by adding an extra register operand that carries the immediate offset.
                if (!offsetHandled && offset != 0)
                {
                    int tmpReg = 15; // reserved scratch
                    insertLoadImm(block, it, tmpReg, offset);

                    // Ensure the ADD-like instruction uses the loaded offset as the third operand.
                    if (ti->operands.size() == 1)
                    {
                        ti->operands.push_back(new BE::RegOperand(BE::AArch64::PR::sp));
                        ti->operands.push_back(new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)));
                    }
                    else if (ti->operands.size() == 2)
                    {
                        ti->operands.push_back(new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)));
                    }
                    else if (ti->operands.size() >= 3)
                    {
                        // Replace the third operand with our offset register.
                        delete ti->operands[2];
                        ti->operands[2] = new BE::RegOperand(BE::Register(tmpReg, BE::I64, false));
                    }

                    offsetHandled = true;
                }
                ti->use_fiops = false;
            }
        }

        // 2. Expand FILoad/FIStore
        for (auto& [bid, block] : func->blocks)
        {
            for (auto it = block->insts.begin(); it != block->insts.end();)
            {
                if (auto* fiLoad = dynamic_cast<BE::FILoadInst*>(*it))
                {
                    int offset = func->frameInfo.getSpillSlotOffset(fiLoad->frameIndex);
                    offset += savedAreaSize;
                    int size = (fiLoad->dest.dt == BE::I32 || fiLoad->dest.dt == BE::F32) ? 4 : 8;
                    
                    BE::AArch64::MemOperand* mem;
                    if (fitsLdrStrImm(offset, size))
                    {
                        mem = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, offset);
                    }
                    else
                    {
                        int tmpReg = 15; // Use reserved register x15

                        insertLoadImm(block, it, tmpReg, offset);
                        auto* add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                            new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)),
                            new BE::RegOperand(BE::AArch64::PR::sp),
                            new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)));
                        it = block->insts.insert(it, add);
                        it++;
                        mem = new BE::AArch64::MemOperand(BE::Register(tmpReg, BE::I64, false), 0);
                    }

                    auto* inst = BE::AArch64::createInstr2(BE::AArch64::Operator::LDR,
                        new BE::RegOperand(fiLoad->dest),
                        mem);
                    it = block->insts.erase(it);
                    it = block->insts.insert(it, inst);
                    ++it;
                    continue;
                }
                if (auto* fiStore = dynamic_cast<BE::FIStoreInst*>(*it))
                {
                    int offset = func->frameInfo.getSpillSlotOffset(fiStore->frameIndex);
                    offset += savedAreaSize;
                    int size = (fiStore->src.dt == BE::I32 || fiStore->src.dt == BE::F32) ? 4 : 8;

                    BE::AArch64::MemOperand* mem;
                    if (fitsLdrStrImm(offset, size))
                    {
                        mem = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, offset);
                    }
                    else
                    {
                        int tmpReg = 15; // Use reserved register x15

                        insertLoadImm(block, it, tmpReg, offset);
                        auto* add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                            new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)),
                            new BE::RegOperand(BE::AArch64::PR::sp),
                            new BE::RegOperand(BE::Register(tmpReg, BE::I64, false)));
                        it = block->insts.insert(it, add);
                        it++;
                        mem = new BE::AArch64::MemOperand(BE::Register(tmpReg, BE::I64, false), 0);
                    }

                    auto* inst = BE::AArch64::createInstr2(BE::AArch64::Operator::STR,
                        new BE::RegOperand(fiStore->src),
                        mem);
                    it = block->insts.erase(it);
                    it = block->insts.insert(it, inst);
                    ++it;
                    continue;
                }
                ++it;
            }
        }

        struct SaveSlot
        {
            BE::Register reg;
            int          offset;
        };
        std::vector<SaveSlot> saveSlots;
        // Place callee-saved area right after outgoing param area; locals/spills were shifted above.
        for (auto& r : saveInt)
        {
            saveSlots.push_back({r, savedOffset});
            savedOffset += 8;
        }
        for (auto& r : saveFloat)
        {
            saveSlots.push_back({r, savedOffset});
            savedOffset += 8;
        }

        auto insertStoreCallee = [&](BE::Block* block, std::deque<BE::MInstruction*>::iterator& it, const SaveSlot& slot) {
            if (BE::AArch64::fitsUnsignedScaledOffset(slot.offset, 8))
            {
                auto* mem = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, slot.offset);
                auto* str = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::STR, new BE::RegOperand(slot.reg), mem);
                it = block->insts.insert(it, str);
                ++it;
                return;
            }
            BE::Register tmp(9, BE::I64, false);
            insertLoadImm(block, it, tmp.rId, slot.offset);
            auto* add = BE::AArch64::createInstr3(
                BE::AArch64::Operator::ADD,
                new BE::RegOperand(tmp),
                new BE::RegOperand(BE::AArch64::PR::sp),
                new BE::RegOperand(tmp));
            it = block->insts.insert(it, add);
            ++it;
            auto* mem = new BE::AArch64::MemOperand(tmp, 0);
            auto* str = BE::AArch64::createInstr2(
                BE::AArch64::Operator::STR, new BE::RegOperand(slot.reg), mem);
            it = block->insts.insert(it, str);
            ++it;
        };

        auto insertLoadCallee = [&](BE::Block* block, std::deque<BE::MInstruction*>::iterator& it, const SaveSlot& slot) {
            if (BE::AArch64::fitsUnsignedScaledOffset(slot.offset, 8))
            {
                auto* mem = new BE::AArch64::MemOperand(BE::AArch64::PR::sp, slot.offset);
                auto* ldr = BE::AArch64::createInstr2(
                    BE::AArch64::Operator::LDR, new BE::RegOperand(slot.reg), mem);
                it = block->insts.insert(it, ldr);
                ++it;
                return;
            }
            BE::Register tmp(9, BE::I64, false);
            insertLoadImm(block, it, tmp.rId, slot.offset);
            auto* add = BE::AArch64::createInstr3(
                BE::AArch64::Operator::ADD,
                new BE::RegOperand(tmp),
                new BE::RegOperand(BE::AArch64::PR::sp),
                new BE::RegOperand(tmp));
            it = block->insts.insert(it, add);
            ++it;
            auto* mem = new BE::AArch64::MemOperand(tmp, 0);
            auto* ldr = BE::AArch64::createInstr2(
                BE::AArch64::Operator::LDR, new BE::RegOperand(slot.reg), mem);
            it = block->insts.insert(it, ldr);
            ++it;
        };

        if (!func->blocks.empty())
        {
            auto* entryBlock = func->blocks.begin()->second;
            auto it = entryBlock->insts.begin();

            auto stp = BE::AArch64::createInstr4(BE::AArch64::Operator::STP,
                new BE::RegOperand(BE::AArch64::PR::x29),
                new BE::RegOperand(BE::AArch64::PR::x30),
                new BE::RegOperand(BE::AArch64::PR::sp),
                new BE::AArch64::ImmeOperand(-16));
            it = entryBlock->insts.insert(it, stp);
            ++it;

            auto mov = BE::AArch64::createMove(
                new BE::RegOperand(BE::AArch64::PR::x29),
                new BE::RegOperand(BE::AArch64::PR::sp));
            it = entryBlock->insts.insert(it, mov);
            ++it;

            if (frameSizeTotal > 0)
            {
                if (BE::AArch64::fitsUnsignedImm12(frameSizeTotal))
                {
                    auto sub = BE::AArch64::createInstr3(BE::AArch64::Operator::SUB,
                        new BE::RegOperand(BE::AArch64::PR::sp),
                        new BE::RegOperand(BE::AArch64::PR::sp),
                        new BE::AArch64::ImmeOperand(frameSizeTotal));
                    it = entryBlock->insts.insert(it, sub);
                    ++it;
                }
                else
                {
                    BE::Register tmp(9, BE::I64, false);
                    insertLoadImm(entryBlock, it, tmp.rId, frameSizeTotal);
                    auto sub = BE::AArch64::createInstr3(BE::AArch64::Operator::SUB,
                        new BE::RegOperand(BE::AArch64::PR::sp),
                        new BE::RegOperand(BE::AArch64::PR::sp),
                        new BE::RegOperand(tmp));
                    it = entryBlock->insts.insert(it, sub);
                    ++it;
                }
            }

            for (const auto& slot : saveSlots) insertStoreCallee(entryBlock, it, slot);

            for (auto& [bid, block] : func->blocks)
            {
                for (size_t i = 0; i < block->insts.size(); ++i)
                {
                    auto* inst = block->insts[i];
                    if (auto* ti = dynamic_cast<BE::AArch64::Instr*>(inst))
                    {
                        if (ti->op != BE::AArch64::Operator::RET) continue;
                        
                        auto it = block->insts.begin() + i;

                        for (auto rs = saveSlots.rbegin(); rs != saveSlots.rend(); ++rs)
                            insertLoadCallee(block, it, *rs);

                        if (frameSizeTotal > 0)
                        {
                            if (BE::AArch64::fitsUnsignedImm12(frameSizeTotal))
                            {
                                auto add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                                    new BE::RegOperand(BE::AArch64::PR::sp),
                                    new BE::RegOperand(BE::AArch64::PR::sp),
                                    new BE::AArch64::ImmeOperand(frameSizeTotal));
                                it = block->insts.insert(it, add);
                                ++it;
                            }
                            else
                            {
                                BE::Register tmp(9, BE::I64, false);
                                insertLoadImm(block, it, tmp.rId, frameSizeTotal);
                                auto add = BE::AArch64::createInstr3(BE::AArch64::Operator::ADD,
                                    new BE::RegOperand(BE::AArch64::PR::sp),
                                    new BE::RegOperand(BE::AArch64::PR::sp),
                                    new BE::RegOperand(tmp));
                                it = block->insts.insert(it, add);
                                ++it;
                            }
                        }

                        // Restore fp/lr and unwind the last 16 bytes in one post-indexed step.
                        auto ldp = BE::AArch64::createInstr4(BE::AArch64::Operator::LDP,
                            new BE::RegOperand(BE::AArch64::PR::x29),
                            new BE::RegOperand(BE::AArch64::PR::x30),
                            new BE::RegOperand(BE::AArch64::PR::sp),
                            new BE::AArch64::ImmeOperand(16));
                        it = block->insts.insert(it, ldp);
                        ++it;
                        
                        break; 
                    }
                }
            }
        }
    }
}
