#include <backend/targets/aarch64/aarch64_target.h>
#include <backend/target/registry.h>
#include <backend/targets/aarch64/aarch64_reg_info.h>
#include <backend/targets/aarch64/aarch64_instr_adapter.h>
#include <backend/targets/aarch64/isel/aarch64_ir_isel.h>
#include <backend/targets/aarch64/passes/lowering/frame_lowering.h>
#include <backend/targets/aarch64/passes/lowering/stack_lowering.h>
#include <backend/ra/linear_scan.h>
#include <backend/targets/aarch64/aarch64_codegen.h>
#include <middleend/visitor/printer/module_printer.h>

#include <iostream>

namespace BE::Targeting::AArch64
{
    namespace
    {
        struct AutoRegister
        {
            AutoRegister()
            {
                BE::Targeting::TargetRegistry::registerTargetFactory("aarch64", []() { return new AArch64Target(); });
                BE::Targeting::TargetRegistry::registerTargetFactory("armv8", []() { return new AArch64Target(); });
            }
        } s_auto_register;
    }  // namespace

    void AArch64Target::runPipeline(ME::Module* ir, BE::Module* backend, std::ostream* out)
    {
        if (!ir || !out)
        {
            std::cerr << "[aarch64] invalid inputs for backend pipeline\n";
            return;
        }

        BE::Module backendModuleLocal;
        if (!backend) backend = &backendModuleLocal;

        // 目标相关辅助
        static RegInfo             regInfo;
        static InstrAdapter        adapter;
        BE::Targeting::setTargetInstrAdapter(&adapter);

        // ISel
        {
            BE::AArch64::IRIsel isel(ir, backend, this);
            isel.run();
        }

        // Frame Lowering (预RA) - 目前无需额外处理
        {
            BE::AArch64::Passes::Lowering::FrameLoweringPass fl;
            fl.runOnModule(*backend);
        }

        // 寄存器分配（简化版 linear scan 内部做溢出/回填）
        {
            BE::RA::LinearScanRA ra;
            ra.allocate(*backend, regInfo);
        }

        // Stack Lowering（栈大小、帧索引、前言/后语）
        {
            BE::AArch64::Passes::Lowering::StackLoweringPass sl;
            sl.runOnModule(*backend);
        }

        // 汇编输出
        {
            BE::AArch64::Codegen cg(backend, *out);
            cg.generateAssembly();
        }
    }
}  // namespace BE::Targeting::AArch64
