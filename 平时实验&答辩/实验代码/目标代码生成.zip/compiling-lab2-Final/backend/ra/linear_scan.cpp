#include <backend/ra/linear_scan.h>
#include <backend/mir/m_function.h>
#include <backend/mir/m_instruction.h>
#include <backend/mir/m_block.h>
#include <backend/mir/m_defs.h>
#include <backend/target/target_reg_info.h>
#include <backend/target/target_instr_adapter.h>
#include <backend/common/cfg.h>
#include <backend/common/cfg_builder.h>
#include <utils/dynamic_bitset.h>
#include <debug.h>
#include <backend/targets/aarch64/aarch64_defs.h>

#include <map>
#include <set>
#include <unordered_map>
#include <deque>
#include <algorithm>

namespace BE::RA
{
    /*
     * 线性扫描寄存器分配（Linear Scan）教学版说明
     *
     * 目标：将每个虚拟寄存器（vreg）的活跃区间映射到目标机的物理寄存器或栈槽（溢出）。
     *
     * 核心步骤（整数/浮点分开执行，流程相同）：
     * 1) 指令线性化与编号：为函数内所有指令分配全局顺序号，记录每个基本块的 [start, end) 区间，
     *    同时收集调用点（callPoints），用于偏好分配被调用者保存寄存器（callee-saved）。
     * 2) 构建 USE/DEF：枚举每条指令的使用与定义寄存器，聚合到基本块级的 USE/DEF 集合。
     * 3) 活跃性分析：在 CFG 上迭代 IN/OUT，满足 IN = USE ∪ (OUT − DEF) 直至收敛。
     * 4) 活跃区间构建：按基本块从后向前，根据 IN/OUT 与指令次序，累积每个 vreg 的若干 [start, end) 段并合并。
     * 5) 标记跨调用：若区间与任意调用点重叠（交叉），标记 crossesCall=true，以便后续优先使用被调用者保存寄存器。
     * 6) 线性扫描分配：将区间按起点排序，维护活动集合 active；到达新区间时先移除已过期区间，然后
     *    尝试选择空闲物理寄存器；若无空闲则选择一个区间溢出（常见启发：溢出“结束点更远”的区间）。
     * 7) 重写 MIR：对未分配物理寄存器的 use/def，在指令前/后插入 reload/spill，并用临时物理寄存器替换操作数。
     *
     * 提示：
     * - 通过 TargetInstrAdapter 提供的接口完成目标无关的指令读写。
     * - TargetRegInfo 提供了可分配寄存器集合、被调用者保存寄存器、保留寄存器等信息。
     */
    namespace
    {
        struct Segment
        {
            int start;
            int end;
            Segment(int s = 0, int e = 0) : start(s), end(e) {}
        };
        struct Interval
        {
            BE::Register         vreg;
            std::vector<Segment> segs;
            bool                 crossesCall = false;

            void addSegment(int s, int e)
            {
                if (s >= e) return;
                segs.emplace_back(s, e);
            }
            void merge()
            {
                if (segs.empty()) return;
                std::sort(segs.begin(), segs.end(), [](const Segment& a, const Segment& b) { return a.start < b.start; });
                std::vector<Segment> merged;
                merged.push_back(segs[0]);
                for (size_t i = 1; i < segs.size(); ++i)
                {
                    if (segs[i].start <= merged.back().end)
                    {
                        merged.back().end = std::max(merged.back().end, segs[i].end);
                    }
                    else
                    {
                        merged.push_back(segs[i]);
                    }
                }
                segs = merged;
            }
        };

        struct IntervalOrder
        {
            bool operator()(const Interval* a, const Interval* b) const { return a->segs.front().start < b->segs.front().start; }
        };
    }  // namespace

    static std::vector<int> buildAllocatableInt(const BE::Targeting::TargetRegInfo& ri)
    {
        std::vector<int> regs;
        for (int r : ri.intRegs())
        {
            if (std::find(ri.reservedRegs().begin(), ri.reservedRegs().end(), r) != ri.reservedRegs().end()) continue;
            regs.push_back(r);
        }
        return regs;
    }
    static std::vector<int> buildAllocatableFloat(const BE::Targeting::TargetRegInfo& ri)
    {
        std::vector<int> regs;
        for (int r : ri.floatRegs()) regs.push_back(r);
        return regs;
    }

    void LinearScanRA::allocateFunction(BE::Function& func, const BE::Targeting::TargetRegInfo& regInfo)
    {
        ASSERT(BE::Targeting::g_adapter && "TargetInstrAdapter is not set");

        std::map<BE::Block*, std::pair<int, int>>                                   blockRange;
        std::vector<std::pair<BE::Block*, std::deque<BE::MInstruction*>::iterator>> id2iter;
        std::set<int>                                                               callPoints;
        int                                                                         ins_id = 0;
        for (auto& [bid, block] : func.blocks)
        {
            int start = ins_id;
            for (auto it = block->insts.begin(); it != block->insts.end(); ++it, ++ins_id)
            {
                id2iter.emplace_back(block, it);
                if (BE::Targeting::g_adapter->isCall(*it)) callPoints.insert(ins_id);
            }
            blockRange[block] = {start, ins_id};
        }

        std::map<BE::Block*, std::set<BE::Register>> USE, DEF;
        for (auto& [bid, block] : func.blocks)
        {
            std::set<BE::Register> use, def;
            for (auto it = block->insts.begin(); it != block->insts.end(); ++it)
            {
                std::vector<BE::Register> uses, defs;
                BE::Targeting::g_adapter->enumUses(*it, uses);
                BE::Targeting::g_adapter->enumDefs(*it, defs);
                for (auto& d : defs)
                    if (!def.count(d)) def.insert(d);
                for (auto& u : uses)
                    if (!def.count(u)) use.insert(u);
            }
            USE[block] = std::move(use);
            DEF[block] = std::move(def);
        }

        // ============================================================================
        // 构建 CFG 后继关系
        // ============================================================================
        // 作用：搭建活跃性数据流的图结构。
        // 如何做：可直接用 MIR::CFGBuilder 生成 CFG，再转换为 succs 映射。
        BE::MIR::CFGBuilder                           builder(BE::Targeting::g_adapter);
        BE::MIR::CFG*                                 cfg = builder.buildCFGForFunction(&func);
        std::map<BE::Block*, std::vector<BE::Block*>> succs;
        if (cfg)
        {
            for (size_t from = 0; from < cfg->graph_id.size(); ++from)
            {
                if (func.blocks.count(from) == 0) continue;
                BE::Block* fromBlk = func.blocks[from];
                std::vector<BE::Block*> list;
                const auto& tos = cfg->graph_id[from];
                for (auto t : tos)
                    if (func.blocks.count(t)) list.push_back(func.blocks[t]);
                succs[fromBlk] = std::move(list);
            }
        }

        // ============================================================================
        // 活跃性分析（IN/OUT）
        // ============================================================================
        // IN[b] = USE[b] ∪ (OUT[b] − DEF[b])，OUT[b] = ⋃ IN[s]，其中 s ∈ succs[b]
        // 迭代执行上述操作直到不变为止
        std::map<BE::Block*, std::set<BE::Register>> IN, OUT;
        bool                                         changed = true;
        while (changed)
        {
            changed = false;
            for (auto& [bid, block] : func.blocks)
            {
                std::set<BE::Register> newOUT;
                for (auto* s : succs[block])
                {
                    auto it = IN.find(s);
                    if (it != IN.end()) newOUT.insert(it->second.begin(), it->second.end());
                }
                std::set<BE::Register> newIN = USE[block];

                for (auto& r : newOUT)
                    if (!DEF[block].count(r)) newIN.insert(r);

                if (!(newOUT != OUT[block] || newIN != IN[block])) continue;

                OUT[block] = std::move(newOUT);
                IN[block]  = std::move(newIN);
                changed    = true;
            }
        }

        delete cfg;

        // ============================================================================
        // 构建活跃区间（Intervals）
        // ============================================================================
        // 作用：得到每个 vreg 的若干 [start,end) 段并合并（interval.merge()）。
        // 如何做：对每个基本块，反向遍历其指令序列，根据 IN/OUT/uses/defs 更新段的开始/结束。
        std::map<BE::Register, Interval> intervals;
        auto ensureInterval = [&](const BE::Register& r) -> Interval& {
            if (intervals[r].vreg.dt == nullptr && intervals[r].vreg.rId == 0) intervals[r].vreg = r;
            return intervals[r];
        };

        for (auto& [bid, block] : func.blocks)
        {
            int end = blockRange[block].second;
            int cur = end - 1;  // last instruction position
            std::set<BE::Register> live = OUT[block];

            for (auto it = block->insts.rbegin(); it != block->insts.rend(); ++it, --cur)
            {
                // Extend all currently live regs through this instruction slot
                for (auto& r : live) ensureInterval(r).addSegment(cur, cur + 1);

                std::vector<BE::Register> uses, defs;
                BE::Targeting::g_adapter->enumUses(*it, uses);
                BE::Targeting::g_adapter->enumDefs(*it, defs);

                for (auto& d : defs)
                {
                    ensureInterval(d).addSegment(cur, cur + 1);
                    live.erase(d);
                }
                for (auto& u : uses) live.insert(u);
            }

            // cur exits loop at start-1; remaining live (IN set) already extended during traversal.
        }
        for (auto& [vr, itv] : intervals) itv.merge();

        // ============================================================================
        // 线性扫描主循环
        // ============================================================================
        // 作用：按区间起点排序；进入新区间前，先从活动集合 active 移除“已结束”的区间；
        // 然后尝试分配空闲物理寄存器；若无可用，执行溢出策略（如“溢出结束点更远”的区间）。
        auto allIntRegs   = buildAllocatableInt(regInfo);
        auto allFloatRegs = buildAllocatableFloat(regInfo);

        // 排除专用的溢出回填 scratch，避免与真实分配冲突
        std::vector<int> intScratch   = {11, 12, 13, 14};
        std::vector<int> floatScratch = {16, 17, 18, 19}; // Use caller-saved floats (v16-v31)
        auto eraseScratch = [](std::vector<int>& pool, const std::vector<int>& scratch) {
            pool.erase(std::remove_if(pool.begin(), pool.end(), [&](int r) {
                return std::find(scratch.begin(), scratch.end(), r) != scratch.end();
            }), pool.end());
        };
        eraseScratch(allIntRegs, intScratch);
        eraseScratch(allFloatRegs, floatScratch);

        // 预留：若指令中显式使用了物理寄存器，则不再分配这些寄存器以避免破坏语义
        std::set<int> usedPhysInt;
        std::set<int> usedPhysFloat;
        for (auto& [bid, block] : func.blocks)
        {
            (void)bid;
            for (auto* inst : block->insts)
            {
                std::vector<BE::Register> phys;
                BE::Targeting::g_adapter->enumPhysRegs(inst, phys);
                for (auto& pr : phys)
                {
                    if (pr.dt == BE::F32 || pr.dt == BE::F64)
                        usedPhysFloat.insert(pr.rId);
                    else
                        usedPhysInt.insert(pr.rId);
                }
            }
        }
        auto eraseUsed = [](std::vector<int>& pool, const std::set<int>& used) {
            pool.erase(std::remove_if(pool.begin(), pool.end(), [&](int r) { return used.count(r); }), pool.end());
        };
        eraseUsed(allIntRegs, usedPhysInt);
        eraseUsed(allFloatRegs, usedPhysFloat);

        auto calleeInt   = regInfo.calleeSavedIntRegs();
        auto calleeFloat = regInfo.calleeSavedFloatRegs();
        std::set<int> calleeIntSet(calleeInt.begin(), calleeInt.end());
        std::set<int> calleeFloatSet(calleeFloat.begin(), calleeFloat.end());

        std::map<BE::Register, BE::Register> vreg2phys;
        std::map<BE::Register, int>          vreg2fi;

        std::vector<Interval*> intIntervals;
        std::vector<Interval*> floatIntervals;
        for (auto& [vr, itv] : intervals)
        {
            if (!vr.isVreg) continue;
            // 标记跨调用区间：有任意片段覆盖 callPoints 中的指令序号即认为跨调用
            for (int cp : callPoints)
            {
                for (auto& seg : itv.segs)
                    if (cp >= seg.start && cp < seg.end) itv.crossesCall = true;
            }

            if (vr.dt == BE::F32 || vr.dt == BE::F64)
                floatIntervals.push_back(&itv);
            else
                intIntervals.push_back(&itv);
        }

        auto endOf = [](Interval* itv) { return itv->segs.back().end; };

        struct ActiveInfo
        {
            Interval* itv;
            int       reg;
        };

        auto expireOld = [&](std::vector<ActiveInfo>& active, int curStart, std::vector<int>& freeRegs) {
            active.erase(std::remove_if(active.begin(), active.end(), [&](const ActiveInfo& info) {
                if (endOf(info.itv) <= curStart)
                {
                    freeRegs.push_back(info.reg);
                    return true;
                }
                return false;
            }), active.end());
        };

        auto chooseReg = [&](std::vector<int>& freeRegs, const std::set<int>& calleeSaved, bool preferCallee) -> int {
            auto pickFrom = [&](auto pred) -> int {
                for (auto it = freeRegs.begin(); it != freeRegs.end(); ++it)
                {
                    if (pred(*it))
                    {
                        int r = *it;
                        freeRegs.erase(it);
                        return r;
                    }
                }
                return -1;
            };

            if (preferCallee)
            {
                int r = pickFrom([&](int id) { return calleeSaved.count(id); });
                if (r != -1) return r;
                return -1;
            }

            int r = pickFrom([&](int id) { return !calleeSaved.count(id); });
            if (r != -1) return r;
            return pickFrom([&](int) { return true; });
        };

        auto ensureSpill = [&](const BE::Register& vreg, bool isFloat) {
            if (vreg2fi.find(vreg) != vreg2fi.end()) return;
            int fi = func.frameInfo.createSpillSlot(isFloat ? 8 : 8);
            vreg2fi[vreg] = fi;
        };

        auto allocateList = [&](std::vector<Interval*>& list, std::vector<int>& freeRegs, const std::set<int>& calleeSaved, bool isFloat) {
            std::sort(list.begin(), list.end(), IntervalOrder());
            std::vector<ActiveInfo> active;

            for (auto* itv : list)
            {
                int start = itv->segs.front().start;
                expireOld(active, start, freeRegs);

                int reg = chooseReg(freeRegs, calleeSaved, itv->crossesCall);
                if (reg == -1)
                {
                    auto spillIt = active.end();
                    if (itv->crossesCall)
                    {
                        int maxEnd = -1;
                        for (auto it = active.begin(); it != active.end(); ++it)
                        {
                            if (calleeSaved.count(it->reg))
                            {
                                if (endOf(it->itv) > maxEnd)
                                {
                                    maxEnd  = endOf(it->itv);
                                    spillIt = it;
                                }
                            }
                        }
                    }
                    else
                    {
                        spillIt = std::max_element(active.begin(), active.end(),
                                                   [&](const ActiveInfo& a, const ActiveInfo& b) { return endOf(a.itv) < endOf(b.itv); });
                    }

                    if (spillIt != active.end() && endOf(spillIt->itv) > endOf(itv))
                    {
                        ensureSpill(spillIt->itv->vreg, isFloat);
                        vreg2phys.erase(spillIt->itv->vreg);
                        reg = spillIt->reg;
                        active.erase(spillIt);
                    }
                    else
                    {
                        ensureSpill(itv->vreg, isFloat);
                        continue;
                    }
                }

                vreg2phys[itv->vreg] = BE::Register(reg, itv->vreg.dt, false);
                active.push_back({itv, reg});
                std::sort(active.begin(), active.end(), [&](const ActiveInfo& a, const ActiveInfo& b) {
                    return endOf(a.itv) < endOf(b.itv);
                });
            }
        };

        allocateList(intIntervals, allIntRegs, calleeIntSet, false);
        allocateList(floatIntervals, allFloatRegs, calleeFloatSet, true);

        // ============================================================================
        // 重写 MIR（插入 reload/spill，替换 use/def）
        // ============================================================================
        // 作用：将未分配物理寄存器的 use/def 改写为使用 scratch + FILoad/FIStore（由 Adapter 注入）。
        for (auto& [bid, block] : func.blocks)
        {
            (void)bid;
            for (size_t i = 0; i < block->insts.size(); ++i)
            {
                auto instIt = block->insts.begin() + i;
                auto inst   = *instIt;

                std::vector<BE::Register> uses, defs;
                BE::Targeting::g_adapter->enumUses(inst, uses);
                BE::Targeting::g_adapter->enumDefs(inst, defs);

                int intUseIdx = 0, floatUseIdx = 0;
                for (auto& u : uses)
                {
                    if (!u.isVreg) continue;

                    auto physIt = vreg2phys.find(u);
                    if (physIt != vreg2phys.end())
                    {
                        BE::Targeting::g_adapter->replaceUse(inst, u, physIt->second);
                        continue;
                    }

                    ensureSpill(u, u.dt == BE::F32 || u.dt == BE::F64);
                    int fi = vreg2fi[u];

                    bool isF = (u.dt == BE::F32 || u.dt == BE::F64);
                    int  idx = isF ? floatUseIdx++ : intUseIdx++;
                    const auto& scratch = isF ? floatScratch : intScratch;
                    if (idx >= static_cast<int>(scratch.size())) idx = static_cast<int>(scratch.size()) - 1;
                    auto phys = BE::Register(scratch[idx], u.dt, false);

                    BE::Targeting::g_adapter->insertReloadBefore(block, block->insts.begin() + i, phys, fi);
                    ++i;  // 跳过刚插入的 load
                    inst = block->insts[i];
                    BE::Targeting::g_adapter->replaceUse(inst, u, phys);
                }

                int intDefIdx = 0, floatDefIdx = 0;
                for (auto& d : defs)
                {
                    if (!d.isVreg) continue;

                    auto physIt = vreg2phys.find(d);
                    if (physIt != vreg2phys.end())
                    {
                        BE::Targeting::g_adapter->replaceDef(inst, d, physIt->second);
                        continue;
                    }

                    ensureSpill(d, d.dt == BE::F32 || d.dt == BE::F64);
                    int fi = vreg2fi[d];

                    bool isF = (d.dt == BE::F32 || d.dt == BE::F64);
                    int  idx = isF ? floatDefIdx++ : intDefIdx++;
                    const auto& scratch = isF ? floatScratch : intScratch;
                    if (idx >= static_cast<int>(scratch.size())) idx = static_cast<int>(scratch.size()) - 1;
                    auto phys = BE::Register(scratch[idx], d.dt, false);

                    BE::Targeting::g_adapter->replaceDef(inst, d, phys);
                    BE::Targeting::g_adapter->insertSpillAfter(block, block->insts.begin() + i, phys, fi);
                    ++i;  // 跳过插入的 spill
                }
            }
        }
    }
}  // namespace BE::RA
