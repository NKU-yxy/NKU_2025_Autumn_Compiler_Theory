#include <middleend/pass/mem2reg.h>
#include <middleend/pass/analysis/analysis_manager.h>
#include <middleend/pass/analysis/cfg.h>
#include <middleend/pass/analysis/dominfo.h>
#include <middleend/module/ir_block.h>
#include <middleend/module/ir_function.h>
#include <middleend/module/ir_module.h>
#include <middleend/module/ir_instruction.h>
#include <middleend/module/ir_operand.h>
#include <utils/debug.h>
#include <deque>
#include <map>
#include <queue>
#include <set>
#include <unordered_map>
#include <cstdlib>
#include <cstdio>

namespace
{
    using namespace ME;
    using namespace ME::Analysis;

    static bool mem2regDebugEnabled()
    {
        static bool enabled = (std::getenv("MEM2REG_DEBUG") != nullptr);
        return enabled;
    }

    static void mem2regTrace(const char* stage)
    {
        if (mem2regDebugEnabled()) std::fprintf(stderr, "[mem2reg] %s\n", stage);
    }

    // -------- 基础工具函数 --------
    static bool isRegOperand(const Operand* op, size_t reg)
    {
        if (!op) return false;
        if (op->getType() != OperandType::REG) return false;
        return op->getRegNum() == reg;
    }

    static bool replaceOperand(Operand*& op, size_t from, Operand* to)
    {
        if (isRegOperand(op, from))
        {
            op = to;
            return true;
        }
        return false;
    }

    static bool instructionDefines(Instruction* inst, size_t& defReg)
    {
        defReg = 0;
        if (auto* i = dynamic_cast<ArithmeticInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<IcmpInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<FcmpInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<LoadInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<GEPInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<SI2FPInst*>(inst)) { defReg = i->dest->getRegNum(); return true; }
        if (auto* i = dynamic_cast<FP2SIInst*>(inst)) { defReg = i->dest->getRegNum(); return true; }
        if (auto* i = dynamic_cast<ZextInst*>(inst)) { defReg = i->dest->getRegNum(); return true; }
        if (auto* i = dynamic_cast<CallInst*>(inst))
        {
            if (i->res)
            {
                defReg = i->res->getRegNum();
                return true;
            }
            return false;
        }
        if (auto* i = dynamic_cast<PhiInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        if (auto* i = dynamic_cast<AllocaInst*>(inst))
        {
            defReg = i->res->getRegNum();
            return true;
        }
        return false;
    }

    static bool hasSideEffect(Instruction* inst)
    {
        switch (inst->opcode)
        {
            case Operator::STORE:
            case Operator::BR_COND:
            case Operator::BR_UNCOND:
            case Operator::RET:
            case Operator::CALL: return true;
            default: return false;
        }
    }

    static void replaceAllUses(Function& func, size_t fromReg, Operand* to)
    {
        if (!to) return;
        for (auto& [bid, block] : func.blocks)
        {
            for (auto* inst : block->insts)
            {
                // 不替换定义位置，只改用到 fromReg 的操作数
                switch (inst->opcode)
                {
                    case Operator::LOAD:
                    {
                        auto* i = static_cast<LoadInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        break;
                    }
                    case Operator::STORE:
                    {
                        auto* i = static_cast<StoreInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        replaceOperand(i->val, fromReg, to);
                        break;
                    }
                    case Operator::ADD:
                    case Operator::SUB:
                    case Operator::MUL:
                    case Operator::DIV:
                    case Operator::MOD:
                    case Operator::BITXOR:
                    case Operator::BITAND:
                    case Operator::SHL:
                    case Operator::ASHR:
                    case Operator::LSHR:
                    case Operator::FADD:
                    case Operator::FSUB:
                    case Operator::FMUL:
                    case Operator::FDIV:
                    {
                        auto* i = static_cast<ArithmeticInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::ICMP:
                    {
                        auto* i = static_cast<IcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::FCMP:
                    {
                        auto* i = static_cast<FcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::BR_COND:
                    {
                        auto* i = static_cast<BrCondInst*>(inst);
                        replaceOperand(i->cond, fromReg, to);
                        break;
                    }
                    case Operator::CALL:
                    {
                        auto* i = static_cast<CallInst*>(inst);
                        for (auto& [_, op] : i->args) replaceOperand(op, fromReg, to);
                        break;
                    }
                    case Operator::RET:
                    {
                        auto* i = static_cast<RetInst*>(inst);
                        replaceOperand(i->res, fromReg, to);
                        break;
                    }
                    case Operator::GETELEMENTPTR:
                    {
                        auto* i = static_cast<GEPInst*>(inst);
                        replaceOperand(i->basePtr, fromReg, to);
                        for (auto& idx : i->idxs) replaceOperand(idx, fromReg, to);
                        break;
                    }
                    case Operator::SITOFP:
                    {
                        auto* i = static_cast<SI2FPInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::FPTOSI:
                    {
                        auto* i = static_cast<FP2SIInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::ZEXT:
                    {
                        auto* i = static_cast<ZextInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::PHI:
                    {
                        auto* i = static_cast<PhiInst*>(inst);
                        for (auto& kv : i->incomingVals) replaceOperand(kv.second, fromReg, to);
                        break;
                    }
                    default: break;
                }
            }
        }
    }

    static void cleanTrailingUnreachable(Function& func)
    {
        for (auto& [bid, block] : func.blocks)
        {
            bool seenTerm = false;
            for (auto it = block->insts.begin(); it != block->insts.end();)
            {
                if (!seenTerm && (*it)->isTerminator())
                {
                    seenTerm = true;
                    ++it;
                    continue;
                }
                if (seenTerm)
                {
                    delete *it;
                    it = block->insts.erase(it);
                }
                else
                {
                    ++it;
                }
            }
        }
    }

    static bool removeDeadDefs(Function& func)
    {
        bool changed = false;
        while (true)
        {
            std::unordered_map<size_t, int> useCnt;
            auto addUse = [&](Operand* op) {
                if (!op) return;
                if (op->getType() != OperandType::REG) return;
                useCnt[op->getRegNum()]++;
            };

            for (auto& [bid, block] : func.blocks)
            {
                for (auto* inst : block->insts)
                {
                    switch (inst->opcode)
                    {
                        case Operator::LOAD:
                        {
                            auto* i = static_cast<LoadInst*>(inst);
                            addUse(i->ptr);
                            break;
                        }
                        case Operator::STORE:
                        {
                            auto* i = static_cast<StoreInst*>(inst);
                            addUse(i->ptr);
                            addUse(i->val);
                            break;
                        }
                        case Operator::ADD:
                        case Operator::SUB:
                        case Operator::MUL:
                        case Operator::DIV:
                        case Operator::MOD:
                        case Operator::BITXOR:
                        case Operator::BITAND:
                        case Operator::SHL:
                        case Operator::ASHR:
                        case Operator::LSHR:
                        case Operator::FADD:
                        case Operator::FSUB:
                        case Operator::FMUL:
                        case Operator::FDIV:
                        {
                            auto* i = static_cast<ArithmeticInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::ICMP:
                        {
                            auto* i = static_cast<IcmpInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::FCMP:
                        {
                            auto* i = static_cast<FcmpInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::BR_COND:
                        {
                            auto* i = static_cast<BrCondInst*>(inst);
                            addUse(i->cond);
                            break;
                        }
                        case Operator::CALL:
                        {
                            auto* i = static_cast<CallInst*>(inst);
                            for (auto& [_, op] : i->args) addUse(op);
                            break;
                        }
                        case Operator::RET:
                        {
                            auto* i = static_cast<RetInst*>(inst);
                            addUse(i->res);
                            break;
                        }
                        case Operator::GETELEMENTPTR:
                        {
                            auto* i = static_cast<GEPInst*>(inst);
                            addUse(i->basePtr);
                            for (auto* idx : i->idxs) addUse(idx);
                            break;
                        }
                        case Operator::SITOFP:
                        {
                            auto* i = static_cast<SI2FPInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::FPTOSI:
                        {
                            auto* i = static_cast<FP2SIInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::ZEXT:
                        {
                            auto* i = static_cast<ZextInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::PHI:
                        {
                            auto* i = static_cast<PhiInst*>(inst);
                            for (auto& kv : i->incomingVals) addUse(kv.second);
                            break;
                        }
                        default: break;
                    }
                }
            }

            bool removed = false;
            for (auto& [bid, block] : func.blocks)
            {
                for (auto it = block->insts.begin(); it != block->insts.end();)
                {
                    size_t def = 0;
                    Instruction* inst = *it;
                    if (!instructionDefines(inst, def) || useCnt[def] > 0 || hasSideEffect(inst))
                    {
                        ++it;
                        continue;
                    }
                    delete inst;
                    it       = block->insts.erase(it);
                    removed  = true;
                }
            }

            if (!removed) break;
            changed = true;
        }
        return changed;
    }

    // -------- Mem2Reg 核心数据结构 --------
    struct VarInfo
    {
        AllocaInst*          alloca;
        DataType             dt;
        bool                 promotable;
        std::set<int>        defBlocks;
        Operand*             defaultVal;
    };

    static Operand* buildDefault(DataType dt)
    {
        switch (dt)
        {
            case DataType::F32: return getImmeF32Operand(0.0f);
            case DataType::I1:
            case DataType::I32:
            case DataType::I64:
            case DataType::PTR:
            default: return getImmeI32Operand(0);
        }
    }

    static std::map<size_t, VarInfo> collectPromotableVars(Function& func, const std::map<Operand*, size_t>& ptr2var)
    {
        std::map<size_t, VarInfo> vars;

        // 先收集所有可候选的 Alloca
        for (auto& [bid, block] : func.blocks)
        {
            for (auto* inst : block->insts)
            {
                auto* alloc = dynamic_cast<AllocaInst*>(inst);
                if (!alloc) continue;
                if (!alloc->dims.empty()) continue;  // 数组不提升

                size_t reg = alloc->res->getRegNum();
                VarInfo info;
                info.alloca     = alloc;
                info.dt         = alloc->dt;
                info.promotable = true;
                info.defaultVal = buildDefault(alloc->dt);
                vars[reg]       = info;
            }
        }

        // 检查所有使用，判定是否可提升，并收集 defBlocks
        for (auto& [bid, block] : func.blocks)
        {
            for (auto* inst : block->insts)
            {
                if (auto* ld = dynamic_cast<LoadInst*>(inst))
                {
                    auto it = ptr2var.find(ld->ptr);
                    if (it == ptr2var.end()) continue;
                    auto vit = vars.find(it->second);
                    if (vit != vars.end() && vit->second.promotable) { /* 合法使用，保持 promotable */ }
                    continue;
                }
                if (auto* st = dynamic_cast<StoreInst*>(inst))
                {
                    auto it = ptr2var.find(st->ptr);
                    if (it == ptr2var.end()) continue;
                    auto& info = vars[it->second];
                    info.defBlocks.insert((int)bid);
                    // 如果值本身是地址、或变量被当作值传递，简单保守处理
                    if (isRegOperand(st->val, info.alloca->res->getRegNum())) info.promotable = false;
                    continue;
                }

                // 其它指令若直接使用了该 alloca 的地址，则视为地址逃逸，不可提升
                auto banIfUse = [&](Operand* op) {
                    if (!op) return;
                    auto it = ptr2var.find(op);
                    if (it == ptr2var.end()) return;
                    vars[it->second].promotable = false;
                };

                switch (inst->opcode)
                {
                    case Operator::BR_COND:
                    {
                        auto* i = static_cast<BrCondInst*>(inst);
                        banIfUse(i->cond);
                        break;
                    }
                    case Operator::CALL:
                    {
                        auto* i = static_cast<CallInst*>(inst);
                        for (auto& [_, op] : i->args) banIfUse(op);
                        break;
                    }
                    case Operator::ADD:
                    case Operator::SUB:
                    case Operator::MUL:
                    case Operator::DIV:
                    case Operator::MOD:
                    case Operator::BITXOR:
                    case Operator::BITAND:
                    case Operator::SHL:
                    case Operator::ASHR:
                    case Operator::LSHR:
                    case Operator::FADD:
                    case Operator::FSUB:
                    case Operator::FMUL:
                    case Operator::FDIV:
                    {
                        auto* i = static_cast<ArithmeticInst*>(inst);
                        banIfUse(i->lhs);
                        banIfUse(i->rhs);
                        break;
                    }
                    case Operator::ICMP:
                    {
                        auto* i = static_cast<IcmpInst*>(inst);
                        banIfUse(i->lhs);
                        banIfUse(i->rhs);
                        break;
                    }
                    case Operator::FCMP:
                    {
                        auto* i = static_cast<FcmpInst*>(inst);
                        banIfUse(i->lhs);
                        banIfUse(i->rhs);
                        break;
                    }
                    case Operator::RET:
                    {
                        auto* i = static_cast<RetInst*>(inst);
                        banIfUse(i->res);
                        break;
                    }
                    case Operator::GETELEMENTPTR:
                    {
                        auto* i = static_cast<GEPInst*>(inst);
                        banIfUse(i->basePtr);
                        for (auto* idx : i->idxs) banIfUse(idx);
                        break;
                    }
                    case Operator::SITOFP:
                    {
                        auto* i = static_cast<SI2FPInst*>(inst);
                        banIfUse(i->src);
                        break;
                    }
                    case Operator::FPTOSI:
                    {
                        auto* i = static_cast<FP2SIInst*>(inst);
                        banIfUse(i->src);
                        break;
                    }
                    case Operator::ZEXT:
                    {
                        auto* i = static_cast<ZextInst*>(inst);
                        banIfUse(i->src);
                        break;
                    }
                    case Operator::PHI:
                    {
                        auto* i = static_cast<PhiInst*>(inst);
                        for (auto& kv : i->incomingVals) banIfUse(kv.second);
                        break;
                    }
                    default: break;
                }
            }
        }

        // 若从未有 store，则仍视为可提升，但 defBlocks 为空
        return vars;
    }

    static void insertPhiNodes(Function& func, CFG* cfg, DomInfo* domInfo,
        const std::map<Operand*, size_t>& ptr2var, std::map<size_t, VarInfo>& vars,
        std::map<size_t, std::map<size_t, PhiInst*>>& blockPhi)
    {
        auto& frontier = domInfo->getDomFrontier();
        for (auto& [vreg, info] : vars)
        {
            if (!info.promotable) continue;
            std::set<int> hasPhi;
            std::queue<int> work;
            for (int b : info.defBlocks) work.push(b);

            while (!work.empty())
            {
                int x = work.front();
                work.pop();
                if (x >= (int)frontier.size()) continue;
                for (int y : frontier[x])
                {
                    if (hasPhi.insert(y).second)
                    {
                        Operand* res = getRegOperand(func.getNewRegId());
                        auto*    phi = new PhiInst(info.dt, res);
                        cfg->id2block[y]->insts.push_front(phi);
                        blockPhi[y][vreg] = phi;
                        if (!info.defBlocks.count(y)) work.push(y);
                    }
                }
            }
        }
    }

    static void renameVariables(size_t blockId, CFG* cfg, const std::vector<std::vector<int>>& domTree,
        std::map<size_t, VarInfo>& vars, const std::map<Operand*, size_t>& ptr2var,
        std::map<size_t, std::map<size_t, PhiInst*>>& blockPhi,
        std::unordered_map<size_t, std::vector<Operand*>>& valueStack)
    {
        Block* block = cfg->id2block[blockId];
        std::map<size_t, int> pushedCount;

        // 处理本块的 phi 定义
        auto phiIt = blockPhi.find(blockId);
        if (phiIt != blockPhi.end())
        {
            for (auto& [vreg, phi] : phiIt->second)
            {
                valueStack[vreg].push_back(phi->res);
                pushedCount[vreg]++;
            }
        }

        // 指令线性扫描：store 入栈、load 用栈顶替换
        for (auto it = block->insts.begin(); it != block->insts.end();)
        {
            Instruction* inst = *it;
            bool         erased = false;

            if (auto* ld = dynamic_cast<LoadInst*>(inst))
            {
                auto vit = ptr2var.find(ld->ptr);
                if (vit != ptr2var.end())
                {
                    size_t varReg = vit->second;
                    auto   vInfo  = vars.find(varReg);
                    if (vInfo != vars.end() && vInfo->second.promotable)
                    {
                        Operand* replacement =
                            valueStack[varReg].empty() ? vInfo->second.defaultVal : valueStack[varReg].back();
                        replaceAllUses(*cfg->func, ld->res->getRegNum(), replacement);
                        delete inst;
                        it     = block->insts.erase(it);
                        erased = true;
                    }
                }
            }
            else if (auto* st = dynamic_cast<StoreInst*>(inst))
            {
                auto vit = ptr2var.find(st->ptr);
                if (vit != ptr2var.end())
                {
                    size_t varReg = vit->second;
                    auto   vInfo  = vars.find(varReg);
                    if (vInfo != vars.end() && vInfo->second.promotable)
                    {
                        valueStack[varReg].push_back(st->val);
                        pushedCount[varReg]++;
                        delete inst;
                        it     = block->insts.erase(it);
                        erased = true;
                    }
                }
            }

            if (!erased) ++it;
        }

        // 为后继的 phi 补充 incoming
        for (size_t succ : cfg->G_id[blockId])
        {
            auto succPhiIt = blockPhi.find(succ);
            if (succPhiIt == blockPhi.end()) continue;
            Operand* labelOp = getLabelOperand(blockId);
            for (auto& [vreg, phi] : succPhiIt->second)
            {
                auto& info = vars[vreg];
                Operand* incoming = valueStack[vreg].empty() ? info.defaultVal : valueStack[vreg].back();
                phi->addIncoming(incoming, labelOp);
            }
        }

        // DFS 遍历支配树
        for (int child : domTree[blockId]) renameVariables(child, cfg, domTree, vars, ptr2var, blockPhi, valueStack);

        // 出栈：撤销当前块产生的定义
        for (auto& [vreg, cnt] : pushedCount)
        {
            while (cnt-- > 0 && !valueStack[vreg].empty()) valueStack[vreg].pop_back();
        }
    }
}  // namespace

namespace ME
{
    void Mem2RegPass::runOnModule(Module& module)
    {
        for (auto* func : module.functions) runOnFunction(*func);
    }

    void Mem2RegPass::runOnFunction(Function& function)
    {
        mem2regTrace("start");
        // 1. 构建 CFG，顺带剔除不可达基本块
        auto* cfg = Analysis::AM.get<Analysis::CFG>(function);
        mem2regTrace("cfg built");

        // 2. 清理终结指令之后的不可达指令
        cleanTrailingUnreachable(function);
        mem2regTrace("clean trailing unreachable");

        // 3. 基础死代码消除：删除无 use 的 def
        removeDeadDefs(function);
        mem2regTrace("initial dce");

        // 4. 收集可提升的变量
        std::map<Operand*, size_t> ptr2var;
        for (auto& [bid, block] : function.blocks)
            for (auto* inst : block->insts)
                if (auto* alloca = dynamic_cast<AllocaInst*>(inst))
                    if (alloca->dims.empty()) ptr2var[alloca->res] = alloca->res->getRegNum();

        auto vars = collectPromotableVars(function, ptr2var);
        mem2regTrace("collect vars done");
        if (vars.empty()) return;

        // 5. 支配信息，用于插入 phi 与重命名
        auto* domInfo = Analysis::AM.get<Analysis::DomInfo>(function);
        mem2regTrace("dom info ready");

        // 6. 插入 phi
        std::map<size_t, std::map<size_t, PhiInst*>> blockPhi;
        insertPhiNodes(function, cfg, domInfo, ptr2var, vars, blockPhi);
        mem2regTrace("phi inserted");

        // 7. 重命名变量为 SSA
        std::unordered_map<size_t, std::vector<Operand*>> valueStack;
        const auto& domTree = domInfo->getDomTree();
        if (!domTree.empty()) renameVariables(0, cfg, domTree, vars, ptr2var, blockPhi, valueStack);
        mem2regTrace("rename done");

        // 8. 删除已提升变量的 alloca
        for (auto it = cfg->id2block[0]->insts.begin(); it != cfg->id2block[0]->insts.end();)
        {
            auto* inst = *it;
            auto* alloc = dynamic_cast<AllocaInst*>(inst);
            if (alloc && vars.count(alloc->res->getRegNum()) && vars[alloc->res->getRegNum()].promotable)
            {
                delete inst;
                it = cfg->id2block[0]->insts.erase(it);
            }
            else
            {
                ++it;
            }
        }
        mem2regTrace("alloca removed");

        // 9. 再做一遍 DCE，清理被替换后无用的指令 / phi
        removeDeadDefs(function);
        mem2regTrace("final dce");

        // 10. CFG、DomInfo 失效
        Analysis::AM.invalidate(function);
        mem2regTrace("finish");
    }
}  // namespace ME
