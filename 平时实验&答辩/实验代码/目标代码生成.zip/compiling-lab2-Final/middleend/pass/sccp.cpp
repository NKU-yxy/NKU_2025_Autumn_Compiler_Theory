#include <middleend/pass/sccp.h>
#include <middleend/pass/analysis/analysis_manager.h>
#include <middleend/pass/analysis/cfg.h>
#include <middleend/module/ir_module.h>
#include <middleend/module/ir_block.h>
#include <middleend/module/ir_function.h>
#include <middleend/module/ir_instruction.h>
#include <middleend/module/ir_operand.h>
#include <utils/debug.h>
#include <cmath>
#include <deque>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace
{
    using namespace ME;
    using namespace ME::Analysis;

    enum class LatticeKind
    {
        UNDEF,
        CONST,
        OVERDEF
    };

    struct LatticeVal
    {
        LatticeKind kind = LatticeKind::UNDEF;
        bool        isFloat{};
        double      fVal{};
        long long   iVal{};
    };

    static bool isConst(const LatticeVal& v) { return v.kind == LatticeKind::CONST; }
    static bool isOverdef(const LatticeVal& v) { return v.kind == LatticeKind::OVERDEF; }

    static bool latticeEqual(const LatticeVal& a, const LatticeVal& b)
    {
        if (a.kind != b.kind) return false;
        if (a.kind != LatticeKind::CONST) return true;
        if (a.isFloat != b.isFloat) return false;
        if (a.isFloat) return fabs(a.fVal - b.fVal) < 1e-6;
        return a.iVal == b.iVal;
    }

    static LatticeVal join(const LatticeVal& oldv, const LatticeVal& newv)
    {
        if (oldv.kind == LatticeKind::OVERDEF || newv.kind == LatticeKind::OVERDEF) return {LatticeKind::OVERDEF};
        if (oldv.kind == LatticeKind::UNDEF) return newv;
        if (newv.kind == LatticeKind::UNDEF) return oldv;
        if (oldv.kind == LatticeKind::CONST && newv.kind == LatticeKind::CONST)
        {
            if (oldv.isFloat != newv.isFloat) return {LatticeKind::OVERDEF};
            if (oldv.isFloat)
            {
                if (fabs(oldv.fVal - newv.fVal) < 1e-6) return oldv;
                return {LatticeKind::OVERDEF};
            }
            if (oldv.iVal == newv.iVal) return oldv;
            return {LatticeKind::OVERDEF};
        }
        return {LatticeKind::OVERDEF};
    }

    static LatticeVal constInt(long long v)
    {
        LatticeVal r;
        r.kind   = LatticeKind::CONST;
        r.isFloat = false;
        r.iVal    = v;
        return r;
    }

    static LatticeVal constFloat(double v)
    {
        LatticeVal r;
        r.kind    = LatticeKind::CONST;
        r.isFloat = true;
        r.fVal    = v;
        return r;
    }

    static LatticeVal getOperandVal(Operand* op, std::unordered_map<size_t, LatticeVal>& state)
    {
        if (!op) return {LatticeKind::UNDEF};

        switch (op->getType())
        {
            case OperandType::IMMEI32:
            {
                auto* imm = static_cast<ImmeI32Operand*>(op);
                return constInt(imm->value);
            }
            case OperandType::IMMEF32:
            {
                auto* imm = static_cast<ImmeF32Operand*>(op);
                return constFloat(imm->value);
            }
            case OperandType::REG:
            {
                size_t reg = op->getRegNum();
                if (state.count(reg)) return state[reg];
                return {LatticeKind::UNDEF};
            }
            default: return {LatticeKind::OVERDEF};
        }
    }

    static bool instructionDefines(Instruction* inst, size_t& def, DataType& ty)
    {
        def = 0;
        switch (inst->opcode)
        {
            case Operator::ADD:
            case Operator::SUB:
            case Operator::MUL:
            case Operator::DIV:
            case Operator::MOD:
            case Operator::BITXOR:
            case Operator::BITAND:
            case Operator::SHL:
            case Operator::ASHR:
            case Operator::LSHR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
            {
                auto* i = static_cast<ArithmeticInst*>(inst);
                def     = i->res->getRegNum();
                ty      = i->dt;
                return true;
            }
            case Operator::ICMP:
            {
                auto* i = static_cast<IcmpInst*>(inst);
                def     = i->res->getRegNum();
                ty      = i->dt;
                return true;
            }
            case Operator::FCMP:
            {
                auto* i = static_cast<FcmpInst*>(inst);
                def     = i->res->getRegNum();
                ty      = i->dt;
                return true;
            }
            case Operator::SITOFP:
            {
                auto* i = static_cast<SI2FPInst*>(inst);
                def     = i->dest->getRegNum();
                ty      = DataType::F32;
                return true;
            }
            case Operator::FPTOSI:
            {
                auto* i = static_cast<FP2SIInst*>(inst);
                def     = i->dest->getRegNum();
                ty      = DataType::I32;
                return true;
            }
            case Operator::ZEXT:
            {
                auto* i = static_cast<ZextInst*>(inst);
                def     = i->dest->getRegNum();
                ty      = i->to;
                return true;
            }
            case Operator::PHI:
            {
                auto* i = static_cast<PhiInst*>(inst);
                def     = i->res->getRegNum();
                ty      = i->dt;
                return true;
            }
            case Operator::LOAD:
            {
                auto* i = static_cast<LoadInst*>(inst);
                def     = i->res->getRegNum();
                ty      = i->dt;
                return true;
            }
            case Operator::GETELEMENTPTR:
            {
                auto* i = static_cast<GEPInst*>(inst);
                def     = i->res->getRegNum();
                ty      = DataType::PTR;
                return true;
            }
            case Operator::CALL:
            {
                auto* i = static_cast<CallInst*>(inst);
                if (!i->res) return false;
                def = i->res->getRegNum();
                ty  = i->retType;
                return true;
            }
            default: return false;
        }
    }

    static bool replaceOperand(Operand*& op, size_t from, Operand* to)
    {
        if (!op) return false;
        if (op->getType() == OperandType::REG && op->getRegNum() == from)
        {
            op = to;
            return true;
        }
        return false;
    }

    static void replaceAllUses(Function& func, size_t fromReg, Operand* to)
    {
        if (!to) return;
        for (auto& [bid, block] : func.blocks)
        {
            for (auto* inst : block->insts)
            {
                switch (inst->opcode)
                {
                    case Operator::LOAD:
                    {
                        auto* i = static_cast<LoadInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        break;
                    }
                    case Operator::STORE:
                    {
                        auto* i = static_cast<StoreInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        replaceOperand(i->val, fromReg, to);
                        break;
                    }
                    case Operator::ADD:
                    case Operator::SUB:
                    case Operator::MUL:
                    case Operator::DIV:
                    case Operator::MOD:
                    case Operator::BITXOR:
                    case Operator::BITAND:
                    case Operator::SHL:
                    case Operator::ASHR:
                    case Operator::LSHR:
                    case Operator::FADD:
                    case Operator::FSUB:
                    case Operator::FMUL:
                    case Operator::FDIV:
                    {
                        auto* i = static_cast<ArithmeticInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::ICMP:
                    {
                        auto* i = static_cast<IcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::FCMP:
                    {
                        auto* i = static_cast<FcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::BR_COND:
                    {
                        auto* i = static_cast<BrCondInst*>(inst);
                        replaceOperand(i->cond, fromReg, to);
                        break;
                    }
                    case Operator::CALL:
                    {
                        auto* i = static_cast<CallInst*>(inst);
                        for (auto& [_, op] : i->args) replaceOperand(op, fromReg, to);
                        break;
                    }
                    case Operator::RET:
                    {
                        auto* i = static_cast<RetInst*>(inst);
                        replaceOperand(i->res, fromReg, to);
                        break;
                    }
                    case Operator::GETELEMENTPTR:
                    {
                        auto* i = static_cast<GEPInst*>(inst);
                        replaceOperand(i->basePtr, fromReg, to);
                        for (auto& idx : i->idxs) replaceOperand(idx, fromReg, to);
                        break;
                    }
                    case Operator::SITOFP:
                    {
                        auto* i = static_cast<SI2FPInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::FPTOSI:
                    {
                        auto* i = static_cast<FP2SIInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::ZEXT:
                    {
                        auto* i = static_cast<ZextInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::PHI:
                    {
                        auto* i = static_cast<PhiInst*>(inst);
                        for (auto& kv : i->incomingVals) replaceOperand(kv.second, fromReg, to);
                        break;
                    }
                    default: break;
                }
            }
        }
    }

    static bool removeDeadDefs(Function& func)
    {
        bool changed = false;
        while (true)
        {
            std::unordered_map<size_t, int> useCnt;
            auto addUse = [&](Operand* op) {
                if (!op) return;
                if (op->getType() != OperandType::REG) return;
                useCnt[op->getRegNum()]++;
            };

            for (auto& [bid, block] : func.blocks)
            {
                for (auto* inst : block->insts)
                {
                    switch (inst->opcode)
                    {
                        case Operator::LOAD:
                        {
                            auto* i = static_cast<LoadInst*>(inst);
                            addUse(i->ptr);
                            break;
                        }
                        case Operator::STORE:
                        {
                            auto* i = static_cast<StoreInst*>(inst);
                            addUse(i->ptr);
                            addUse(i->val);
                            break;
                        }
                        case Operator::ADD:
                        case Operator::SUB:
                        case Operator::MUL:
                        case Operator::DIV:
                        case Operator::MOD:
                        case Operator::BITXOR:
                        case Operator::BITAND:
                        case Operator::SHL:
                        case Operator::ASHR:
                        case Operator::LSHR:
                        case Operator::FADD:
                        case Operator::FSUB:
                        case Operator::FMUL:
                        case Operator::FDIV:
                        {
                            auto* i = static_cast<ArithmeticInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::ICMP:
                        {
                            auto* i = static_cast<IcmpInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::FCMP:
                        {
                            auto* i = static_cast<FcmpInst*>(inst);
                            addUse(i->lhs);
                            addUse(i->rhs);
                            break;
                        }
                        case Operator::BR_COND:
                        {
                            auto* i = static_cast<BrCondInst*>(inst);
                            addUse(i->cond);
                            break;
                        }
                        case Operator::CALL:
                        {
                            auto* i = static_cast<CallInst*>(inst);
                            for (auto& [_, op] : i->args) addUse(op);
                            break;
                        }
                        case Operator::RET:
                        {
                            auto* i = static_cast<RetInst*>(inst);
                            addUse(i->res);
                            break;
                        }
                        case Operator::GETELEMENTPTR:
                        {
                            auto* i = static_cast<GEPInst*>(inst);
                            addUse(i->basePtr);
                            for (auto* idx : i->idxs) addUse(idx);
                            break;
                        }
                        case Operator::SITOFP:
                        {
                            auto* i = static_cast<SI2FPInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::FPTOSI:
                        {
                            auto* i = static_cast<FP2SIInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::ZEXT:
                        {
                            auto* i = static_cast<ZextInst*>(inst);
                            addUse(i->src);
                            break;
                        }
                        case Operator::PHI:
                        {
                            auto* i = static_cast<PhiInst*>(inst);
                            for (auto& kv : i->incomingVals) addUse(kv.second);
                            break;
                        }
                        default: break;
                    }
                }
            }

            bool removed = false;
            for (auto& [bid, block] : func.blocks)
            {
                for (auto it = block->insts.begin(); it != block->insts.end();)
                {
                    size_t    def = 0;
                    DataType  ty;
                    auto*     inst = *it;
                    bool      defInst = instructionDefines(inst, def, ty);
                    bool      hasUse  = defInst && useCnt[def] > 0;
                    bool      sideEffect =
                        inst->opcode == Operator::CALL || inst->opcode == Operator::STORE || inst->isTerminator();
                    if (!defInst || hasUse || sideEffect)
                    {
                        ++it;
                        continue;
                    }
                    delete inst;
                    it      = block->insts.erase(it);
                    removed = true;
                }
            }
            if (!removed) break;
            changed = true;
        }
        return changed;
    }

    static void removeUnreachableBlocks(Function& func, const std::vector<bool>& executable)
    {
        std::vector<size_t> deadBlocks;
        for (auto& [bid, block] : func.blocks)
        {
            if (bid >= executable.size() || !executable[bid]) deadBlocks.push_back(bid);
        }
        if (deadBlocks.empty()) return;

        std::unordered_set<size_t> deadSet(deadBlocks.begin(), deadBlocks.end());

        for (auto& [bid, block] : func.blocks)
        {
            if (deadSet.count(bid)) continue;
            for (auto* inst : block->insts)
            {
                auto* phi = dynamic_cast<PhiInst*>(inst);
                if (!phi) continue;
                for (auto it = phi->incomingVals.begin(); it != phi->incomingVals.end();)
                {
                    auto* label = static_cast<LabelOperand*>(it->first);
                    if (deadSet.count(label->lnum))
                        it = phi->incomingVals.erase(it);
                    else
                        ++it;
                }
            }
        }

        for (size_t bid : deadBlocks)
        {
            auto it = func.blocks.find(bid);
            if (it == func.blocks.end()) continue;
            delete it->second;
            func.blocks.erase(it);
        }
    }

    static LatticeVal evalBinary(Operator op, DataType dt, const LatticeVal& lhs, const LatticeVal& rhs)
    {
        if (isOverdef(lhs) || isOverdef(rhs)) return {LatticeKind::OVERDEF};
        if (!isConst(lhs) || !isConst(rhs)) return {LatticeKind::UNDEF};

        if (dt == DataType::F32)
        {
            double a = lhs.isFloat ? lhs.fVal : lhs.iVal;
            double b = rhs.isFloat ? rhs.fVal : rhs.iVal;
            switch (op)
            {
                case Operator::FADD: return constFloat(a + b);
                case Operator::FSUB: return constFloat(a - b);
                case Operator::FMUL: return constFloat(a * b);
                case Operator::FDIV:
                    if (fabs(b) < 1e-6) return {LatticeKind::OVERDEF};
                    return constFloat(a / b);
                default: return {LatticeKind::OVERDEF};
            }
        }
        else
        {
            long long a = lhs.isFloat ? (long long)lhs.fVal : lhs.iVal;
            long long b = rhs.isFloat ? (long long)rhs.fVal : rhs.iVal;
            long long res = 0;

            if (op == Operator::LSHR && dt == DataType::I32)
            {
                unsigned int ua = (unsigned int)a;
                res             = ua >> b;
            }
            else
            {
                switch (op)
                {
                    case Operator::ADD: res = a + b; break;
                    case Operator::SUB: res = a - b; break;
                    case Operator::MUL: res = a * b; break;
                    case Operator::DIV:
                        if (b == 0) return {LatticeKind::OVERDEF};
                        res = a / b;
                        break;
                    case Operator::MOD:
                        if (b == 0) return {LatticeKind::OVERDEF};
                        res = a % b;
                        break;
                    case Operator::BITXOR: res = a ^ b; break;
                    case Operator::BITAND: res = a & b; break;
                    case Operator::SHL: res = a << b; break;
                    case Operator::ASHR: res = a >> b; break;
                    case Operator::LSHR: res = (unsigned long long)a >> b; break;
                    default: return {LatticeKind::OVERDEF};
                }
            }

            if (dt == DataType::I32)
            {
                res = (int)res;
            }
            return constInt(res);
        }
    }

    static LatticeVal evalCmp(ICmpOp cond, const LatticeVal& lhs, const LatticeVal& rhs)
    {
        if (isOverdef(lhs) || isOverdef(rhs)) return {LatticeKind::OVERDEF};
        if (!isConst(lhs) || !isConst(rhs)) return {LatticeKind::UNDEF};
        long long a = lhs.isFloat ? (long long)lhs.fVal : lhs.iVal;
        long long b = rhs.isFloat ? (long long)rhs.fVal : rhs.iVal;
        bool      res = false;
        switch (cond)
        {
            case ICmpOp::EQ: res = (a == b); break;
            case ICmpOp::NE: res = (a != b); break;
            case ICmpOp::SGT: res = (a > b); break;
            case ICmpOp::SGE: res = (a >= b); break;
            case ICmpOp::SLT: res = (a < b); break;
            case ICmpOp::SLE: res = (a <= b); break;
            default: res = false; break;
        }
        return constInt(res ? 1 : 0);
    }

    static LatticeVal evalFCmp(FCmpOp cond, const LatticeVal& lhs, const LatticeVal& rhs)
    {
        if (isOverdef(lhs) || isOverdef(rhs)) return {LatticeKind::OVERDEF};
        if (!isConst(lhs) || !isConst(rhs)) return {LatticeKind::UNDEF};
        double a = lhs.isFloat ? lhs.fVal : lhs.iVal;
        double b = rhs.isFloat ? rhs.fVal : rhs.iVal;
        bool   res = false;
        switch (cond)
        {
            case FCmpOp::OEQ: res = (fabs(a - b) < 1e-6); break;
            case FCmpOp::OGT: res = (a > b); break;
            case FCmpOp::OGE: res = (a >= b); break;
            case FCmpOp::OLT: res = (a < b); break;
            case FCmpOp::OLE: res = (a <= b); break;
            case FCmpOp::ONE: res = (fabs(a - b) > 1e-6); break;
            default: res = false; break;
        }
        return constInt(res ? 1 : 0);
    }
}  // namespace

namespace ME
{
    void SCCPPass::runOnModule(Module& module)
    {
        for (auto* func : module.functions) runOnFunction(*func);
    }

    void SCCPPass::runOnFunction(Function& function)
    {
        auto* cfg = Analysis::AM.get<Analysis::CFG>(function);

        size_t maxId = cfg->G_id.size();
        std::vector<bool> executable(maxId, false);
        if (!cfg->G_id.empty()) executable[0] = true;

        std::unordered_map<size_t, LatticeVal> state;
        std::unordered_map<size_t, DataType>   regType;

        if (function.funcDef)
        {
            for (auto& pair : function.funcDef->argRegs)
            {
                Operand* op = pair.second;
                if (op->getType() == OperandType::REG)
                {
                    size_t reg   = op->getRegNum();
                    state[reg]   = {LatticeKind::OVERDEF};
                    regType[reg] = pair.first;
                }
            }
        }

        bool changed = true;
        while (changed)
        {
            changed     = false;
            bool newExec = false;

            for (auto& [bid, block] : cfg->id2block)
            {
                if (bid >= executable.size() || !executable[bid]) continue;

                for (auto* inst : block->insts)
                {
                    // 控制流可达性更新
                    if (auto* brc = dynamic_cast<BrCondInst*>(inst))
                    {
                        auto condVal = getOperandVal(brc->cond, state);
                        bool goTrue  = true;
                        bool goFalse = true;
                        if (isConst(condVal))
                        {
                            bool c = condVal.isFloat ? (condVal.fVal != 0.0) : (condVal.iVal != 0);
                            goTrue  = c;
                            goFalse = !c;
                        }
                        if (goTrue && brc->trueTar->getType() == OperandType::LABEL)
                        {
                            size_t tid = static_cast<LabelOperand*>(brc->trueTar)->lnum;
                            if (tid < executable.size() && !executable[tid])
                            {
                                executable[tid] = true;
                                newExec         = true;
                            }
                        }
                        if (goFalse && brc->falseTar->getType() == OperandType::LABEL)
                        {
                            size_t fid = static_cast<LabelOperand*>(brc->falseTar)->lnum;
                            if (fid < executable.size() && !executable[fid])
                            {
                                executable[fid] = true;
                                newExec         = true;
                            }
                        }
                    }
                    else if (auto* bru = dynamic_cast<BrUncondInst*>(inst))
                    {
                        if (bru->target->getType() == OperandType::LABEL)
                        {
                            size_t tid = static_cast<LabelOperand*>(bru->target)->lnum;
                            if (tid < executable.size() && !executable[tid])
                            {
                                executable[tid] = true;
                                newExec         = true;
                            }
                        }
                    }

                    size_t  def = 0;
                    DataType ty;
                    if (!instructionDefines(inst, def, ty)) continue;
                    regType[def] = ty;

                    LatticeVal oldVal = state[def];
                    LatticeVal newVal{LatticeKind::UNDEF};

                    switch (inst->opcode)
                    {
                        case Operator::ADD:
                        case Operator::SUB:
                        case Operator::MUL:
                        case Operator::DIV:
                        case Operator::MOD:
                        case Operator::BITXOR:
                        case Operator::BITAND:
                        case Operator::SHL:
                        case Operator::ASHR:
                        case Operator::LSHR:
                        case Operator::FADD:
                        case Operator::FSUB:
                        case Operator::FMUL:
                        case Operator::FDIV:
                        {
                            auto* i = static_cast<ArithmeticInst*>(inst);
                            auto  lhs = getOperandVal(i->lhs, state);
                            auto  rhs = getOperandVal(i->rhs, state);
                            newVal    = evalBinary(inst->opcode, i->dt, lhs, rhs);
                            break;
                        }
                        case Operator::ICMP:
                        {
                            auto* i = static_cast<IcmpInst*>(inst);
                            auto  lhs = getOperandVal(i->lhs, state);
                            auto  rhs = getOperandVal(i->rhs, state);
                            newVal    = evalCmp(i->cond, lhs, rhs);
                            break;
                        }
                        case Operator::FCMP:
                        {
                            auto* i = static_cast<FcmpInst*>(inst);
                            auto  lhs = getOperandVal(i->lhs, state);
                            auto  rhs = getOperandVal(i->rhs, state);
                            newVal    = evalFCmp(i->cond, lhs, rhs);
                            break;
                        }
                        case Operator::SITOFP:
                        {
                            auto* i = static_cast<SI2FPInst*>(inst);
                            auto  v = getOperandVal(i->src, state);
                            if (isConst(v))
                                newVal = constFloat(static_cast<float>(v.isFloat ? v.fVal : v.iVal));
                            else if (isOverdef(v))
                                newVal = {LatticeKind::OVERDEF};
                            break;
                        }
                        case Operator::FPTOSI:
                        {
                            auto* i = static_cast<FP2SIInst*>(inst);
                            auto  v = getOperandVal(i->src, state);
                            if (isConst(v))
                                newVal = constInt(static_cast<int>(v.isFloat ? v.fVal : v.iVal));
                            else if (isOverdef(v))
                                newVal = {LatticeKind::OVERDEF};
                            break;
                        }
                        case Operator::ZEXT:
                        {
                            auto* i = static_cast<ZextInst*>(inst);
                            auto  v = getOperandVal(i->src, state);
                            if (isConst(v))
                                newVal = constInt(v.isFloat ? (long long)v.fVal : v.iVal);
                            else if (isOverdef(v))
                                newVal = {LatticeKind::OVERDEF};
                            break;
                        }
                        case Operator::PHI:
                        {
                            auto* i = static_cast<PhiInst*>(inst);
                            bool       hasVal = false;
                            LatticeVal acc{LatticeKind::UNDEF};
                            for (auto& kv : i->incomingVals)
                            {
                                auto* lbl = static_cast<LabelOperand*>(kv.first);
                                size_t predId = lbl->lnum;
                                if (predId >= executable.size() || !executable[predId]) continue;
                                auto v = getOperandVal(kv.second, state);
                                if (!hasVal)
                                {
                                    acc    = v;
                                    hasVal = true;
                                }
                                else
                                {
                                    acc = join(acc, v);
                                }
                            }
                            newVal = acc;
                            break;
                        }
                        default:
                        {
                            // 对于访存/调用等，保守设为 OVERDEF
                            newVal = {LatticeKind::OVERDEF};
                            break;
                        }
                    }

                    LatticeVal merged = join(oldVal, newVal);
                    if (!latticeEqual(merged, oldVal))
                    {
                        state[def] = merged;
                        changed    = true;
                    }
                }
            }
            changed = changed || newExec;
        }

        // 常量替换与分支折叠
        for (auto& [reg, val] : state)
        {
            if (!isConst(val)) continue;
            Operand* repl = nullptr;
            DataType ty   = regType.count(reg) ? regType[reg] : DataType::I32;
            if (ty == DataType::F32)
                repl = getImmeF32Operand((float)(val.isFloat ? val.fVal : val.iVal));
            else
                repl = getImmeI32Operand((int)(val.isFloat ? val.fVal : val.iVal));
            replaceAllUses(function, reg, repl);
        }

        for (auto& [bid, block] : cfg->id2block)
        {
            for (auto it = block->insts.begin(); it != block->insts.end(); ++it)
            {
                auto* inst = *it;
                if (auto* brc = dynamic_cast<BrCondInst*>(inst))
                {
                    auto condVal = getOperandVal(brc->cond, state);
                    if (isConst(condVal))
                    {
                        bool         c      = condVal.isFloat ? (condVal.fVal != 0.0) : (condVal.iVal != 0);
                        Operand*     target = c ? brc->trueTar : brc->falseTar;
                        Operand*     drop   = c ? brc->falseTar : brc->trueTar;

                        // Drop the incoming edge from this block in the untaken successor's phi nodes
                        if (drop && drop->getType() == OperandType::LABEL)
                        {
                            size_t dropId = static_cast<LabelOperand*>(drop)->lnum;
                            auto   blkIt  = cfg->id2block.find(dropId);
                            if (blkIt != cfg->id2block.end())
                            {
                                for (auto* phiInst : blkIt->second->insts)
                                {
                                    auto* phi = dynamic_cast<PhiInst*>(phiInst);
                                    if (!phi) break;  // phi nodes are expected to be clustered at the top
                                    for (auto inIt = phi->incomingVals.begin(); inIt != phi->incomingVals.end();)
                                    {
                                        auto* lbl = static_cast<LabelOperand*>(inIt->first);
                                        if (lbl->lnum == bid)
                                            inIt = phi->incomingVals.erase(inIt);
                                        else
                                            ++inIt;
                                    }
                                }
                            }
                        }

                        auto* nue = new BrUncondInst(target);
                        *it        = nue;
                        delete inst;
                    }
                }
            }
        }

        removeUnreachableBlocks(function, executable);
        removeDeadDefs(function);
        Analysis::AM.invalidate(function);
    }
}  // namespace ME
