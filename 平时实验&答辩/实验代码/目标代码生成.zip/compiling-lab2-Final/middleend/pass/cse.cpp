#include <middleend/pass/cse.h>
#include <middleend/module/ir_module.h>
#include <middleend/module/ir_block.h>
#include <middleend/module/ir_function.h>
#include <middleend/module/ir_instruction.h>
#include <middleend/module/ir_operand.h>
#include <utils/debug.h>
#include <deque>
#include <map>
#include <sstream>
#include <unordered_map>

namespace
{
    using namespace ME;

    static bool replaceOperand(Operand*& op, size_t from, Operand* to)
    {
        if (!op) return false;
        if (op->getType() == OperandType::REG && op->getRegNum() == from)
        {
            op = to;
            return true;
        }
        return false;
    }

    static void replaceAllUses(Function& func, size_t fromReg, Operand* to)
    {
        if (!to) return;
        for (auto& [bid, block] : func.blocks)
        {
            for (auto* inst : block->insts)
            {
                switch (inst->opcode)
                {
                    case Operator::LOAD:
                    {
                        auto* i = static_cast<LoadInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        break;
                    }
                    case Operator::STORE:
                    {
                        auto* i = static_cast<StoreInst*>(inst);
                        replaceOperand(i->ptr, fromReg, to);
                        replaceOperand(i->val, fromReg, to);
                        break;
                    }
                    case Operator::ADD:
                    case Operator::SUB:
                    case Operator::MUL:
                    case Operator::DIV:
                    case Operator::MOD:
                    case Operator::BITXOR:
                    case Operator::BITAND:
                    case Operator::SHL:
                    case Operator::ASHR:
                    case Operator::LSHR:
                    case Operator::FADD:
                    case Operator::FSUB:
                    case Operator::FMUL:
                    case Operator::FDIV:
                    {
                        auto* i = static_cast<ArithmeticInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::ICMP:
                    {
                        auto* i = static_cast<IcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::FCMP:
                    {
                        auto* i = static_cast<FcmpInst*>(inst);
                        replaceOperand(i->lhs, fromReg, to);
                        replaceOperand(i->rhs, fromReg, to);
                        break;
                    }
                    case Operator::BR_COND:
                    {
                        auto* i = static_cast<BrCondInst*>(inst);
                        replaceOperand(i->cond, fromReg, to);
                        break;
                    }
                    case Operator::CALL:
                    {
                        auto* i = static_cast<CallInst*>(inst);
                        for (auto& [_, op] : i->args) replaceOperand(op, fromReg, to);
                        break;
                    }
                    case Operator::RET:
                    {
                        auto* i = static_cast<RetInst*>(inst);
                        replaceOperand(i->res, fromReg, to);
                        break;
                    }
                    case Operator::GETELEMENTPTR:
                    {
                        auto* i = static_cast<GEPInst*>(inst);
                        replaceOperand(i->basePtr, fromReg, to);
                        for (auto& idx : i->idxs) replaceOperand(idx, fromReg, to);
                        break;
                    }
                    case Operator::SITOFP:
                    {
                        auto* i = static_cast<SI2FPInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::FPTOSI:
                    {
                        auto* i = static_cast<FP2SIInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::ZEXT:
                    {
                        auto* i = static_cast<ZextInst*>(inst);
                        replaceOperand(i->src, fromReg, to);
                        break;
                    }
                    case Operator::PHI:
                    {
                        auto* i = static_cast<PhiInst*>(inst);
                        for (auto& kv : i->incomingVals) replaceOperand(kv.second, fromReg, to);
                        break;
                    }
                    default: break;
                }
            }
        }
    }

    static bool isCommutative(Operator op)
    {
        switch (op)
        {
            case Operator::ADD:
            case Operator::MUL:
            case Operator::BITAND:
            case Operator::BITXOR:
            case Operator::FADD:
            case Operator::FMUL: return true;
            default: return false;
        }
    }

    static std::string operandRepr(Operand* op)
    {
        if (!op) return "_";
        switch (op->getType())
        {
            case OperandType::REG: return "r" + std::to_string(op->getRegNum());
            case OperandType::IMMEI32:
            case OperandType::IMMEF32:
            case OperandType::GLOBAL:
            case OperandType::LABEL: return op->toString();
            default: return op->toString();
        }
    }

    static std::string buildKey(Instruction* inst)
    {
        std::stringstream ss;
        ss << static_cast<int>(inst->opcode) << ":";
        switch (inst->opcode)
        {
            case Operator::ADD:
            case Operator::SUB:
            case Operator::MUL:
            case Operator::DIV:
            case Operator::MOD:
            case Operator::BITXOR:
            case Operator::BITAND:
            case Operator::SHL:
            case Operator::ASHR:
            case Operator::LSHR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
            {
                auto* i  = static_cast<ArithmeticInst*>(inst);
                auto  a1 = operandRepr(i->lhs);
                auto  a2 = operandRepr(i->rhs);
                if (isCommutative(inst->opcode) && a2 < a1) std::swap(a1, a2);
                ss << static_cast<int>(i->dt) << ":" << a1 << "," << a2;
                break;
            }
            case Operator::ICMP:
            {
                auto* i = static_cast<IcmpInst*>(inst);
                auto  a1 = operandRepr(i->lhs);
                auto  a2 = operandRepr(i->rhs);
                if (isCommutative(inst->opcode) && a2 < a1) std::swap(a1, a2);
                ss << static_cast<int>(i->cond) << ":" << a1 << "," << a2;
                break;
            }
            case Operator::FCMP:
            {
                auto* i = static_cast<FcmpInst*>(inst);
                auto  a1 = operandRepr(i->lhs);
                auto  a2 = operandRepr(i->rhs);
                if (isCommutative(inst->opcode) && a2 < a1) std::swap(a1, a2);
                ss << static_cast<int>(i->cond) << ":" << a1 << "," << a2;
                break;
            }
            case Operator::SITOFP:
            {
                auto* i = static_cast<SI2FPInst*>(inst);
                ss << operandRepr(i->src) << "->f";
                break;
            }
            case Operator::FPTOSI:
            {
                auto* i = static_cast<FP2SIInst*>(inst);
                ss << operandRepr(i->src) << "->i";
                break;
            }
            case Operator::ZEXT:
            {
                auto* i = static_cast<ZextInst*>(inst);
                ss << operandRepr(i->src) << "->" << static_cast<int>(i->to);
                break;
            }
            default: break;
        }
        return ss.str();
    }

    static bool instructionDefines(Instruction* inst, size_t& def)
    {
        def = 0;
        switch (inst->opcode)
        {
            case Operator::ADD:
            case Operator::SUB:
            case Operator::MUL:
            case Operator::DIV:
            case Operator::MOD:
            case Operator::BITXOR:
            case Operator::BITAND:
            case Operator::SHL:
            case Operator::ASHR:
            case Operator::LSHR:
            case Operator::FADD:
            case Operator::FSUB:
            case Operator::FMUL:
            case Operator::FDIV:
                def = static_cast<ArithmeticInst*>(inst)->res->getRegNum();
                return true;
            case Operator::ICMP:
                def = static_cast<IcmpInst*>(inst)->res->getRegNum();
                return true;
            case Operator::FCMP:
                def = static_cast<FcmpInst*>(inst)->res->getRegNum();
                return true;
            case Operator::SITOFP:
                def = static_cast<SI2FPInst*>(inst)->dest->getRegNum();
                return true;
            case Operator::FPTOSI:
                def = static_cast<FP2SIInst*>(inst)->dest->getRegNum();
                return true;
            case Operator::ZEXT:
                def = static_cast<ZextInst*>(inst)->dest->getRegNum();
                return true;
            default: return false;
        }
    }

    static bool hasSideEffect(Instruction* inst)
    {
        switch (inst->opcode)
        {
            case Operator::STORE:
            case Operator::CALL:
            case Operator::BR_COND:
            case Operator::BR_UNCOND:
            case Operator::RET: return true;
            default: return false;
        }
    }
}  // namespace

namespace ME
{
    void CSEPass::runOnModule(Module& module)
    {
        for (auto* func : module.functions) runOnFunction(*func);
    }

    void CSEPass::runOnFunction(Function& function)
    {
        for (auto& [bid, block] : function.blocks)
        {
            std::map<std::string, size_t> expr2reg;
            for (auto it = block->insts.begin(); it != block->insts.end();)
            {
                Instruction* inst = *it;

                if (hasSideEffect(inst))
                {
                    expr2reg.clear();
                    ++it;
                    continue;
                }

                size_t def = 0;
                if (!instructionDefines(inst, def))
                {
                    ++it;
                    continue;
                }

                std::string key = buildKey(inst);
                auto        existed = expr2reg.find(key);
                if (existed != expr2reg.end())
                {
                    Operand* repl = getRegOperand(existed->second);
                    replaceAllUses(function, def, repl);
                    delete inst;
                    it = block->insts.erase(it);
                    continue;
                }
                expr2reg[key] = def;
                ++it;
            }
        }
    }
}  // namespace ME
