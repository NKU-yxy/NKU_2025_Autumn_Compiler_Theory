#ifndef __MIDDLEEND_PASS_SCCP_H__
#define __MIDDLEEND_PASS_SCCP_H__

#include <interfaces/middleend/pass.h>

namespace ME
{
    // 稀疏条件常量传播（标量）
    class SCCPPass : public ModulePass
    {
      public:
        SCCPPass()  = default;
        ~SCCPPass() = default;

        void runOnModule(Module& module) override;
        void runOnFunction(Function& function) override;
    };
}  // namespace ME

#endif  // __MIDDLEEND_PASS_SCCP_H__
