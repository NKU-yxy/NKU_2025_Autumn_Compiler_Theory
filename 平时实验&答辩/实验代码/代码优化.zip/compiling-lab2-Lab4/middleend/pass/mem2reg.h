#ifndef __MIDDLEEND_PASS_MEM2REG_H__
#define __MIDDLEEND_PASS_MEM2REG_H__

#include <interfaces/middleend/pass.h>

namespace ME
{
    class Mem2RegPass : public ModulePass
    {
      public:
        Mem2RegPass()  = default;
        ~Mem2RegPass() = default;

        void runOnModule(Module& module) override;
        void runOnFunction(Function& function) override;
    };
}  // namespace ME

#endif  // __MIDDLEEND_PASS_MEM2REG_H__
