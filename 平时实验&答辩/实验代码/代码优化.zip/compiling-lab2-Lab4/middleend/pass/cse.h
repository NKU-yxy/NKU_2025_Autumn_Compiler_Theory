#ifndef __MIDDLEEND_PASS_CSE_H__
#define __MIDDLEEND_PASS_CSE_H__

#include <interfaces/middleend/pass.h>

namespace ME
{
    // 标量公共子表达式消除（块内 GVN-lite）
    class CSEPass : public ModulePass
    {
      public:
        CSEPass()  = default;
        ~CSEPass() = default;

        void runOnModule(Module& module) override;
        void runOnFunction(Function& function) override;
    };
}  // namespace ME

#endif  // __MIDDLEEND_PASS_CSE_H__
