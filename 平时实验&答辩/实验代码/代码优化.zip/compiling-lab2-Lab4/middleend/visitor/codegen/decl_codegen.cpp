#include <middleend/visitor/codegen/ast_codegen.h>
#include <debug.h>

namespace ME
{
    void ASTCodeGen::visit(FE::AST::Initializer& node, Module* m)
    {
        (void)m;
        ERROR("Initializer should not appear here, at line %d", node.line_num);
    }
    void ASTCodeGen::visit(FE::AST::InitializerList& node, Module* m)
    {
        (void)m;
        ERROR("InitializerList should not appear here, at line %d", node.line_num);
    }
    void ASTCodeGen::visit(FE::AST::VarDeclarator& node, Module* m)
    {
        (void)m;
        ERROR("VarDeclarator should not appear here, at line %d", node.line_num);
    }
    void ASTCodeGen::visit(FE::AST::ParamDeclarator& node, Module* m)
    {
        (void)m;
        ERROR("ParamDeclarator should not appear here, at line %d", node.line_num);
    }

    // 把 Initializer / InitializerList 里的表达式按行优先拍扁到 flat 里
    static void flattenInitDecl(FE::AST::InitDecl* idecl,
                                std::vector<FE::AST::ExprNode*>& flat);

    static void flattenInitList(FE::AST::InitializerList* list,
                                std::vector<FE::AST::ExprNode*>& flat)
    {
        using namespace FE::AST;
        if (!list || !list->init_list) return;

        for (auto* sub : *list->init_list)
        {
            if (!sub) continue;
            flattenInitDecl(sub, flat);  // 递归处理子 InitDecl
        }
    }

    static void flattenInitDecl(FE::AST::InitDecl* idecl,
                                std::vector<FE::AST::ExprNode*>& flat)
    {
        using namespace FE::AST;
        if (!idecl) return;

        // 1) 单个表达式初始化：Initializer
        if (auto* init = dynamic_cast<Initializer*>(idecl))
        {
            if (!init->init_val) return;

            // 可能是嵌套列表，也可能是表达式
            if (auto* subList = dynamic_cast<InitializerList*>(init->init_val))
            {
                flattenInitList(subList, flat);
            }
            else if (auto* expr = dynamic_cast<ExprNode*>(init->init_val))
            {
                flat.push_back(expr);
            }
            return;
        }

        // 2) 列表初始化：InitializerList
        if (auto* list = dynamic_cast<InitializerList*>(idecl))
        {
            flattenInitList(list, flat);
            return;
        }

        // 其它情况（理论上不会出现），直接忽略
    }


        // 把 InitDecl（Initializer / InitializerList）里的表达式按行优先拍扁到 flat 里
        static void flattenInitExpr(FE::AST::InitDecl* idecl,
                                    std::vector<FE::AST::ExprNode*>& flat)
        {
            using namespace FE::AST;
            if (!idecl) return;

            // 1) 形如：Initializer { expr } / { { ... }, ... }
            if (auto* init = dynamic_cast<Initializer*>(idecl))
            {
                if (!init->init_val) return;

                // 1.1 里面还是一个列表：继续递归
                if (auto* subList = dynamic_cast<InitializerList*>(init->init_val))
                {
                    if (!subList->init_list) return;
                    for (auto* sub : *subList->init_list)
                    {
                        if (!sub) continue;
                        flattenInitExpr(sub, flat);
                    }
                }
                // 1.2 里面就是一个普通表达式：收集到 flat
                else if (auto* expr = dynamic_cast<ExprNode*>(init->init_val))
                {
                    flat.push_back(expr);
                }
                return;
            }

            // 2) 形如：InitializerList { init1, init2, ... }
            if (auto* list = dynamic_cast<InitializerList*>(idecl))
            {
                if (!list->init_list) return;
                for (auto* sub : *list->init_list)
                {
                    if (!sub) continue;
                    flattenInitExpr(sub, flat);
                }
                return;
            }

            // 其它情况忽略
        }




    // 帮助函数：从 InitDecl 里抽出一个“标量表达式”（忽略更深层括号）
    // 用在一维、二维数组初始化中
    static FE::AST::ExprNode* extractScalarExpr(FE::AST::InitDecl* idecl)
    {
        using namespace FE::AST;
        if (!idecl) return nullptr;

        // 1) 单个初始化器：Initializer
        if (auto* init = dynamic_cast<Initializer*>(idecl))
        {
            if (!init->init_val) return nullptr;

            // 1.1 直接是表达式
            if (auto* e = dynamic_cast<ExprNode*>(init->init_val))
                return e;

            // 1.2 是一层子列表 { ... }，取第一个元素继续递归
            if (auto* subList = dynamic_cast<InitializerList*>(init->init_val))
            {
                if (!subList->init_list || subList->init_list->empty())
                    return nullptr;
                return extractScalarExpr((*subList->init_list)[0]);
            }

            return nullptr;
        }

        // 2) 直接是列表：InitializerList
        if (auto* list = dynamic_cast<InitializerList*>(idecl))
        {
            if (!list->init_list || list->init_list->empty())
                return nullptr;
            return extractScalarExpr((*list->init_list)[0]);
        }

        return nullptr;
    }

    // TODO(Lab 3-2): 生成变量声明 IR（alloca、数组零初始化、可选初始化表达式）
    void ASTCodeGen::visit(FE::AST::VarDeclaration& node, Module* m)
    {
        (void)m;
        using namespace FE;

        if (!node.decls) return;
        ASSERT(curFunc && curBlock && "VarDeclaration must be inside a function");

        // 函数入口基本块（统一在这里放 alloca）
        Block* entryBlock = curFunc->getBlock(0);
        ASSERT(entryBlock && "Function entry block not found");

        // 变量的基础类型（元素类型）
        AST::Type* at = node.type;
        DataType   dt = convert(at);
        ASSERT((dt == DataType::I32 || dt == DataType::F32) &&
            "locals must be int/float-based in current phase");

        for (auto* decl : *node.decls)
        {
            if (!decl) continue;

            auto* lval = dynamic_cast<AST::LeftValExpr*>(decl->lval);
            ASSERT(lval && "VarDeclarator lval must be LeftValExpr");

            Sym::Entry* entry = lval->entry;
            ASSERT(entry && "VarDeclarator must have symbol entry");

            // ===== 1) 取数组各维度大小 =====
            std::vector<int> dims;
            if (lval->indices && !lval->indices->empty())
            {
                dims.reserve(lval->indices->size());
                for (auto* dimExpr : *lval->indices)
                {
                    if (!dimExpr) continue;
                    int dsz = dimExpr->attr.val.value.getInt();
                    dims.push_back(dsz);
                }
                if (!dims.empty())
                {
                    localArrayDims[entry] = dims;
                }
            }

            // ===== 2) alloca：插到函数入口块 =====
            size_t      ptrReg = getNewRegId();
            AllocaInst* alloc  = nullptr;

            if (dims.empty())
            {
                alloc = createAllocaInst(dt, ptrReg);
            }
            else
            {
                alloc = createAllocaInst(dt, ptrReg, dims);
            }
            entryBlock->insts.push_front(alloc);
            name2reg.addSymbol(entry, ptrReg);
            symbolTypes[entry] = dt;

            // ===== 3) 没有初始化器：保持未定义即可 =====
            if (!decl->init) continue;

            // ===== 4) 标量初始化（保持原逻辑） =====
            if (dims.empty())
            {
                auto* init = dynamic_cast<AST::Initializer*>(decl->init);
                ASSERT(init && "scalar var must use scalar initializer");
                auto* exprNode = dynamic_cast<AST::ExprNode*>(init->init_val);
                ASSERT(exprNode && "scalar initializer must be an expression");

                apply(*this, *exprNode, m);
                size_t   valReg  = getMaxReg();
                DataType rhsType = convert(exprNode->attr.val.value.type);
                if (rhsType != dt)
                {
                    auto convInsts = createTypeConvertInst(rhsType, dt, valReg);
                    for (auto* inst : convInsts) insert(inst);
                    valReg = getMaxReg();
                }

                Operand*   ptrOp = getRegOperand(ptrReg);
                StoreInst* st    = createStoreInst(dt, valReg, ptrOp);
                insert(st);
                continue;
            }

            // ===== 5) 数组初始化：统一先把整块数组清 0 =====
            auto storeZeroAtIndex = [&](const std::vector<int>& idxVec)
            {
                // idxVec = {i0, i1, ...}，生成 GEP(0, i0, i1, ...)
                std::vector<Operand*> gepIdx;
                gepIdx.push_back(getImmeI32Operand(0));
                for (int idx : idxVec)
                    gepIdx.push_back(getImmeI32Operand(idx));

                Operand* base   = getRegOperand(ptrReg);
                size_t   gepReg = getNewRegId();
                GEPInst* gep    = createGEP_I32Inst(dt, base, dims, gepIdx, gepReg);
                insert(gep);

                Operand* zeroOp = (dt == DataType::F32)
                                    ? static_cast<Operand*>(getImmeF32Operand(0.0f))
                                    : static_cast<Operand*>(getImmeI32Operand(0));
                StoreInst* st = createStoreInst(dt, zeroOp, getRegOperand(gepReg));
                insert(st);
            };

            // 目前只精确处理 1 维和 2 维数组（实验测试基本只用到这两种）
            if (dims.size() == 1)
            {
                int n = dims[0];

                // 先全 0
                for (int i = 0; i < n; ++i)
                {
                    std::vector<int> idx = {i};
                    storeZeroAtIndex(idx);
                }

                // 取顶层 initializer 序列
                using namespace FE::AST;
                std::vector<InitDecl*> items;
                if (auto* initRoot = dynamic_cast<Initializer*>(decl->init))
                {
                    if (auto* listRoot = dynamic_cast<InitializerList*>(initRoot->init_val))
                    {
                        if (listRoot->init_list)
                            for (auto* it : *listRoot->init_list) items.push_back(it);
                    }
                    else
                    {
                        items.push_back(decl->init);
                    }
                }
                else if (auto* listRoot = dynamic_cast<InitializerList*>(decl->init))
                {
                    if (listRoot->init_list)
                        for (auto* it : *listRoot->init_list) items.push_back(it);
                }

                int idx = 0;
                for (auto* item : items)
                {
                    if (idx >= n) break;
                    FE::AST::ExprNode* expr = extractScalarExpr(item);
                    if (!expr) continue;

                    // 生成 expr 并 store 到 [idx]
                    apply(*this, *expr, m);
                    size_t   valReg  = getMaxReg();
                    DataType rhsType = convert(expr->attr.val.value.type);
                    if (rhsType != dt)
                    {
                        auto convInsts = createTypeConvertInst(rhsType, dt, valReg);
                        for (auto* inst : convInsts) insert(inst);
                        valReg = getMaxReg();
                    }

                    std::vector<int> idxVec = {idx};
                    std::vector<Operand*> gepIdx;
                    gepIdx.push_back(getImmeI32Operand(0));
                    gepIdx.push_back(getImmeI32Operand(idx));

                    Operand* base   = getRegOperand(ptrReg);
                    size_t   gepReg = getNewRegId();
                    GEPInst* gep    = createGEP_I32Inst(dt, base, dims, gepIdx, gepReg);
                    insert(gep);

                    StoreInst* st = createStoreInst(dt, valReg, getRegOperand(gepReg));
                    insert(st);

                    ++idx;
                }

                continue;
            }

            // ===== 6) 重点：二维数组初始化，支持 {1,2,{3},{5},7,8} 这种 C 语义 =====
            if (dims.size() == 2)
            {
                int R = dims[0];
                int C = dims[1];

                // 先全 0
                for (int i = 0; i < R; ++i)
                {
                    for (int j = 0; j < C; ++j)
                    {
                        std::vector<int> idx = {i, j};
                        storeZeroAtIndex(idx);
                    }
                }

                using namespace FE::AST;

                // 在 (row, col) 位置写入一个标量表达式 expr
                auto storeScalarAt = [&](ExprNode* expr, int row, int col)
                {
                    if (!expr) return;

                    apply(*this, *expr, m);
                    size_t   valReg  = getMaxReg();
                    DataType rhsType = convert(expr->attr.val.value.type);
                    if (rhsType != dt)
                    {
                        auto convInsts = createTypeConvertInst(rhsType, dt, valReg);
                        for (auto* inst : convInsts) insert(inst);
                        valReg = getMaxReg();
                    }

                    std::vector<Operand*> gepIdx;
                    gepIdx.push_back(getImmeI32Operand(0));
                    gepIdx.push_back(getImmeI32Operand(row));
                    gepIdx.push_back(getImmeI32Operand(col));

                    Operand* base   = getRegOperand(ptrReg);
                    size_t   gepReg = getNewRegId();
                    GEPInst* gep    = createGEP_I32Inst(dt, base, dims, gepIdx, gepReg);
                    insert(gep);

                    StoreInst* st = createStoreInst(dt, valReg, getRegOperand(gepReg));
                    insert(st);
                };

                // 取顶层 initializer 序列：相当于 C 里的最外层大括号
                std::vector<InitDecl*> items;
                if (auto* initRoot = dynamic_cast<Initializer*>(decl->init))
                {
                    if (auto* listRoot = dynamic_cast<InitializerList*>(initRoot->init_val))
                    {
                        if (listRoot->init_list)
                            for (auto* it : *listRoot->init_list) items.push_back(it);
                    }
                    else
                    {
                        items.push_back(decl->init);
                    }
                }
                else if (auto* listRoot = dynamic_cast<InitializerList*>(decl->init))
                {
                    if (listRoot->init_list)
                        for (auto* it : *listRoot->init_list) items.push_back(it);
                }

                int row = 0, col = 0;
                for (auto* item : items)
                {
                    if (row >= R) break;

                    if (auto* init = dynamic_cast<Initializer*>(item))
                    {
                        if (!init->init_val) continue;

                        // 情况 1：顶层是子列表 { ... }，当成“一整行”的初始化
                        if (auto* subList = dynamic_cast<InitializerList*>(init->init_val))
                        {
                            if (!subList->init_list)
                            {
                                // 空子列表，整行保持 0
                                ++row;
                                col = 0;
                                continue;
                            }

                            // 从当前 (row, col) 开始为这一行写入若干元素
                            for (auto* sub : *subList->init_list)
                            {
                                if (row >= R) break;
                                if (col >= C) break;

                                ExprNode* expr = extractScalarExpr(sub);
                                if (!expr) continue;

                                storeScalarAt(expr, row, col);
                                ++col;
                            }

                            // 子列表结束：这一行的剩余列保持为 0，跳到下一行
                            ++row;
                            col = 0;
                            continue;
                        }

                        // 情况 2：顶层是单个标量
                        if (auto* e = dynamic_cast<ExprNode*>(init->init_val))
                        {
                            ExprNode* expr = e;
                            storeScalarAt(expr, row, col);
                            ++col;
                            if (col >= C)
                            {
                                col = 0;
                                ++row;
                            }
                            continue;
                        }

                        // 其它情况忽略
                        continue;
                    }
                    else if (auto* list = dynamic_cast<InitializerList*>(item))
                    {
                        // 顶层直接是列表：也当成“一整行”
                        if (!list->init_list)
                        {
                            ++row;
                            col = 0;
                            continue;
                        }

                        for (auto* sub : *list->init_list)
                        {
                            if (row >= R) break;
                            if (col >= C) break;

                            ExprNode* expr = extractScalarExpr(sub);
                            if (!expr) continue;

                            storeScalarAt(expr, row, col);
                            ++col;
                        }

                        ++row;
                        col = 0;
                        continue;
                    }
                }

                // 剩余没被初始化到的行/列保持 0（前面已经全 0 过）
                continue;
            }

            // ===== 7) 其他维度（>2）：通用多维数组初始化（带调试信息） =====
            if (dims.size() > 2)
            {
                int k     = static_cast<int>(dims.size());
                int total = 1;
                for (int dsz : dims) total *= dsz;

                // 行优先 stride：最右维变化最快
                std::vector<int> stride(k, 1);
                for (int i = k - 2; i >= 0; --i)
                {
                    stride[i] = stride[i + 1] * dims[i + 1];
                }

                // DEBUG：打印当前局部数组的形状
                fprintf(stderr,
                        "[DBG-3D] local array name=%s, dims=%zu (",
                        entry->getName().c_str(),
                        dims.size());
                for (size_t di = 0; di < dims.size(); ++di)
                {
                    fprintf(stderr, "%d%s", dims[di], (di + 1 < dims.size() ? "x" : ""));
                }
                fprintf(stderr, "), total=%d\n", total);

                // 1) 整块先清 0（未指定初始化项全为 0）
                for (int linear = 0; linear < total; ++linear)
                {
                    int tmp = linear;
                    std::vector<int> idxVec(k);
                    for (int dim = 0; dim < k; ++dim)
                    {
                        int idx = tmp / stride[dim];
                        tmp     = tmp % stride[dim];
                        idxVec[dim] = idx;
                    }
                    storeZeroAtIndex(idxVec);
                }

                using namespace FE::AST;

                // 2) 顶层 initializer 序列：对应第一维上的每一个“块”
                std::vector<InitDecl*> groups;
                if (auto* initRoot = dynamic_cast<Initializer*>(decl->init))
                {
                    if (auto* listRoot = dynamic_cast<InitializerList*>(initRoot->init_val))
                    {
                        if (listRoot->init_list)
                        {
                            for (auto* it : *listRoot->init_list)
                                groups.push_back(it);
                        }
                    }
                    else
                    {
                        // 形如：int a[...]=expr; 整个数组看作一个块
                        groups.push_back(decl->init);
                    }
                }
                else if (auto* listRoot = dynamic_cast<InitializerList*>(decl->init))
                {
                    if (listRoot->init_list)
                    {
                        for (auto* it : *listRoot->init_list)
                            groups.push_back(it);
                    }
                }

                int D0      = dims[0];  // 第一维长度
                int blockSz = 1;        // 每个“块”占用的线性长度
                for (size_t di = 1; di < dims.size(); ++di)
                    blockSz *= dims[di];

                fprintf(stderr,
                        "[DBG-3D] groups=%zu, D0=%d, blockSz=%d\n",
                        groups.size(), D0, blockSz);

                // 3) 对每个“块”分别 flatten，再映射到该块的线性区间 [g*blockSz, (g+1)*blockSz)
                for (int g = 0; g < D0 && g < (int)groups.size(); ++g)
                {
                    InitDecl* gInit = groups[g];
                    if (!gInit) continue;

                    std::vector<ExprNode*> flat;
                    flattenInitExpr(gInit, flat);  // 只拍扁这个块内部的花括号

                    fprintf(stderr,
                            "[DBG-3D] group %d: flatSize=%zu\n",
                            g, flat.size());
                    for (size_t i = 0; i < flat.size(); ++i)
                    {
                        auto* e = flat[i];
                        if (!e)
                        {
                            fprintf(stderr, "  [g=%d] flat[%zu] = <null>\n", g, i);
                            continue;
                        }
                        auto& vinfo = e->attr.val;
                        if (vinfo.isConstexpr)
                        {
                            fprintf(stderr,
                                    "  [g=%d] flat[%zu]: constexpr int=%d (line=%d)\n",
                                    g, i, vinfo.value.getInt(), e->line_num);
                        }
                        else
                        {
                            fprintf(stderr,
                                    "  [g=%d] flat[%zu]: non-constexpr (line=%d)\n",
                                    g, i, e->line_num);
                        }
                    }

                    int maxInBlock =
                        (flat.size() < (size_t)blockSz)
                            ? (int)flat.size()
                            : blockSz;

                    for (int t = 0; t < maxInBlock; ++t)
                    {
                        ExprNode* expr = flat[t];
                        if (!expr) continue;

                        // 生成 expr 的值
                        apply(*this, *expr, m);
                        size_t   valReg  = getMaxReg();
                        DataType rhsType = convert(expr->attr.val.value.type);
                        if (rhsType != dt)
                        {
                            auto convInsts = createTypeConvertInst(rhsType, dt, valReg);
                            for (auto* inst : convInsts) insert(inst);
                            valReg = getMaxReg();
                        }

                        // 线性下标 = 块起始 + t
                        int linear = g * blockSz + t;
                        if (linear >= total) break;

                        // linear → 多维下标 idxVec（行优先）
                        int tmp = linear;
                        std::vector<int> idxVec(k);
                        for (int dim = 0; dim < k; ++dim)
                        {
                            int idx = tmp / stride[dim];
                            tmp     = tmp % stride[dim];
                            idxVec[dim] = idx;
                        }

                        fprintf(stderr,
                                "[DBG-3D] write g=%d, t=%d, linear=%d -> (",
                                g, t, linear);
                        for (int dim = 0; dim < k; ++dim)
                        {
                            fprintf(stderr, "%d%s",
                                    idxVec[dim],
                                    (dim + 1 < k ? "," : ""));
                        }
                        fprintf(stderr, ")\n");

                        // GEP(0, i0, i1, ..., ik-1)
                        std::vector<Operand*> gepIdx;
                        gepIdx.push_back(getImmeI32Operand(0));
                        for (int idx : idxVec)
                            gepIdx.push_back(getImmeI32Operand(idx));

                        Operand* base   = getRegOperand(ptrReg);
                        size_t   gepReg = getNewRegId();
                        GEPInst* gep    = createGEP_I32Inst(dt, base, dims, gepIdx,gepReg);
                        insert(gep);

                        StoreInst* st = createStoreInst(dt, valReg, getRegOperand(gepReg));
                        insert(st);
                    }
                }

                // 剩余没被显式初始化到的位置保持 0
                continue;  // dims.size() > 2 处理完毕
            }



        }
    }

}  // namespace ME
