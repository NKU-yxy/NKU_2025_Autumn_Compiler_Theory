#include <middleend/visitor/codegen/ast_codegen.h>

namespace ME
{

    // DEBUG 使用
    static long long DBG_visit_LeftVal   = 0;
    static long long DBG_visit_Binary   = 0;
    static long long DBG_handle_Assign  = 0;

    void ASTCodeGen::visit(FE::AST::LeftValExpr& node, Module* m)
    {
        (void)m;

        // DEBUG 计数
        ++DBG_visit_LeftVal;
        if (DBG_visit_LeftVal == 1 ||
            DBG_visit_LeftVal == 1000 ||
            DBG_visit_LeftVal == 100000 ||
            DBG_visit_LeftVal % 1000000 == 0)
        {
            fprintf(stderr, "[DBG] LeftValExpr visits = %lld\n", DBG_visit_LeftVal);
        }

        // 基本健壮性检查
        ASSERT(node.entry && "LeftValExpr with null entry");
        FE::Sym::Entry* entry = node.entry;

        size_t regLocal = name2reg.getReg(entry);
        bool   isLocal  = (regLocal != static_cast<size_t>(-1));
        bool   isGlobal = (glbSymbols.find(entry) != glbSymbols.end());
        if (!isLocal && !isGlobal)
        {
            ERROR("CodeGen LeftValExpr: symbol not found in name2reg or glbSymbols");
        }

        ASSERT(curFunc && curBlock && "LeftValExpr: curFunc/curBlock is null");

        // 额外：是否是形参
        bool isParam = (paramSymbols.find(entry) != paramSymbols.end());

        // 先拿到维度信息（局部数组 / 形参数组 / 全局数组）
        std::vector<int> dims;
        if (isLocal)
        {
            if (isParam)
            {
                auto itP = paramArrayDims.find(entry);
                if (itP != paramArrayDims.end()) dims = itP->second;
            }
            else
            {
                auto itL = localArrayDims.find(entry);
                if (itL != localArrayDims.end()) dims = itL->second;
            }
        }
        if (dims.empty() && isGlobal)
        {
            auto itG = glbSymbols.find(entry);
            if (itG != glbSymbols.end()) dims = itG->second.arrayDims;
        }
        // 丢弃缺省/非法维度（如形参首维省略）
        while (!dims.empty() && dims.front() <= 0) dims.erase(dims.begin());

        // 形参是否按指针传递（含数组形参）
        bool isPointerLike = pointerParams.find(entry) != pointerParams.end();

        // ========= 0. 元素类型（用于 GEP 和 load） =========
        FE::AST::Type* astTy = node.attr.val.value.type;  // 一般是元素类型（int / float 等）
        DataType       valTy = convert(astTy);
        if (valTy == DataType::VOID)
        {
            valTy = DataType::I32;  // 兜底
        }

        // 修正：如果符号表里记录了存储类型，且当前是标量访问，则优先使用存储类型
        if (entry && symbolTypes.count(entry))
        {
            DataType storedTy = symbolTypes[entry];
            if (storedTy != DataType::PTR) 
            {
                bool isScalarAccess = true;
                if (!dims.empty()) {
                    if (!node.indices || node.indices->size() != dims.size()) {
                        isScalarAccess = false;
                    }
                }
                
                if (isScalarAccess) {
                    valTy = storedTy;
                }
            }
        }

        // ========= 1. 基础地址 =========
        Operand* addrOp = nullptr;
        if (isLocal)
        {
            addrOp = getRegOperand(regLocal);
        }
        else
        {
            addrOp = getGlobalOperand(entry->getName());
        }

        // 形参指针：先 load 出真实地址
        if (isPointerLike && isLocal)
        {
            size_t ptrReg = getNewRegId();
            auto*  ldPtr  = createLoadInst(DataType::PTR, addrOp, ptrReg);
            insert(ldPtr);
            addrOp = getRegOperand(ptrReg);
        }

        // ========= 2. 数组下标（生成 GEP） =========
        if (node.indices && !node.indices->empty())
        {
            std::vector<Operand*> gepIndices;

            // 真正的数组对象（非指针形参）需要在 GEP 前加一个 0
            if (!dims.empty() && !isPointerLike)
            {
                gepIndices.push_back(getImmeI32Operand(0));
            }

            // 2.4 依次处理每个下标表达式
            for (auto* indexExpr : *node.indices)
            {
                if (!indexExpr) continue;
                apply(*this, *indexExpr, m);
                size_t indexReg = getMaxReg();
                gepIndices.push_back(getRegOperand(indexReg));
            }

            // 2.5 生成 GEP
            size_t  gepReg = getNewRegId();
            GEPInst* gep   = createGEP_I32Inst(valTy, addrOp, dims, gepIndices, gepReg);
            insert(gep);
            addrOp = getRegOperand(gepReg);
        }

        // 保存“这个 LeftValExpr 对应的地址”，后续赋值用
        lval2ptr[&node] = addrOp;

        // ========= 3. 作为右值使用：load 出值 =========
        size_t resReg = getNewRegId();
        auto*  load   = createLoadInst(valTy, addrOp, resReg);
        insert(load);

        // 记录结果寄存器的类型信息
        FE::AST::VarAttr vAttr;
        vAttr.type       = astTy;
        reg2attr[resReg] = vAttr;
    }


    void ASTCodeGen::visit(FE::AST::LiteralExpr& node, Module* m)
    {
        (void)m;

        size_t reg = getNewRegId();
        // Use the semantic-checked type from attr instead of the raw literal type
        // This ensures type conversions (e.g., int 0 -> float) are respected
        FE::AST::Type* typeToUse = node.attr.val.value.type;
        if (!typeToUse)
        {
            // Fallback to literal type if attr is not set
            typeToUse = node.literal.type;
        }
        
        switch (typeToUse->getBaseType())
        {
            case FE::AST::Type_t::INT:
            case FE::AST::Type_t::LL:  // treat as I32
            {
                int             val  = node.literal.getInt();
                ArithmeticInst* inst = createArithmeticI32Inst_ImmeAll(Operator::ADD, val, 0, reg);  // reg = val + 0
                insert(inst);
                break;
            }
            case FE::AST::Type_t::FLOAT:
            {
                float           val  = node.literal.getFloat();
                // If literal is int but needs to be float, convert it
                if (node.literal.type->getBaseType() == FE::AST::Type_t::INT || 
                    node.literal.type->getBaseType() == FE::AST::Type_t::LL)
                {
                    // Convert int literal to float
                    float fVal = static_cast<float>(node.literal.getInt());
                    ArithmeticInst* inst = createArithmeticF32Inst_ImmeAll(Operator::FADD, fVal, 0.0f, reg);
                    insert(inst);
                }
                else
                {
                    ArithmeticInst* inst = createArithmeticF32Inst_ImmeAll(Operator::FADD, val, 0, reg);  // reg = val + 0
                    insert(inst);
                }
                break;
            }
            default: ERROR("Unsupported literal type");
        }
    }

    void ASTCodeGen::visit(FE::AST::UnaryExpr& node, Module* m)
    {
        handleUnaryCalc(*node.expr, node.op, curBlock, m);
    }

    void ASTCodeGen::handleAssign(FE::AST::LeftValExpr& lhs, FE::AST::ExprNode& rhs, Module* m)
    {
        using namespace FE::AST;
        (void)m;

        // DEBUG 使用
        ++DBG_handle_Assign;
        if (DBG_handle_Assign <= 20 ||
            DBG_handle_Assign == 100 ||
            DBG_handle_Assign == 1000 ||
            DBG_handle_Assign % 10000 == 0)
        {
            fprintf(stderr, "[DBG] handleAssign #%lld\n", DBG_handle_Assign);
        }

        // 1. 先算右值 rhs
        apply(*this, rhs, m);
        size_t   rhsReg  = getMaxReg();
        DataType rhsType = convert(rhs.attr.val.value.type);

        // 2. 再处理左值 lhs，目的是把地址填进 lval2ptr
        apply(*this, lhs, m);

        auto it = lval2ptr.find(&lhs);
        ASSERT(it != lval2ptr.end() && "LeftValExpr has no stored pointer in lval2ptr");
        Operand* ptr = it->second;  // 变量的地址（alloca 出来的指针）

        // 3. 左值类型
        DataType lhsType = convert(lhs.attr.val.value.type);

        // 4. 必要时把 rhs 转成 lhs 的类型
        if (rhsType != lhsType)
        {
            auto convInsts = createTypeConvertInst(rhsType, lhsType, rhsReg);
            for (auto* inst : convInsts)
                insert(inst);       // insert() 用当前 curBlock
            rhsReg  = getMaxReg();
            rhsType = lhsType;
        }

        // 5. 生成 store 指令：*ptr = rhsReg
        StoreInst* store = createStoreInst(lhsType, rhsReg, ptr);
        insert(store);
    }
    // 短路求值：如果对于and 有一个假就不再计算后面的表达式；对于or 有一个真就不再计算后面的表达式
    // 基本块block:一段“没有跳转中断、顺序执行的指令序列”，以跳转指令（br / ret）结束。

    void ASTCodeGen::handleLogicalAnd(FE::AST::BinaryExpr& node,
                                  FE::AST::ExprNode& lhs,
                                  FE::AST::ExprNode& rhs,
                                  Module* m)
    {
        // DEBUG 使用
        ++DBG_visit_Binary;
        if (DBG_visit_Binary == 1 ||
            DBG_visit_Binary == 1000 ||
            DBG_visit_Binary == 100000 ||
            DBG_visit_Binary % 1000000 == 0)
        {
            fprintf(stderr, "[DBG] BinaryExpr visits = %lld\n", DBG_visit_Binary);
        }

        // 1) 在当前块里算 lhs
        // 在当前基本块 curBlock 里，把左子表达式 lhs 先算出来，结果放在某个寄存器
        apply(*this, lhs, m);
        // 记录“计算完 lhs 的那个块”，之后的跳转都从这块发出
        Block* lhsBlock = curBlock;
        // 当前最新的寄存器就是 lhs 的结果寄存器
        size_t lhsReg   = getMaxReg();
        DataType lhsTy  = convert(lhs.attr.val.value.type);
        // 如果 lhs 不是 i1（比如是 int / float），用 createTypeConvertInst(lhsTy, I1, lhsReg) 把它转成 i1
        // 把转换指令直接插到 lhsBlock 末尾
        if (lhsTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(lhsTy, DataType::I1, lhsReg);
            for (auto* inst : convInsts) lhsBlock->insert(inst);
            lhsReg = getMaxReg();
        }

        // 2) 创建 rhs 块 和 end 块
        Block* rhsBlock = createBlock();
        Block* endBlock = createBlock();

        // lhsBlock：lhs 为真 -> rhsBlock；为假 -> 直接到 endBlock
        lhsBlock->insert(createBranchInst(lhsReg, rhsBlock->blockId, endBlock->blockId));

        // 3) 在 rhsBlock 里计算 rhs（只有 lhs 为真时才会执行到）
        curBlock = rhsBlock;
        apply(*this, rhs, m);
        Block* rhsEndBlock = curBlock;  // 注意：rhs 可能自己创建了新的块

        size_t   rhsReg  = getMaxReg();
        DataType rhsTy   = convert(rhs.attr.val.value.type);
        if (rhsTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(rhsTy, DataType::I1, rhsReg);
            for (auto* inst : convInsts) rhsEndBlock->insert(inst);
            rhsReg = getMaxReg();
        }

        // 从 rhs 的“最终块”跳到 endBlock
        rhsEndBlock->insert(createBranchInst(endBlock->blockId));

        /*
            1.lhsBlock --(lhs 为真)--> rhsBlock ... rhsEndBlock --(无条件 br)--> endBlock
            2.lhsBlock --(lhs 为假)-----------------------> endBlock
        */

        // 4) 在 endBlock 里用 phi 合并：
        //    - 从 lhsBlock（lhs 为假直接跳到 end）：结果为 0
        //    - 从 rhsEndBlock（执行了 rhs）：结果为 rhsReg
        curBlock       = endBlock;
        size_t  resReg = getNewRegId();
        auto*   phi    = new PhiInst(DataType::I1, getRegOperand(resReg));
        // 对应上方第二条边
        phi->addIncoming(getImmeI32Operand(0), getLabelOperand(lhsBlock->blockId));
        // 对应上方第一条边
        phi->addIncoming(getRegOperand(rhsReg), getLabelOperand(rhsEndBlock->blockId));
        endBlock->insert(phi);
        regTypes[resReg] = DataType::I1;

        // 5) 如果 BinaryExpr 的目标类型不是 i1，再从 i1 转一下
        // 一般SysY会int bool混用 从int->bool时需要转换 eg. int x = (a && b);  // 期望 x 是 0 或 1
        DataType wantTy = convert(node.attr.val.value.type);
        if (wantTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(DataType::I1, wantTy, resReg);
            for (auto* inst : convInsts) endBlock->insert(inst);
        }
    }

    // 逻辑或短路求值
    void ASTCodeGen::handleLogicalOr(FE::AST::BinaryExpr& node,
                                 FE::AST::ExprNode& lhs,
                                 FE::AST::ExprNode& rhs,
                                 Module* m)
    {
        // 1) 在当前块里算 lhs
        apply(*this, lhs, m);
        Block* lhsBlock = curBlock;
        size_t lhsReg   = getMaxReg();
        DataType lhsTy  = convert(lhs.attr.val.value.type);

        if (lhsTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(lhsTy, DataType::I1, lhsReg);
            for (auto* inst : convInsts) lhsBlock->insert(inst);
            lhsReg = getMaxReg();
        }

        // 2) 创建 rhs 块 和 end 块
        Block* rhsBlock = createBlock();
        Block* endBlock = createBlock();

        // 对于 ||：lhs 为真 -> 直接短路到 end；为假 -> 去 rhs
        lhsBlock->insert(createBranchInst(lhsReg, endBlock->blockId, rhsBlock->blockId));

        // 3) 在 rhsBlock 里计算 rhs（只有 lhs 为假时才会执行到）
        curBlock = rhsBlock;
        apply(*this, rhs, m);
        Block* rhsEndBlock = curBlock;  // rhs 最终所在块

        size_t   rhsReg = getMaxReg();
        DataType rhsTy  = convert(rhs.attr.val.value.type);
        if (rhsTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(rhsTy, DataType::I1, rhsReg);
            for (auto* inst : convInsts) rhsEndBlock->insert(inst);
            rhsReg = getMaxReg();
        }

        // 从 rhsEndBlock 跳到 endBlock
        rhsEndBlock->insert(createBranchInst(endBlock->blockId));

        // 4) 在 endBlock 里用 phi 合并：
        //    - 从 lhsBlock（lhs 为真短路过来）：结果为 1
        //    - 从 rhsEndBlock（执行了 rhs）：结果为 rhsReg
        curBlock       = endBlock;
        size_t  resReg = getNewRegId();
        auto*   phi    = new PhiInst(DataType::I1, getRegOperand(resReg));
        phi->addIncoming(getImmeI32Operand(1), getLabelOperand(lhsBlock->blockId));
        phi->addIncoming(getRegOperand(rhsReg), getLabelOperand(rhsEndBlock->blockId));
        endBlock->insert(phi);
        regTypes[resReg] = DataType::I1;

        // 5) 根据 BinaryExpr 的静态类型决定是否从 i1 转成别的类型
        DataType wantTy = convert(node.attr.val.value.type);
        if (wantTy != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(DataType::I1, wantTy, resReg);
            for (auto* inst : convInsts) endBlock->insert(inst);
        }
    }

    void ASTCodeGen::visit(FE::AST::BinaryExpr& node, Module* m)
    {
        Block* originalBlock = curBlock;  // 保存原始块
        ASSERT(originalBlock && "No current block in BinaryExpr");

        auto op = node.op;

        // 赋值
        if (op == FE::AST::Operator::ASSIGN)
        {
            auto* lval = dynamic_cast<FE::AST::LeftValExpr*>(node.lhs);
            ASSERT(lval && "Left side of assignment must be a left value");
            handleAssign(*lval, *node.rhs, m);
            return;
        }

        // 逻辑与 / 或
        if (op == FE::AST::Operator::AND)
        {
            handleLogicalAnd(node, *node.lhs, *node.rhs, m);
            return;
        }
        if (op == FE::AST::Operator::OR)
        {
            handleLogicalOr(node, *node.lhs, *node.rhs, m);
            return;
        }

        // 其他算术 / 比较运算
        curBlock = originalBlock;  // 确保使用原始块
        handleBinaryCalc(*node.lhs, *node.rhs, op, originalBlock, m);
    }

    void ASTCodeGen::visit(FE::AST::CallExpr& node, Module* m)
    {
        (void)m;
        ASSERT(curFunc && curBlock && "CallExpr: curFunc/curBlock is null");

        // ---------- 1. 计算实参 ----------
        CallInst::argList     args;
        FE::AST::FuncDeclStmt* calleeDecl = nullptr;
        auto itDecl = funcDecls.find(node.func);
        if (itDecl != funcDecls.end()) calleeDecl = itDecl->second;

        size_t argIdx = 0;
        if (node.args)
        {
            for (auto* argExpr : *node.args)
            {
                if (!argExpr) continue;

                // 先按普通表达式算一遍
                apply(*this, *argExpr, m);
                size_t   argReg  = getMaxReg();
                DataType argType = convert(argExpr->attr.val.value.type);
                Operand* argOp   = getRegOperand(argReg);

                // ===== 特判：形如 exgcd(a, b, x, y) 里的“裸数组名”实参，需要退化为 int* =====
                if (auto* lval = dynamic_cast<FE::AST::LeftValExpr*>(argExpr))
                {
                    bool noIndex = (!lval->indices || lval->indices->empty());

                    // 收集数组维度（本地 / 全局 / 形参）
                    std::vector<int> dims;
                    if (lval->entry)
                    {
                        auto itG = glbSymbols.find(lval->entry);
                        if (itG != glbSymbols.end())
                        {
                            dims = itG->second.arrayDims;
                        }
                        else
                        {
                            auto itL = localArrayDims.find(lval->entry);
                            if (itL != localArrayDims.end())
                            {
                                dims = itL->second;
                            }
                            else
                            {
                                auto itP = paramArrayDims.find(lval->entry);
                                if (itP != paramArrayDims.end()) dims = itP->second;
                            }
                        }
                    }
                    while (!dims.empty() && dims.front() <= 0) dims.erase(dims.begin());

                    bool isPointerLike = (lval->entry && pointerParams.find(lval->entry) != pointerParams.end());

                    if (noIndex && lval->entry && (isPointerLike || !dims.empty()))
                    {
                        // 从 LeftValExpr 里取出“这个数组/指针实参的地址”
                        auto itPtr = lval2ptr.find(lval);
                        ASSERT(itPtr != lval2ptr.end() && "CallExpr: array arg has no ptr in lval2ptr");
                        Operand* basePtr = itPtr->second;

                        // 对真数组做一次退化 &arr[0]；指针形参直接使用原指针
                        if (!dims.empty() && !isPointerLike)
                        {
                            std::vector<Operand*> gepIdx;
                            gepIdx.push_back(getImmeI32Operand(0));
                            gepIdx.push_back(getImmeI32Operand(0));

                            size_t  gepReg = getNewRegId();
                            GEPInst* gep   = createGEP_I32Inst(DataType::I32, basePtr, dims, gepIdx, gepReg);
                            insert(gep);
                            basePtr = getRegOperand(gepReg);
                        }

                        argOp   = basePtr;
                        argType = DataType::PTR;
                    }
                    else if (lval->indices && !lval->indices->empty() && lval->entry)
                    {
                        // dims.size() = 总维数；indices.size() = 实际写的下标数
                        // 对于 c 是 2 维数组，c[0] 就是 indices.size() = 1，dims.size() = 2
                        if (!dims.empty() && dims.size() == lval->indices->size() + 1)
                        {
                            Operand* basePtr = nullptr;
                            if (isPointerLike)
                            {
                                auto itPtr = lval2ptr.find(lval);
                                ASSERT(itPtr != lval2ptr.end() && "CallExpr: param ptr not in lval2ptr");
                                basePtr = itPtr->second;
                            }
                            else
                            {
                                size_t regLocal = name2reg.getReg(lval->entry);
                                bool   isLocal  = (regLocal != static_cast<size_t>(-1));
                                basePtr         = isLocal
                                    ? static_cast<Operand*>(getRegOperand(regLocal))
                                    : static_cast<Operand*>(getGlobalOperand(lval->entry->getName()));
                            }

                            // GEP 索引：[0] + 原有各维下标 + [0]（最后一维取第 0 个元素）
                            std::vector<Operand*> gepIdx;
                            if (!isPointerLike) gepIdx.push_back(getImmeI32Operand(0));

                            for (auto* idxExpr : *lval->indices)
                            {
                                if (!idxExpr) continue;
                                apply(*this, *idxExpr, m);
                                size_t idxReg = getMaxReg();
                                gepIdx.push_back(getRegOperand(idxReg));
                            }

                            gepIdx.push_back(getImmeI32Operand(0));

                            size_t  gepReg = getNewRegId();
                            GEPInst* gep   = createGEP_I32Inst(
                                DataType::I32,  // 元素类型是 int
                                basePtr,
                                dims,
                                gepIdx,
                                gepReg);
                            insert(gep);

                            argOp   = getRegOperand(gepReg);   // &arr[i][0]
                            argType = DataType::PTR;
                        }
                    }
                }

                // 尝试按函数声明的形参类型做一次转换
                size_t              argRegId = argReg;
                RegOperand*         regOp    = dynamic_cast<RegOperand*>(argOp);
                if (regOp) argRegId = regOp->getRegNum();

                DataType expectedDt = DataType::UNK;
                if (calleeDecl && calleeDecl->params && argIdx < calleeDecl->params->size())
                {
                    auto* pDecl = (*calleeDecl->params)[argIdx];
                    if (pDecl)
                    {
                        expectedDt = convertForParam(pDecl->attr.val.value.type);
                        if (expectedDt != DataType::PTR && pDecl->dims && !pDecl->dims->empty())
                            expectedDt = DataType::PTR;
                    }
                }

                DataType actualType = argType;
                auto itRegType = regTypes.find(argRegId);
                if (itRegType != regTypes.end())
                    actualType = itRegType->second;
                else
                {
                    auto itAttr = reg2attr.find(argRegId);
                    if (itAttr != reg2attr.end() && itAttr->second.type)
                        actualType = convert(itAttr->second.type);
                }

                // DEBUG
                // fprintf(stderr, "Call arg %zu: actual=%d, expected=%d, regOp=%p\n", argIdx, (int)actualType, (int)expectedDt, regOp);

                auto isConvertible = [](DataType dt) {
                    return dt == DataType::I1 || dt == DataType::I32 || dt == DataType::F32;
                };

                if (regOp && expectedDt != DataType::UNK && actualType != expectedDt &&
                    isConvertible(actualType) && isConvertible(expectedDt))
                {
                    auto convInsts = createTypeConvertInst(actualType, expectedDt, argRegId);
                    for (auto* inst : convInsts) insert(inst);
                    argRegId = getMaxReg();
                    argOp    = getRegOperand(argRegId);
                    argType  = expectedDt;
                }

                args.emplace_back(argType, argOp);
                ++argIdx;
            }
        }


        // ---------- 2. 返回类型：直接用语义分析填好的类型 ----------
        DataType retType = convert(node.attr.val.value.type);

        // ---------- 3. 函数名 ----------
        std::string funcName;
        if (node.func)
        {
            funcName = node.func->getName();  // 按你符号表实际接口改
        }
        else
        {
            ERROR("CallExpr without func entry not supported");
        }

        // ---------- 4. 生成 call 指令 ----------
        if (retType == DataType::VOID)
        {
            // 无返回值
            CallInst* inst = createCallInst(retType, funcName, args);
            insert(inst);
        }
        else
        {
            // 有返回值
            size_t   resReg = getNewRegId();
            CallInst* inst  = createCallInst(retType, funcName, args, resReg);
            insert(inst);

            // 记录寄存器的类型属性
            FE::AST::VarAttr vAttr;
            vAttr.type          = node.attr.val.value.type;
            reg2attr[resReg]    = vAttr;
        }
    }

    void ASTCodeGen::visit(FE::AST::CommaExpr& node, Module* m)
    {
        (void)m;
        if (!node.exprs || node.exprs->empty()) return;

        // 依次求值，最后一个表达式的结果寄存器就是整个逗号表达式的结果
        for (auto* e : *node.exprs)
        {
            if (!e) continue;
            apply(*this, *e, m);
        }
    }

}  // namespace ME