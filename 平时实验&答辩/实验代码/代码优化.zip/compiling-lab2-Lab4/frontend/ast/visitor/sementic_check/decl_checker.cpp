#include <frontend/ast/visitor/sementic_check/ast_checker.h>
#include <debug.h>

namespace FE::AST
{

    // 辅助函数：把 InitDecl（Initializer / InitializerList）拍扁成一维常量列表
    static bool collectInitValues(ASTChecker& checker,
                                InitDecl*    idecl,
                                std::vector<VarValue>& out)
    {
        if (!idecl) return true;
        bool res = true;

        // 情况 1：单个初始化器：Initializer { expr }
        if (auto* ini = dynamic_cast<Initializer*>(idecl))
        {
            if (!ini->init_val) return true;

            // 确保表达式已经做过常量折叠
            res &= apply(checker, *ini->init_val);

            auto& vinfo = ini->init_val->attr.val;
            if (vinfo.isConstexpr)
            {
                out.push_back(vinfo.value);
            }
            return res;
        }

        // 情况 2：初始化列表：InitializerList { init1, init2, ... }
        if (auto* list = dynamic_cast<InitializerList*>(idecl))
        {
            if (!list->init_list) return true;

            for (auto* sub : *list->init_list)
            {
                if (!sub) continue;
                res &= collectInitValues(checker, sub, out);
            }
            return res;
        }

        return res;
    }




    bool ASTChecker::visit(Initializer& node)
    {
        // 单个初始化器：访问初始化表达式，把属性拷到自己身上
        ASSERT(node.init_val && "Null initializer value");
        bool res  = apply(*this, *node.init_val);
        node.attr = node.init_val->attr;
        return res;
    }

    bool ASTChecker::visit(InitializerList& node)
    {
        // 初始化器列表：把里面每个 Initializer 都走一遍
        if (!node.init_list) return true;
        bool res = true;
        for (auto* init : *(node.init_list))
        {
            if (!init) continue;
            res &= apply(*this, *init);
        }
        return res;
    }

    bool ASTChecker::visit(VarDeclarator& node)
    {
        // 变量声明器：主要检查初始化器
        bool res = true;

        if (node.init)
        {
            // 有初始化器，先检查初始化表达式
            res &= apply(*this, *node.init);
            // 把初始化表达式的属性拷给当前声明器，但需要处理类型
            node.attr.val.value = node.init->attr.val.value;
            node.attr.val.isConstexpr = node.init->attr.val.isConstexpr;
            
            // 重要：如果初始化表达式没有设置类型（例如空初始化列表 {}），
            // 但VarDeclaration已经设置了基础类型，则保留基础类型
            // 另外，如果初始化器是InitializerList，它不应该覆盖已设置的类型
            // 只有当初始化器的类型不是void时，才使用它
            if (!node.attr.val.value.type || node.attr.val.value.type == voidType)
            {
                // 如果初始化值类型为void或未设置，保留VarDeclaration设置的类型
                // 此时node.attr.val.value.type应该已经被VarDeclaration::visit设置过
            }
        }
        else
        {
            // 没有初始化器：不是编译期常量，没有常量值
            node.attr.val.isConstexpr = false;
            node.attr.val.value       = VarValue();
            // 类型会在 VarDeclaration 里从 node.type 传下来
        }

        return res;
    }

    bool ASTChecker::visit(ParamDeclarator& node)
    {
        // 函数形参：设置类型信息，并加入当前作用域的符号表
        bool res = true;

        // node.type 在语法分析时已经构造好，这里把它写入 attr
        node.attr.val.isConstexpr = false;
        node.attr.val.value       = VarValue();
        node.attr.val.value.type  = node.type;

        // 这里只做最基本处理：把形参加入符号表，不再做复杂的重定义检测
        // （如果以后你在 SymTable 里实现“只看当前作用域”的查重，再在这里加）
        VarAttr attr{};
        attr.isConstDecl = false;  // SysY 形参本身不是 const 声明
        attr.type        = node.type; 
        // ParamDeclarator 里没有 ident，只有 entry
        symTable.addSymbol(node.entry, attr);

        return res;
    }

    

    

    bool ASTChecker::visit(VarDeclaration& node)
    {
        // 变量/常量声明：比如
        //   int a, b = 1;
        //   const int c = 3;
        bool res = true;

        if (!node.decls) return true;

        for (auto* decl : *(node.decls))
        {
            if (!decl) continue;

            // 把基础类型先传给声明器（后面做类型检查要用）
            decl->attr.val.value.type  = node.type;
            decl->attr.val.isConstexpr = false;

            // 先检查这个声明器（主要是初始化器）
            res &= apply(*this, *decl);

            // 从 lval 里取出变量名 Entry*
            auto* lval = dynamic_cast<LeftValExpr*>(decl->lval);
            if (!lval || !lval->entry)
            {
                errors.push_back("Invalid variable declarator at line " +
                                std::to_string(node.line_num));
                res = false;
                continue;
            }

            // 初始化器不能是 void 类型的表达式（例如 int x = putint(); ）
            // 但初始化列表（如 {} 或 {1, 2, 3}）不是void表达式，即使是空的也合法
            if (decl->init)
            {
                // 只有当初始化器是真实表达式（Initializer）且为void，才报错
                // InitializerList不会是void，即使是空的 {}
                auto* initExpr = dynamic_cast<Initializer*>(decl->init);
                if (initExpr && initExpr->attr.val.value.type == voidType)
                {
                    errors.push_back("Invalid initialization from void expression at line " + std::to_string(decl->line_num));
                    res = false;
                    // 继续处理以保持符号表完整性，但该声明被视为语义错误
                    // 注意：不要 `continue`，仍需把符号加入表以免后续访问崩溃
                }
            }


            FE::Sym::Entry* ident = lval->entry;

            // 重定义检查：如果当前作用域已有该符号，则视为重定义错误
            if (symTable.hasSymbolInCurrentScope(ident))
            {
                errors.push_back("Redefinition of variable at line " + std::to_string(node.line_num));
                res = false;
                continue;
            }

            // 重新组装 VarAttr
            VarAttr attr{};
            attr.isConstDecl = node.isConstDecl;
            attr.type        = node.type; 
            // ========= 关键：从 lval->indices 收集数组维度 =========
            // 声明形式：
            //   int head[10];
            // 这里 lval->indices 里就是那几个 ConstExp
            if (lval->indices && !lval->indices->empty())
            {
                for (auto* dimExpr : *(lval->indices))
                {
                    if (!dimExpr) continue;

                    // 确保这个维度表达式做过常量折叠
                    res &= apply(*this, *dimExpr);

                    if (!dimExpr->attr.val.isConstexpr)
                    {
                        errors.push_back("Array dimension is not a constant expression at line " +
                                        std::to_string(dimExpr->line_num));
                        res = false;
                        continue;
                    }

                    int dim = dimExpr->attr.val.value.getInt();
                    attr.arrayDims.push_back(dim);
                }
            }

            /*
            // ========= 全局变量的常量初始化 =========
            if (symTable.isGlobalScope() && decl->init)
            {
                // 在 VarDeclarator::visit 里，你已经做了：
                //   node.attr.val = node.init->attr.val;
                // 所以 decl->attr.val 里已经有初始化表达式的常量信息
                const auto& vinfo = decl->attr.val;
                if (vinfo.isConstexpr)
                {
                    attr.initList.push_back(vinfo.value);
                }
                // 否则：非法的全局初始化，可以按需要报错 / 或保留为默认 0
            }
            */

            // ========= 全局变量的常量初始化（标量 + 数组） =========
            if (symTable.isGlobalScope() && decl->init)
            {
                if (attr.arrayDims.empty())
                {
                    // 标量：沿用原来的逻辑
                    const auto& vinfo = decl->attr.val;
                    if (vinfo.isConstexpr)
                    {
                        attr.initList.push_back(vinfo.value);
                    }
                }
                else
                {
                    // 数组：把初始化器（可能是嵌套花括号）拍扁成常量序列
                    std::vector<VarValue> vals;
                    collectInitValues(*this, decl->init, vals);
                    attr.initList = std::move(vals);
                }
            }

            // 对于局部 const 标量，也把编译期常量值记录到 initList 中，
            // 以便 LeftValExpr 在引用该变量时能识别为编译期常量并参与常量折叠。
            // 这能修复诸如局部 const 连锁计算后导致的除以 0 检测漏报问题。
            if (!symTable.isGlobalScope() && attr.isConstDecl && decl->attr.val.isConstexpr && attr.arrayDims.empty())
            {
                attr.initList.push_back(decl->attr.val.value);
            }


            // 加入符号表
            symTable.addSymbol(ident, attr);

            // 如果是在全局作用域，记到 glbSymbols，给 IR 生成用
            if (symTable.isGlobalScope())
            {
                glbSymbols[ident] = attr;
            }
        }

        return res;
    }


}  // namespace FE::AST
