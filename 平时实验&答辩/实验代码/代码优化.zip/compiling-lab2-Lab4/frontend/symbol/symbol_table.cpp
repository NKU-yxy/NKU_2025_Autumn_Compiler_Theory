#include <frontend/symbol/symbol_table.h>
#include <debug.h>

namespace FE::Sym
{
    // 重置符号表：清空所有作用域，只保留一个全局作用域
    void SymTable::reset_impl()
    {
        scopes.clear();
        scopes.emplace_back();  // 创建全局作用域
    }

   void SymTable::enterScope_impl()
    {
        // 如果还没 reset 过，保证至少有一个全局作用域
        if (scopes.empty())
            scopes.emplace_back();

        scopes.emplace_back();
    }

     // 退出当前作用域：弹出栈顶 Scope
    void SymTable::exitScope_impl()
    {
        // 至少保留一个全局作用域
        if (scopes.size() <= 1)
        {
            // 如果你希望在调试时严格检查，可以加 ASSERT
            // ASSERT(false && "Try to exit global scope in SymTable::exitScope_impl");
            return;
        }
        scopes.pop_back();
    }

    bool SymTable::hasSymbolInCurrentScope_impl(Entry* entry)
    {
        if (!entry) return false;
        if (scopes.empty()) return false;
        auto& cur = scopes.back();
        return cur.find(entry) != cur.end();
    }

    // 在当前作用域添加符号
    void SymTable::addSymbol_impl(Entry* entry, FE::AST::VarAttr& attr)
    {
        if (!entry) return;

        if (scopes.empty())
            scopes.emplace_back();  // 保证有一个作用域

        Scope& cur = scopes.back();

        // 这里简单覆盖旧值，重定义检查通常在 ASTChecker 中做
        cur[entry] = attr;
    }

    

    // 从当前作用域往外查找符号
    FE::AST::VarAttr* SymTable::getSymbol_impl(Entry* entry)
    {
        if (!entry) return nullptr;

        // 从最内层作用域开始向外查
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it)
        {
            auto& scope = *it;
            auto  pos   = scope.find(entry);
            if (pos != scope.end())
                return &pos->second;
        }

        return nullptr;
    }

   // 当前是否在全局作用域
    bool SymTable::isGlobalScope_impl()
    {
        // 约定：scopes[0] 是全局，size()==1 则只有全局
        return scopes.size() <= 1;
    }

    // 当前作用域深度（全局为 0，下一层为 1，依此类推）
    int SymTable::getScopeDepth_impl()
    {
        if (scopes.empty()) return 0;
        return static_cast<int>(scopes.size()) - 1;
    }
}  // namespace FE::Sym
