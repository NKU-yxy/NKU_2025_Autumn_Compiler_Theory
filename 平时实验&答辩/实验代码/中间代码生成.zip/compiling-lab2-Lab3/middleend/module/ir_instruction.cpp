#include <middleend/module/ir_instruction.h>
#include <debug.h>
#include <numeric>
#include <sstream>

namespace ME
{
    std::string LoadInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = load " << dt << ", ptr " << ptr << getComment();
        return ss.str();
    }

    std::string StoreInst::toString() const
    {
        std::stringstream ss;
        ss << "store " << dt << " " << val << ", ptr " << ptr << getComment();
        return ss.str();
    }

    std::string ArithmeticInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = " << opcode << " " << dt << " " << lhs << ", " << rhs << getComment();
        return ss.str();
    }

    std::string IcmpInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = icmp " << cond << " " << dt << " " << lhs << ", " << rhs << getComment();
        return ss.str();
    }

    std::string FcmpInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = fcmp " << cond << " " << dt << " " << lhs << ", " << rhs << getComment();
        return ss.str();
    }

    std::string AllocaInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = alloca ";
        if (dims.empty()) { ss << dt << getComment(); }
        else
        {
            for (int dim : dims) ss << "[" << dim << " x ";
            ss << dt << std::string(dims.size(), ']') << getComment();
        }
        return ss.str();
    }

    std::string BrCondInst::toString() const
    {
        std::stringstream ss;
        ss << "br i1 " << cond << ", label " << trueTar << ", label " << falseTar << getComment();
        return ss.str();
    }

    std::string BrUncondInst::toString() const
    {
        std::stringstream ss;
        ss << "br label " << target << getComment();
        return ss.str();
    }

    void initArrayGlb(
        std::ostream& s, DataType type, const FE::AST::VarAttr& v, size_t dimDph, size_t beginPos, size_t endPos)
    {
        if (dimDph == 0)
        {
            bool allZero = true;
            for (auto& initVal : v.initList)
            {
                if (initVal.type == FE::AST::boolType || initVal.type == FE::AST::intType ||
                    initVal.type == FE::AST::llType)
                {
                    int iv = initVal.getInt();
                    if (iv != 0) allZero = false;
                }
                if (initVal.type == FE::AST::floatType)
                {
                    float fv = initVal.getFloat();
                    if (fv != 0.0f) allZero = false;
                }
                if (!allZero) break;
            }

            if (allZero)
            {
                for (size_t i = 0; i < v.arrayDims.size(); ++i) s << "[" << v.arrayDims[i] << " x ";
                s << type << std::string(v.arrayDims.size(), ']') << " zeroinitializer";
                return;
            }
        }

        if (beginPos == endPos)
        {
            switch (type)
            {
                case DataType::I1:
                case DataType::I32:
                case DataType::I64: s << type << " " << v.initList[beginPos].getInt(); break;
                case DataType::F32:
                    s << type << " 0x" << std::hex << FLOAT_TO_DOUBLE_BITS(v.initList[beginPos].getFloat()) << std::dec;
                    break;
                default: ERROR("Unsupported data type in global array init");
            }
            return;
        }

        for (size_t i = dimDph; i < v.arrayDims.size(); ++i) s << "[" << v.arrayDims[i] << " x ";
        s << type << std::string(v.arrayDims.size() - dimDph, ']') << " [";

        int step = std::accumulate(v.arrayDims.begin() + dimDph + 1, v.arrayDims.end(), 1, std::multiplies<int>());
        for (int i = 0; i < v.arrayDims[dimDph]; ++i)
        {
            if (i != 0) s << ",";
            initArrayGlb(s, type, v, dimDph + 1, beginPos + i * step, beginPos + (i + 1) * step - 1);
        }

        s << "]";
    }
    /*
    std::string GlbVarDeclInst::toString() const
    {
        std::stringstream ss;
        ss << "@" << name << " = global ";
        if (initList.arrayDims.empty())
        {
            ss << dt << " ";
            if (init)
                ss << init;
            else
                ss << "zeroinitializer";
        }
        else
        {
            size_t step = 1;
            for (int dim : initList.arrayDims) step *= dim;
            initArrayGlb(ss, dt, initList, 0, 0, step - 1);
        }
        ss << getComment();
        return ss.str();
    }
    */

    std::string CallInst::toString() const
    {
        std::stringstream ss;
        if (retType != DataType::VOID) ss << res << " = ";
        ss << "call " << retType << " @" << funcName << "(";

        for (auto it = args.begin(); it != args.end(); ++it)
        {
            ss << it->first << " " << it->second;
            if (std::next(it) != args.end()) ss << ", ";
        }
        ss << ")" << getComment();
        return ss.str();
    }

    std::string RetInst::toString() const
    {
        std::stringstream ss;
        ss << "ret " << rt;
        if (res) ss << " " << res;
        ss << getComment();
        return ss.str();
    }

    std::string FuncDeclInst::toString() const
    {
        std::stringstream ss;
        ss << "declare " << retType << " @" << funcName << "(";
        for (auto it = argTypes.begin(); it != argTypes.end(); ++it)
        {
            ss << *it;
            if (std::next(it) != argTypes.end()) ss << ", ";
        }
        if (isVarArg) ss << ", ...";
        ss << ")" << getComment();
        return ss.str();
    }

    std::string FuncDefInst::toString() const
    {
        std::stringstream ss;
        ss << "define " << retType << " @" << funcName << "(";

        for (auto it = argRegs.begin(); it != argRegs.end(); ++it)
        {
            ss << it->first << " " << it->second;
            if (std::next(it) != argRegs.end()) ss << ", ";
        }
        ss << ")" << getComment();
        return ss.str();
    }

    
    std::string GEPInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = getelementptr ";
        if (dims.empty())
            ss << dt;
        else
        {
            for (int dim : dims) ss << "[" << dim << " x ";
            ss << dt << std::string(dims.size(), ']');
        }

        ss << ", ptr " << basePtr;
        for (auto& idx : idxs) ss << ", " << idxType << " " << idx;
        ss << getComment();
        return ss.str();
    }
    


    // 辅助函数 1：构造数组类型字符串，例如 dims={2,3}, elemType=i32
    // level=0 -> "[2 x [3 x i32]]"
    // level=1 -> "[3 x i32]"
    static std::string buildArrayTypeStr(DataType elemType,
                                        const std::vector<int>& dims,
                                        size_t level)
    {
        std::stringstream ts;
        for (size_t i = level; i < dims.size(); ++i)
        {
            ts << "[" << dims[i] << " x ";
        }
        ts << elemType;
        ts << std::string(dims.size() - level, ']');
        return ts.str();
    }

    // 辅助函数 2：按照 dims 形状，把一维的 initList 打印成嵌套数组初始化
    static void emitArrayInitValues(std::stringstream&                     ss,
                                    DataType                               elemType,
                                    const std::vector<int>&                dims,
                                    size_t                                 level,
                                    size_t&                                curIdx,
                                    const std::vector<FE::AST::VarValue>&  vals)
    {
        // 叶子层：真正的元素（最后一维）
        if (level + 1 == dims.size())
        {
            ss << "[";
            for (int i = 0; i < dims[level]; ++i)
            {
                if (i) ss << ", ";
                ss << elemType << " ";

                if (curIdx < vals.size())
                {
                    const auto& v = vals[curIdx++];
                    if (elemType == DataType::F32)
                        ss << v.getFloat();    // 和你 handleGlobalVarDecl 里用的一致
                    else
                        ss << v.getInt();
                }
                else
                {
                    // 不足的元素补 0
                    if (elemType == DataType::F32)
                        ss << "0.0";
                    else
                        ss << "0";
                }
            }
            ss << "]";
        }
        else
        {
            // 中间层：这一维有 dims[level] 个子数组
            std::string innerTy = buildArrayTypeStr(elemType, dims, level + 1);
            ss << "[";
            for (int i = 0; i < dims[level]; ++i)
            {
                if (i) ss << ", ";
                ss << innerTy << " ";
                emitArrayInitValues(ss, elemType, dims, level + 1, curIdx, vals);
            }
            ss << "]";
        }
    }


    std::string GlbVarDeclInst::toString() const
    {
        std::stringstream ss;
        ss << "@" << name << " = global ";

        const FE::AST::VarAttr& va = initList;   // 这里的 initList 是整份 VarAttr
        bool isArray = !va.arrayDims.empty();

        if (isArray)
        {
            // ===== 1. 打类型：[d0 x [d1 x ... dt]...] =====
            for (size_t i = 0; i < va.arrayDims.size(); ++i)
            {
                ss << "[" << va.arrayDims[i] << " x ";
            }
            ss << dt;
            ss << std::string(va.arrayDims.size(), ']');
            ss << " ";

            // ===== 2. 打初始化 =====
            if (va.initList.empty())
            {
                // 没显式初始化：全部置 0
                ss << "zeroinitializer";
            }
            else
            {
                // 有花括号初始化：按 dims 形状把一维 initList 展开
                size_t curIdx = 0;
                emitArrayInitValues(ss, dt, va.arrayDims, 0, curIdx, va.initList);
            }
        }
        else
        {
            // ===== 标量全局变量 =====
            ss << dt << " ";

            if (init)
            {
                // handleGlobalVarDecl 传进来的立即数 Operand*
                ss << init;
            }
            else if (!va.initList.empty())
            {
                // VarAttr 里记录了常量初始化
                const auto& v = va.initList[0];
                if (dt == DataType::F32)
                    ss << v.getFloat();
                else
                    ss << v.getInt();
            }
            else
            {
                // 没有初始化：SysY 语义默认 0
                if (dt == DataType::F32)
                    ss << "0.0";
                else
                    ss << "0";
            }
        }

        ss << getComment();
        return ss.str();
    }



    std::string SI2FPInst::toString() const
    {
        std::stringstream ss;
        ss << dest << " = sitofp i32 " << src << " to float" << getComment();
        return ss.str();
    }

    std::string FP2SIInst::toString() const
    {
        std::stringstream ss;
        ss << dest << " = fptosi float " << src << " to i32" << getComment();
        return ss.str();
    }

    std::string ZextInst::toString() const
    {
        std::stringstream ss;
        ss << dest << " = zext " << from << " " << src << " to " << to << getComment();
        return ss.str();
    }

    std::string PhiInst::toString() const
    {
        std::stringstream ss;
        ss << res << " = phi " << dt << " ";

        for (auto it = incomingVals.begin(); it != incomingVals.end(); ++it)
        {
            ss << "[ " << it->second << ", " << it->first << " ]";
            if (std::next(it) != incomingVals.end()) ss << ", ";
        }
        ss << getComment();
        return ss.str();
    }
}  // namespace ME
