#include <middleend/visitor/codegen/ast_codegen.h>

namespace ME
{
    /*
    // DEBUG 使用
    // static long long DBG_func_counter = 0;   // 统计生成了多少个函数的 IR
    // static long long DBG_visit_While = 0;
    // static long long DBG_visit_For   = 0;

    // 新增：运行时循环编号
    // static long long DBG_rt_loop_counter = 0;

    // 新增：当前正在生成的函数的 debug 编号（方便在循环里知道自己属于哪个函数）
    static int DBG_cur_func_id = 0;

    static long long DBG_loop_counter = 0;   // 给每个 while/for 一个唯一编号

    */



    // 小工具：当前基本块是否已经有 terminator
    static bool isBlockTerminated(Block* b)
    {
        if (!b) return true;               // 理论上不会为 null，这里兜底
        if (b->insts.empty()) return false;
        return b->insts.back()->isTerminator();
    }

    // 修复93 94
    void ASTCodeGen::visit(FE::AST::ExprStmt& node, Module* m)
    {
        if (!node.expr) return;
        apply(*this, *node.expr, m);
    }
    


   

    void ASTCodeGen::visit(FE::AST::FuncDeclStmt& node, Module* m)
    {
        localArrayDims.clear();

        paramSymbols.clear();
        if (!node.body) return;  // 仅处理有函数体的定义

        // 1. 函数返回类型
        DataType retType = convert(node.retType);

        // 2. 函数名
        ASSERT(node.entry && "FuncDeclStmt entry should not be null");
        std::string funcName = node.entry->getName();

        // DEBUG使用
        /*
        ++DBG_func_counter;
        DBG_cur_func_id = (int)DBG_func_counter;  // 记录当前函数的编号
        fprintf(stderr, "\n[DBG] ==== Begin Func #%lld: %s ====\n", DBG_func_counter, funcName.c_str());
        */
        

        // 3. 先创建函数定义（暂时不给 args），再创建 Function
        //    注意这里先给一个空的 argList，稍后在进入函数上下文后再填充
        FuncDefInst::argList emptyArgs;
        auto* funcDef = new FuncDefInst(retType, funcName, emptyArgs);
        auto* func    = new Function(funcDef);
        m->functions.emplace_back(func);

        // 4. 进入该函数上下文
        enterFunc(func);

        // 5. 创建入口基本块，并设为当前基本块
        Block* entry = func->createBlock();
        enterBlock(entry);

        
       
        // 6. 为该函数建立一个作用域（函数级）
        name2reg.enterScope();

        // 7. 现在已经有了 curFunc，可以安全地分配寄存器，构造真正的形参列表
        FuncDefInst::argList args;
        curFuncParamRegs.clear();

        if (node.params)
        {
            for (auto* p : *node.params)
            {
                if (!p) continue;

                auto* tyAst = p->attr.val.value.type;
                DataType dt = convertForParam(tyAst);  // ★ 使用参数专用转换

                auto itVarAttr = glbSymbols.find(p->entry);
                if (itVarAttr != glbSymbols.end())
                {
                    const auto& vattr = itVarAttr->second;
                    if (!vattr.arrayDims.empty())
                    {
                        dt = DataType::PTR;
                    }
                }
                // 7.1 为每个形参分配一个“值寄存器”
                size_t   argRegId = getNewRegId();      // 此时 getNewRegId 使用的 curFunc 已经非空
                Operand* argOp    = getRegOperand(argRegId);

                // 7.2 填入 FuncDefInst::argList（元素类型是 CallInst::argPair = std::pair<DataType, Operand*>）
                args.emplace_back(dt, argOp);

                // 7.3 把寄存器号记下来，稍后入口块里要用来 store 到 alloca
                curFuncParamRegs.push_back(argRegId);
            }
        }

        // 7.4 把真正的 args 写回 funcDef
        funcDef->argRegs = args;

        // 8. 在入口基本块里：为每个形参分配栈空间，保存到 alloca，并建立 name2reg 映射
        if (node.params)
        {
            for (size_t i = 0; i < node.params->size(); ++i)
            {
                auto* p = (*node.params)[i];
                if (!p || !p->entry) continue;

                auto* tyAst = p->attr.val.value.type;
                DataType dt = convertForParam(tyAst);
                
                auto itVarAttr = glbSymbols.find(p->entry);
                if (itVarAttr != glbSymbols.end())
                {
                    const auto& vattr = itVarAttr->second;
                    if (!vattr.arrayDims.empty())
                    {
                        dt = DataType::PTR;
                    }
                }// ★ 同样改这里
                // 8.1 alloca 一个局部变量
                size_t ptrReg = getNewRegId();
                insert(createAllocaInst(dt, ptrReg));

                // 8.2 把形参寄存器里的初值写进去
                size_t argRegId = curFuncParamRegs[i];
                insert(createStoreInst(dt, argRegId, getRegOperand(ptrReg)));

                // 8.3 建立符号到“栈指针寄存器”的映射，后续 LeftValExpr 访问形参就走这里
                name2reg.addSymbol(p->entry, ptrReg);
                
                // 8.4 记录：这是一个形参符号
                paramSymbols.insert(p->entry);      // ★ 新增
            }
        }

        // 9. 生成函数体 IR
        if (auto* block = dynamic_cast<FE::AST::BlockStmt*>(node.body))
        {
            apply(*this, *block, m);
        }
        else
        {
            apply(*this, *node.body, m);
        }

        // 10. 收尾：只检查"当前所在的 basic block"，如果没有 terminator 补一个 ret
        {
            Block* bb = curBlock;
            if (bb)
            {
                bool hasTerm = false;
                if (!bb->insts.empty())
                {
                    hasTerm = bb->insts.back()->isTerminator();
                }

                if (!hasTerm)
                {
                    if (retType == DataType::VOID)
                    {
                        // void 函数：补一个 ret void
                        insert(createRetInst());
                    }
                    else if (retType == DataType::F32)
                    {
                        // float 函数：补一个 ret 0.0
                        insert(createRetInst(0.0f));
                    }
                    else
                    {
                        // 非 void 函数：防御性补一个 ret 0
                        insert(createRetInst(0));
                    }
                }
            }
        }

        // 11. 退出函数作用域和当前块、函数
        name2reg.exitScope();
        exitBlock();
        exitFunc();
    }

    // TODO(Lab 3-2): 生成变量声明语句 IR（局部变量分配、初始化）
    // 修改后
    void ASTCodeGen::visit(FE::AST::BlockStmt& node, Module* m)
    {
        name2reg.enterScope();

        if (node.stmts)
        {
            for (auto* s : *node.stmts)
            {
                if (!s) continue;

                // 当前块已经有 ret / br，则后续语句在语义上不可达，直接截断
                if (curBlock && isBlockTerminated(curBlock))
                    break;

                apply(*this, *s, m);
            }
        }

        name2reg.exitScope();
    }

   
   
    // TODO(Lab 3-2): 生成 return 语句 IR（可选返回值与类型转换）
    void ASTCodeGen::visit(FE::AST::ReturnStmt& node, Module* m)
    {
        (void)m;

        ASSERT(curFunc && "ReturnStmt must be inside a function");

        // 当前函数的返回类型
        DataType retType = curFunc->funcDef->retType;

        RetInst* inst = nullptr;

        if (!node.retExpr)
        {
            // return;   —— 只适用于返回类型为 void 的函数
            inst = createRetInst();
        }
        else
        {
            // 1. 先生成返回表达式的 IR
            apply(*this, *node.retExpr, m);

            // 2. 约定：表达式结果在当前函数最后一个寄存器里
            size_t resReg = getMaxReg();

            // 3. 检查表达式的实际类型（通过semantic check设置的）
            FE::AST::Type* exprType = node.retExpr->attr.val.value.type;
            DataType actualType = convert(exprType);
            
            // 4. 如果实际类型与函数返回类型不匹配，需要做类型转换
            size_t finalReg = resReg;
            if (actualType != retType && actualType != DataType::VOID)
            {
                auto convInsts = createTypeConvertInst(actualType, retType, resReg);
                for (auto& convInst : convInsts) curBlock->insert(convInst);
                finalReg = getMaxReg();
            }

            // 5. 生成return指令
            if (retType == DataType::VOID)
            {
                // 语义上不应该到这里（非 void 表达式返回 void），做个兜底
                inst = createRetInst();
            }
            else
            {
                inst = createRetInst(retType, finalReg);
            }
        }

        // 6. 把 ret 指令插入当前基本块末尾
        insert(inst);
    }

    void ASTCodeGen::visit(FE::AST::WhileStmt& node, Module* m)
    {
       
        ASSERT(curFunc && curBlock && "WhileStmt: curFunc/curBlock is null");
        (void)m;

        // DEBUG 使用
        /*
        long long loopId = ++DBG_loop_counter;   // 这个 while 的固定编号

        ++DBG_visit_While;
        if (DBG_visit_While == 1 ||
            DBG_visit_While == 100 ||
            DBG_visit_While == 1000 ||
            DBG_visit_While % 10000 == 0)
        {
            fprintf(stderr, "[DBG] WhileStmt visits = %lld\n", DBG_visit_While);
        }
        */

        Block* beforeLoop = curBlock;          // while 之前的块

        // 1) 创建 cond / body / end 三个基本块
        Block* condBlock = curFunc->createBlock(); // 条件判断块
        Block* bodyBlock = curFunc->createBlock(); // 循环体块
        Block* endBlock  = curFunc->createBlock(); // 循环结束块

        // 2) 如果前面的块还没结束，则从这里跳到 condBlock
        // 进入循环的第一步必须是条件判断，所以跳转目标只能是condBlock。
        if (!isBlockTerminated(beforeLoop))
        {
            beforeLoop->insts.push_back(createBranchInst(condBlock->blockId));
        }

        // 3) condBlock：计算条件并根据条件跳 body / end
        enterBlock(condBlock);

        if (node.cond)
        {
            // 生成条件表达式，转成i1(bool值)
            apply(*this, *node.cond, m);

            size_t   condReg  = getMaxReg();
            DataType condType = convert(node.cond->attr.val.value.type);

            // 先将循环条件转成 LLVM 的布尔类型（i1），确保能做 “真假判断”
            if (condType != DataType::I1)
            {
                auto convInsts = createTypeConvertInst(condType, DataType::I1, condReg);
                for (auto* inst : convInsts)
                    insert(inst);
                condReg  = getMaxReg();
                condType = DataType::I1;
            }
            // 条件分支：condReg为真→bodyBlock，假→endBlock->结束
            insert(createBranchInst(condReg, bodyBlock->blockId, endBlock->blockId));
        }
        else
        {
            // SysY 正常不会这样，这里兜底：无条件跳转到 bodyBlock
            insert(createBranchInst(bodyBlock->blockId));
        }

        // 4) 建立 break / continue 的跳转目标
        // while: continue -> condBlock, break -> endBlock
        // 进入最近一层循环的跳转栈 即内部循环continue/break只是对内部循环操作
        loopCondLabelStack.push_back(condBlock->blockId);
        loopEndLabelStack.push_back(endBlock->blockId);

        // 5) body：循环体
        enterBlock(bodyBlock);

        if (node.body)
        {
            apply(*this, *node.body, m);
        }

        // 注意：body 里可能又生成了 if/while/return/continue 等，
        // 此时 "当前块" 不一定就是一开始的 bodyBlock
        Block* bodyExit = curBlock;
        if (!isBlockTerminated(bodyExit))
        {
            // 从“正常执行到结尾”的路径回到 condBlock
            bodyExit->insts.push_back(createBranchInst(condBlock->blockId));
        }

        // 6) 弹出循环栈
        // 循环处理完成，弹出当前循环的跳转目标（避免影响外层循环 / 后续代码
        loopCondLabelStack.pop_back();
        loopEndLabelStack.pop_back();

        // 7) 后续语句从 endBlock 开始
        enterBlock(endBlock);
    }


    

    // if-else 语句处理
   void ASTCodeGen::visit(FE::AST::IfStmt& node, Module* m)
    {
        ASSERT(curFunc && curBlock && "IfStmt: curFunc/curBlock is null");
        (void)m;

        // 判断一个基本块最后是否已经有 terminator（br/ret）
        auto isTerminated = [](Block* b) -> bool {
            if (!b) return true;
            if (b->insts.empty()) return false;
            Instruction* last = b->insts.back();
            return last->isTerminator();
        };

        // 1. 为这一条 if 创建 then / end / else 块
        /*
        | 情况     | cond 为真跳到 | cond 为假跳到 |
        | 有 else | thenBlock | elseBlock |
        | 无 else | thenBlock | endBlock  |
        */
        Block* thenBlock = curFunc->createBlock();
        Block* endBlock  = curFunc->createBlock();
        // 存在elsestmt时才创建elseBlock
        Block* elseBlock = node.elseStmt ? curFunc->createBlock() : endBlock;

        // 2. 生成条件表达式所在的基本块 condBlock
        apply(*this, *node.cond, m);

        // 对于 && / ||，apply 过程中可能新建块，并把 curBlock 改到“条件结束块”
        // 不假设条件在一个块内完成，而是 取最终的 curBlock 作为 condBlock
        Block* condBlock = curBlock;

        size_t   condReg  = getMaxReg();
        DataType condType = convert(node.cond->attr.val.value.type);
        if (condType != DataType::I1)
        {
            auto convInsts = createTypeConvertInst(condType, DataType::I1, condReg);
            for (auto* inst : convInsts)
                condBlock->insert(inst);
            condReg  = getMaxReg();
            condType = DataType::I1;
        }

        // 在条件块末尾插入条件跳转
        condBlock->insert(createBranchInst(condReg, thenBlock->blockId, elseBlock->blockId));

        // 3. then 分支
        enterBlock(thenBlock);
        if (node.thenStmt)
            apply(*this, *node.thenStmt, m);

        Block* thenExit = curBlock;                 // then 分支生成完后所在的块
        if (!isTerminated(thenExit))
            thenExit->insert(createBranchInst(endBlock->blockId));

        // 4. else 分支（包含 else-if 的情况）
        // else 分支执行完，也跳 endBlock（如果存在的话）
        if (node.elseStmt)
        {
            enterBlock(elseBlock);
            apply(*this, *node.elseStmt, m);        // 这里可能是普通语句，也可能是一个嵌套 IfStmt

            Block* elseExit = curBlock;             // else 分支/else-if 生成完后所在的块（比如 Block9）
            if (!isTerminated(elseExit))
                elseExit->insert(createBranchInst(endBlock->blockId));
        }

        // 5. 后续语句从 endBlock 开始
        // 统一从 endBlock 继续后续代码
        enterBlock(endBlock);
    }
    

    


   
    
    // 修改后的
    void ASTCodeGen::visit(FE::AST::BreakStmt& node, Module* m)
    {
        (void)node;
        (void)m;
        ASSERT(curBlock && !loopEndLabelStack.empty() && "break not in loop");

        size_t target = loopEndLabelStack.back();

        // 不再 createBlock + enterBlock(dead)，
        // BlockStmt 里已经会在看到 terminator 后截断后续语句
        insert(createBranchInst(target));   // 真正的跳转
        
    }

    void ASTCodeGen::visit(FE::AST::ContinueStmt& node, Module* m)
    {
        (void)node;
        (void)m;
        ASSERT(curBlock && !loopCondLabelStack.empty() && "continue not in loop");

        size_t target = loopCondLabelStack.back();
        // while: 回 condBlock；for: 回 stepBlock
        // 同样不再造死块
        insert(createBranchInst(target));   

    }

    
    // For 语句的 IR 生成
    void ASTCodeGen::visit(FE::AST::ForStmt& node, Module* m)
    {
        ASSERT(curFunc && curBlock && "ForStmt: curFunc/curBlock is null");
        (void)m;

        // DEBUG 使用
        /*
        ++DBG_visit_For;
        if (DBG_visit_For == 1 ||
            DBG_visit_For == 100 ||
            DBG_visit_For == 1000 ||
            DBG_visit_For % 10000 == 0)
        {
            fprintf(stderr, "[DBG] ForStmt visits = %lld\n", DBG_visit_For);
        }
        */

        Block* beforeLoop = curBlock;

        // 0) init：在当前块执行一次
        if (node.init)
        {
            apply(*this, *node.init, m);
        }
        beforeLoop = curBlock;   // init 之后可能切换了块

        // 1) 创建 cond / body / step / end 四个基本块
        Block* condBlock = curFunc->createBlock();
        Block* bodyBlock = curFunc->createBlock();
        Block* stepBlock = curFunc->createBlock();
        Block* endBlock  = curFunc->createBlock();

        // 2) 如果 init 之后的块还没有 terminator，则跳到 condBlock
        if (!isBlockTerminated(beforeLoop))
        {
            beforeLoop->insts.push_back(createBranchInst(condBlock->blockId));
        }

        // 3) condBlock：计算条件
        enterBlock(condBlock);


       
        if (node.cond)
        {
            apply(*this, *node.cond, m);

            size_t   condReg  = getMaxReg();
            DataType condType = convert(node.cond->attr.val.value.type);
            if (condType != DataType::I1)
            {
                auto convInsts = createTypeConvertInst(condType, DataType::I1, condReg);
                for (auto* inst : convInsts)
                    insert(inst);
                condReg  = getMaxReg();
                condType = DataType::I1;
            }

            insert(createBranchInst(condReg, bodyBlock->blockId, endBlock->blockId));
        }
        else
        {
            // for(;;) —— 无条件跳到 body
            insert(createBranchInst(bodyBlock->blockId));
        }

        // 4) 压栈：continue -> stepBlock, break -> endBlock
        loopCondLabelStack.push_back(stepBlock->blockId);
        loopEndLabelStack.push_back(endBlock->blockId);

        // 5) body
        enterBlock(bodyBlock);
        if (node.body)
        {
            apply(*this, *node.body, m);
        }

        Block* bodyExit = curBlock;
        if (!isBlockTerminated(bodyExit))
        {
            bodyExit->insts.push_back(createBranchInst(stepBlock->blockId));
        }

        // 6) stepBlock：执行 step，再回 condBlock
        enterBlock(stepBlock);
        if (node.step)
        {
            apply(*this, *node.step, m);
        }

        Block* stepExit = curBlock;
        if (!isBlockTerminated(stepExit))
        {
            stepExit->insts.push_back(createBranchInst(condBlock->blockId));
        }

        // 7) 出栈
        loopCondLabelStack.pop_back();
        loopEndLabelStack.pop_back();

        // 8) 后续语句从 endBlock 开始
        enterBlock(endBlock);
    }



    // 自己加的：
  
    void ASTCodeGen::visit(FE::AST::VarDeclStmt& node, Module* m)
    {
        // VarDeclStmt 本身只是“声明语句”这一层包装，
        // 真正的变量声明细节在内部的 VarDeclaration 里，
        // 所以这里直接把工作转交给 VarDeclaration 的 visit。
        if (!node.decl) return;
        apply(*this, *node.decl, m);
    }

}  // namespace ME

