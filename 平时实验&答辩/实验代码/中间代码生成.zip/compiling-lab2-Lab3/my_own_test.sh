#!/usr/bin/env bash
# 语义检查综合测试脚本
# 放在仓库根目录下执行：
#   chmod +x test_semantic_all.sh
#   ./test_semantic_all.sh
#
# 覆盖的检查点（指导书要求）：
#   1) main 函数是否存在
#   2) 未声明变量 / 未声明函数
#   3) 同一作用域下重复声明变量
#   4) 条件/运算表达式：void 不能参与
#   5) 函数调用：形参与实参类型、个数匹配（含 SysY 运行时库）
#   6) 整型变量除以整型常量 0（编译期可判定）
#   7) 非 void 函数的返回语义 / void 函数返回值
#   8) break / continue 只能在循环内使用
#   9) （可选）全局作用域非法语句（如果你的文法允许）

set -u  # 不用 set -e，因为我们希望保留各个用例的错误输出

COMPILER=bin/compiler
OUT=/tmp/semant.ll
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SEMANT_DIR="$ROOT_DIR/testcase/semant"
MANUAL_DIR="$SEMANT_DIR/manual"

mkdir -p "$MANUAL_DIR"

########################################
# 1. 生成手写的补充测试样例
########################################

# 1.1 缺少 main 函数：检查 “是否存在 main 函数”
cat > "$MANUAL_DIR/no_main.sy" << 'EOF'
// [manual/no_main.sy]
// 覆盖点：1) main 函数是否存在
int foo() {
    return 0;
}
EOF

# 1.2 非 void 函数完全不写 return：触发 "Non-void function may not return a value"
cat > "$MANUAL_DIR/non_void_no_return.sy" << 'EOF'
// [manual/non_void_no_return.sy]
// 覆盖点：7) 非 void 函数返回语义 —— 非 void 函数可能不返回
int f() {
    int x = 5;
    x = x + 1;
    // 故意不写 return
}

int main() {
    return 0;
}
EOF

# 1.3 非 void 函数写了 "return;"：触发 "Missing return value in non-void function"
cat > "$MANUAL_DIR/non_void_return_without_value.sy" << 'EOF'
// [manual/non_void_return_without_value.sy]
// 覆盖点：7) 非 void 函数返回语义 —— return; 在非 void 函数中
int f() {
    return;
}

int main() {
    return 0;
}
EOF

# 1.4 void 函数返回一个值：触发 "Return with a value in void function"
cat > "$MANUAL_DIR/void_return_with_value.sy" << 'EOF'
// [manual/void_return_with_value.sy]
// 覆盖点：7) void 函数返回值
void f() {
    return 123;
}

int main() {
    f();
    return 0;
}
EOF

# 1.5 break / continue 不在循环中
cat > "$MANUAL_DIR/break_continue_outside_loop.sy" << 'EOF'
// [manual/break_continue_outside_loop.sy]
// 覆盖点：8) break / continue 只能在循环内部使用
int main() {
    break;
    continue;
    return 0;
}
EOF

# 1.6 数组下标为 void 表达式：触发 "Array index has void type"
cat > "$MANUAL_DIR/array_index_void.sy" << 'EOF'
// [manual/array_index_void.sy]
// 覆盖点：4) void 不能参与表达式 —— 数组下标为 void
int main() {
    int a[10];
    // putint 返回 void，作为下标会被判为 void 类型
    a[putint(1)] = 5;
    return 0;
}
EOF

# 1.7 If / While 条件为 void：触发 "If/While condition has void type"
cat > "$MANUAL_DIR/cond_void.sy" << 'EOF'
// [manual/cond_void.sy]
// 覆盖点：4) 条件表达式类型检查 —— 条件为 void
int main() {
    if (putint(3)) {
        return 1;
    }
    while (putch(65)) {
        return 2;
    }
    return 0;
}
EOF

# 1.8（可选）int / bool 隐式转换的“正确用例”：应该通过语义检查
cat > "$MANUAL_DIR/bool_int_ok.sy" << 'EOF'
// [manual/bool_int_ok.sy]
// 覆盖点：3) 条件判断和运算表达式：int 和 bool 隐式类型转换
int main() {
    int a = 5;
    // !a 是 bool，a 是 int，a + !a 应该被接受
    return a + !a;
}
EOF

# 1.9 全局重复定义变量（你之前已经测过局部多重定义）
cat > "$MANUAL_DIR/global_multi_def.sy" << 'EOF'
// [manual/global_multi_def.sy]
// 覆盖点：2) 同一作用域下重复声明变量 —— 全局作用域
int x = 1;
int x = 2;

int main() {
    return x;
}
EOF

# 1.10 （可选）全局非法语句（仅在你的文法允许全局语句时才会进入语义检查）
cat > "$MANUAL_DIR/global_illegal_stmt.sy" << 'EOF'
// [manual/global_illegal_stmt.sy]
// 覆盖点：7) 若语法允许：全局作用域内不应出现的语句
int x = 0;
x = 1;          // 如果你的语法允许这行通过语法阶段，就应该在语义检查中报错
int main() {
    return 0;
}
EOF


########################################
# 2. 定义一个统一的运行函数
########################################
run_case() {
    local name="$1"
    local file="$2"
    local desc="$3"

    echo "================================"
    echo "[$name]"
    echo "  用例文件: $file"
    echo "  覆盖内容: $desc"
    echo "--------------------------------"

    if [[ ! -f "$file" ]]; then
        echo "  [跳过] 文件不存在：$file"
        echo
        return
    fi

    # 编译，不中断脚本
    "$COMPILER" -llvm "$file" -o "$OUT" || true
    echo
}

########################################
# 3. 跑手写 manual 用例
########################################

run_case "manual-no-main"        "$MANUAL_DIR/no_main.sy"                     "缺少 main 函数"
run_case "manual-non-void-no-ret" "$MANUAL_DIR/non_void_no_return.sy"         "非 void 函数可能不返回（函数体内没有任何 return）"
run_case "manual-non-void-ret;"   "$MANUAL_DIR/non_void_return_without_value.sy" "非 void 函数中写了 return;（缺少返回值）"
run_case "manual-void-ret-value"  "$MANUAL_DIR/void_return_with_value.sy"     "void 函数中带返回值的 return"
run_case "manual-break-continue"  "$MANUAL_DIR/break_continue_outside_loop.sy" "break / continue 不在循环中"
run_case "manual-array-index-void" "$MANUAL_DIR/array_index_void.sy"          "数组下标为 void 表达式"
run_case "manual-cond-void"       "$MANUAL_DIR/cond_void.sy"                  "If / While 条件为 void 类型"
run_case "manual-bool-int-ok"     "$MANUAL_DIR/bool_int_ok.sy"                "int 与 bool 隐式类型转换（应通过语义检查）"
run_case "manual-global-multi-def" "$MANUAL_DIR/global_multi_def.sy"          "全局作用域下变量重复定义"
run_case "manual-global-illegal-stmt" "$MANUAL_DIR/global_illegal_stmt.sy"    "（可选）全局非法语句：若语法允许"


########################################
# 4. 跑你已经在用的官方 semant 用例
########################################

# 4.1 除以 0：div_zero1/2.sy
run_case "div_zero1" "$SEMANT_DIR/div_zero1.sy" "整型变量除以编译期常量 0（复杂算术 5-4-1）"
run_case "div_zero2" "$SEMANT_DIR/div_zero2.sy" "整型变量除以编译期常量 0（参数中含 getint 等）"

# 4.2 invalid_expr1-4：void 参与表达式、返回类型不匹配等
run_case "invalid_expr1" "$SEMANT_DIR/invalid_expr1.sy" "把 void 函数调用结果赋给变量（Invalid initialization from void expression）"
run_case "invalid_expr2" "$SEMANT_DIR/invalid_expr2.sy" "return 一个 void 表达式（Return type mismatch）"
run_case "invalid_expr3" "$SEMANT_DIR/invalid_expr3.sy" "void 函数调用参与加法，触发 Binary operator applied to void expression + 初始化错误"
run_case "invalid_expr4" "$SEMANT_DIR/invalid_expr4.sy" "if 条件中使用 void，触发 If condition has void type"

# 4.3 multi_def1-3：同一作用域重复声明变量
run_case "multi_def1" "$SEMANT_DIR/multi_def1.sy" "在同一函数块内重复定义局部变量 x"
run_case "multi_def2" "$SEMANT_DIR/multi_def2.sy" "在同一函数块内重复定义局部变量 z"
run_case "multi_def3" "$SEMANT_DIR/multi_def3.sy" "在嵌套块中重复定义局部变量 z2"

# 4.4 undef1-4：未声明变量 / 未声明函数 / void 条件等
run_case "undef1" "$SEMANT_DIR/undef1.sy" "return 未声明变量 x（Use of undefined variable）"
run_case "undef2" "$SEMANT_DIR/undef2.sy" "调用未声明函数 getc（Call to undefined function）"
run_case "undef3" "$SEMANT_DIR/undef3.sy" "表达式中包含未声明变量 e"
run_case "undef4" "$SEMANT_DIR/undef4.sy" "while 条件中使用未声明变量 z"

# 4.5 unmatch_call1-5：形参与实参类型 / 个数不匹配（含 SysY 运行时库）
run_case "unmatch_call1" "$SEMANT_DIR/unmatch_call1.sy" "多层嵌套地把 void 函数 putint 当作参数，多次触发 Argument type mismatch"
run_case "unmatch_call2" "$SEMANT_DIR/unmatch_call2.sy" "putint() 实参与形参个数不匹配（0 vs 1）"
run_case "unmatch_call3" "$SEMANT_DIR/unmatch_call3.sy" "putint(3,4,5) 实参与形参个数不匹配（3 vs 1）"
run_case "unmatch_call4" "$SEMANT_DIR/unmatch_call4.sy" "putint(getint(),getint()) 个数不匹配（2 vs 1）"
run_case "unmatch_call5" "$SEMANT_DIR/unmatch_call5.sy" "putch(getint(), putint(getint())) 个数不匹配（2 vs 1）"

echo "================================"
echo "全部语义测试已跑完。"
echo "你可以逐个对照上面的『覆盖内容』，看错误信息是否与预期一致。"
